# Sub-Admin Manager 1.1.3

Developer: Digital BE — https://digitalbe.in

## Purpose

Creates a controlled **Sub-Admin** role for WordPress sites. The main Administrator controls the left-menu modules/sub-items available to Sub-Admins, defines a landing module, controls the user hierarchy, and can present a professional branded WordPress login screen.

## Release 1.1.3 — Login branding simplification and production hardening

- Fixed the WordPress Media Library picker so **Select login logo** reliably opens the native media modal after the required media scripts are loaded.
- Custom login logo selection accepts images only and stores the attachment ID.
- **Remove logo** clears the selected attachment and preview.
- Removed the visible Login brand name/tagline layer from the feature. Custom login branding is now intentionally logo/layout focused.
- A blank or previously stored site title is never rendered as visible login branding.
- The standard login document title and logo accessibility label are kept neutral and do not expose the website name through this feature.
- WordPress core's default “Go to <site title>” footer link is replaced with a neutral “Back to website” link while branded login mode is enabled.
- Legacy brand-name/tagline settings, if present from an earlier release, are retained harmlessly in the database but are no longer rendered.
- Updated release version to 1.1.3.

## Release 1.1.0 security/access hardening retained

- Sub-Admin admin bar is suppressed in wp-admin as well as normal front-end contexts, including users created below a Sub-Admin.
- Hidden admin screens are separately checked at request time; hiding a menu is not treated as the security boundary.
- Dashboard can redirect to the configured landing module.
- Protected Administrator/Sub-Admin roles cannot be exposed or assigned by lower-level users through the normal role-management paths, REST user queries, registration, default-role changes, or later role changes.
- `options.php` is handled as a Settings API special case so legitimate permitted plugin settings screens continue to work while unpermitted settings paths remain protected.
- External/forged HTTP referers are not accepted as proof of a permitted local settings screen.
- Digital BE branding is included on the plugin screen and plugin action links.

## Login branding

Use **Settings > Login screen branding**.

- Enable the professional branded login screen.
- Select a custom image from the WordPress Media Library.
- The selected image replaces the standard WordPress login logo presentation.
- The logo link points to the site's own home page.
- When no custom image is selected, the site's custom logo or site icon may be used automatically.
- The feature intentionally adds **no visible site-name/brand-name text or plugin footer text** to the login card.
- The normal WordPress login URLs remain unchanged.

## Production deployment

Take a complete backup before replacing the plugin. Keep a main Administrator session available and perform a short site-specific smoke test after activation: administrator access, one clean Sub-Admin login, landing-page redirect, permitted/denied screen access, logout, login branding, and any Settings API screen that the site intentionally grants.

Third-party AJAX/REST/custom endpoints must continue to enforce their own capabilities and nonces; menu visibility alone cannot safely infer arbitrary endpoint permissions.
