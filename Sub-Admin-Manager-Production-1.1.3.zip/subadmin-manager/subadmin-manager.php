<?php
/**
 * Plugin Name:       Sub-Admin Manager
 * Description:       Adds a "Sub-Admin" user type (ideal for handing a site to a client). The main Administrator controls exactly which left-menu modules and sub-items a Sub-Admin sees, sets a landing module per Sub-Admin, adds custom menu links, and keeps a safe user hierarchy. The admin bar is hidden for Sub-Admins and everyone they create.
 * Version:           1.1.3
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            Digital BE
 * Author URI:        https://digitalbe.in
 * License:           GPL-2.0-or-later
 *
 * Intended for single-site WordPress installs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPSA_Plugin {

	const ROLE         = 'sub_admin';
	const OPT          = 'wpsa_settings';
	const SNAP         = 'wpsa_menu_snapshot';
	const PAGE         = 'wpsa';
	const SEP          = '>>'; // Separates parent and child slug inside a submenu key.
	const META_LANDING = '_wpsa_landing';
	const META_BY      = '_wpsa_created_by';
	const META_ROOT    = '_wpsa_root'; // ID of the Sub-Admin at the top of this user's creation chain.

	/** Roles nobody below the main Administrator can create, edit, delete, promote or even see in lists. */
	const PROTECTED_ROLES = array( 'administrator', 'sub_admin' );

	/** What a Sub-Admin sees until the admin saves the permission matrix for the first time. */
	const DEFAULT_TOPS = array( 'index.php', 'edit.php', 'upload.php', 'edit.php?post_type=page', 'edit-comments.php', 'users.php', 'profile.php' );

	private static $instance = null;

	private $settings     = array();
	private $allowed      = array(); // Menu slugs kept for the current user (this request).
	private $denied       = array(); // Menu slugs removed for the current user (this request).
	private $first_url    = '';
	private $sub_caps     = null;
	private $blocked      = null;
	private $new_tab_urls = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function activate() {
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, 'Sub-Admin', array( 'read' => true ) );
		}
		set_transient( 'wpsa_activated', 1, 120 );
	}

	private function __construct() {
		$this->settings = $this->load_settings();

		add_action( 'init', array( $this, 'ensure_role' ), 5 );

		// Menu handling.
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
		add_action( 'admin_menu', array( $this, 'save_snapshot' ), 999990 );
		add_action( 'admin_menu', array( $this, 'apply_hiding' ), 999999 );
		add_action( 'admin_menu', array( $this, 'add_custom_links' ), 1000000 );
		add_action( 'admin_menu', array( $this, 'enforce_menu_access' ), 1000001 );
		add_action( 'admin_init', array( $this, 'enforce_access' ), 1 );
		add_action( 'admin_init', array( $this, 'force_hide_admin_bar' ), 999999 );
		add_action( 'admin_init', array( $this, 'maybe_redirect_after_activation' ) );
		add_action( 'admin_head', array( $this, 'admin_head_css' ), PHP_INT_MAX );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'admin_footer', array( $this, 'footer_script' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );

		// Saving settings (main admin only).
		add_action( 'admin_post_wpsa_save_permissions', array( $this, 'handle_save_permissions' ) );
		add_action( 'admin_post_wpsa_save_links', array( $this, 'handle_save_links' ) );
		add_action( 'admin_post_wpsa_save_settings', array( $this, 'handle_save_settings' ) );

		// Capabilities and hierarchy.
		add_filter( 'user_has_cap', array( $this, 'filter_user_has_cap' ), 10, 4 );
		add_filter( 'map_meta_cap', array( $this, 'filter_map_meta_cap' ), 10, 4 );
		add_filter( 'editable_roles', array( $this, 'filter_editable_roles' ) );
		add_action( 'pre_get_users', array( $this, 'filter_user_query' ) );
		add_filter( 'rest_user_query', array( $this, 'filter_rest_user_query' ) );
		add_filter( 'pre_update_option_default_role', array( $this, 'guard_default_role' ), 10, 2 );
		add_action( 'user_register', array( $this, 'track_creator' ) );
		add_action( 'user_register', array( $this, 'guard_registered_role' ), 20, 1 );
		add_action( 'set_user_role', array( $this, 'guard_role_change' ), 10, 3 );

		// Admin bar and landing page.
		add_filter( 'show_admin_bar', array( $this, 'filter_admin_bar' ), PHP_INT_MAX );
		add_filter( 'login_redirect', array( $this, 'filter_login_redirect' ), 99, 3 );
		add_action( 'load-index.php', array( $this, 'redirect_dashboard' ) );

		// Built-in WordPress login branding. The login URL remains the normal WordPress URL.
		add_filter( 'login_headerurl', array( $this, 'login_header_url' ), 99 );
		add_filter( 'login_headertext', array( $this, 'login_header_text' ), 99 );
		add_filter( 'login_title', array( $this, 'login_title' ), 99, 2 );
		add_filter( 'login_site_html_link', array( $this, 'login_site_html_link' ), 99 );
		add_filter( 'login_body_class', array( $this, 'login_body_class' ), 99, 2 );
		add_action( 'login_enqueue_scripts', array( $this, 'login_enqueue_styles' ), 99 );

		// User screens.
		add_action( 'user_new_form', array( $this, 'render_landing_field_new' ) );
		add_action( 'edit_user_profile', array( $this, 'render_landing_field_edit' ) );
		add_action( 'edit_user_created_user', array( $this, 'save_landing_new' ), 10, 1 );
		add_action( 'edit_user_profile_update', array( $this, 'save_landing_edit' ) );
		add_filter( 'manage_users_columns', array( $this, 'users_column' ) );
		add_filter( 'manage_users_custom_column', array( $this, 'users_column_value' ), 10, 3 );

		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
	}

	/* =====================================================================
	 * Settings helpers
	 * =================================================================== */

	private function load_settings() {
		$defaults = array(
			'perm'                 => array(),      // role => array( 'mode' => 'allow'|'hide', 'keys' => array() ).
			'links'                => array(),
			'enforce'              => 1,            // Block hidden pages by URL too.
			'allow_manage_options' => 0,
			'scope'                => 'all_below',  // or 'own'.
			'creatable'            => null,         // null = every role except the protected ones.
			'hide_bar'             => 1,
			'add_logout'           => 1,
			'login_branding'       => 1,
			'login_logo_id'        => 0,
			'login_brand_name'     => '',
			'login_tagline'        => 'Sign in to continue',
		);
		$saved = get_option( self::OPT, array() );
		return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
	}

	private function persist() {
		update_option( self::OPT, $this->settings );
	}

	public function ensure_role() {
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, 'Sub-Admin', array( 'read' => true ) );
		}
	}

	public function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">Settings</a>' );
		$links[] = '<a href="https://digitalbe.in" target="_blank" rel="noopener noreferrer">Digital BE</a>';
		return $links;
	}

	/* =====================================================================
	 * Who is who
	 * =================================================================== */

	private function resolve_user( $user ) {
		if ( null === $user ) {
			return wp_get_current_user();
		}
		if ( is_numeric( $user ) ) {
			return get_userdata( (int) $user );
		}
		return $user;
	}

	/** Main admin = a real Administrator. (We never use is_super_admin(): on single sites it is true for anyone with delete_users.) */
	private function is_main_admin( $user = null ) {
		$user = $this->resolve_user( $user );
		return ( $user instanceof WP_User ) && $user->exists() && in_array( 'administrator', (array) $user->roles, true );
	}

	private function is_sub_admin( $user = null ) {
		$user = $this->resolve_user( $user );
		return ( $user instanceof WP_User ) && $user->exists() && in_array( self::ROLE, (array) $user->roles, true );
	}

	/** Sub-Admins and anyone they created (directly or down the chain). */
	private function is_below_line( $user = null ) {
		$user = $this->resolve_user( $user );
		if ( ! ( $user instanceof WP_User ) || ! $user->exists() || $this->is_main_admin( $user ) ) {
			return false;
		}
		return $this->is_sub_admin( $user ) || (bool) get_user_meta( $user->ID, self::META_ROOT, true );
	}

	/* =====================================================================
	 * Capabilities: Sub-Admin = Administrator minus the dangerous caps
	 * =================================================================== */

	private function blocked_caps() {
		if ( null === $this->blocked ) {
			$blocked = array(
				'install_plugins', 'activate_plugins', 'edit_plugins', 'delete_plugins', 'update_plugins', 'resume_plugins', 'upload_plugins',
				'install_themes', 'switch_themes', 'edit_themes', 'delete_themes', 'update_themes', 'resume_themes', 'upload_themes',
				'update_core', 'update_php', 'update_https', 'edit_files',
				'manage_privacy_options', 'export_others_personal_data', 'erase_others_personal_data',
				'delete_site', 'manage_network', 'manage_sites', 'manage_network_users', 'manage_network_plugins', 'manage_network_themes', 'manage_network_options',
			);
			if ( empty( $this->settings['allow_manage_options'] ) ) {
				$blocked[] = 'manage_options';
			}
			$this->blocked = (array) apply_filters( 'wpsa_blocked_caps', $blocked );
		}
		return $this->blocked;
	}

	private function sub_admin_caps() {
		if ( null === $this->sub_caps ) {
			$this->sub_caps = array();
			$admin          = get_role( 'administrator' );
			if ( $admin ) {
				foreach ( (array) $admin->capabilities as $cap => $grant ) {
					if ( $grant ) {
						$this->sub_caps[] = (string) $cap;
					}
				}
			}
		}
		return $this->sub_caps;
	}

	public function filter_user_has_cap( $allcaps, $caps, $args, $user ) {
		if ( ! ( $user instanceof WP_User ) || ! in_array( self::ROLE, (array) $user->roles, true ) ) {
			return $allcaps;
		}
		foreach ( $this->sub_admin_caps() as $cap ) {
			$allcaps[ $cap ] = true;
		}
		foreach ( $this->blocked_caps() as $cap ) {
			$allcaps[ $cap ] = false;
		}
		return $allcaps;
	}

	/* =====================================================================
	 * User hierarchy: nobody below the line can touch Administrators / Sub-Admins
	 * =================================================================== */

	public function filter_map_meta_cap( $caps, $cap, $user_id, $args ) {
		static $targets = array(
			'edit_user'    => 1,
			'delete_user'  => 1,
			'promote_user' => 1,
			'remove_user'  => 1,
		);
		if ( ! isset( $targets[ $cap ] ) || empty( $args[0] ) ) {
			return $caps;
		}
		$actor = get_userdata( (int) $user_id );
		if ( ! $actor || $this->is_main_admin( $actor ) ) {
			return $caps;
		}
		$target_id = (int) $args[0];

		if ( $target_id === (int) $user_id ) {
			// Editing your own profile is fine; promoting / deleting yourself is not (Sub-Admins only).
			if ( 'edit_user' !== $cap && $this->is_sub_admin( $actor ) ) {
				return array( 'do_not_allow' );
			}
			return $caps;
		}

		$target = get_userdata( $target_id );
		if ( ! $target ) {
			return $caps;
		}
		if ( array_intersect( self::PROTECTED_ROLES, (array) $target->roles ) ) {
			return array( 'do_not_allow' );
		}
		if ( $this->is_sub_admin( $actor ) && 'own' === $this->settings['scope'] ) {
			if ( (int) get_user_meta( $target_id, self::META_ROOT, true ) !== (int) $user_id ) {
				return array( 'do_not_allow' );
			}
		}
		return $caps;
	}

	private function creatable_roles() {
		$c = $this->settings['creatable'];
		if ( ! is_array( $c ) ) {
			$c = array_keys( wp_roles()->get_names() );
		}
		return array_values( array_diff( array_map( 'strval', $c ), self::PROTECTED_ROLES ) );
	}

	public function filter_editable_roles( $roles ) {
		$user = wp_get_current_user();
		if ( ! $user->exists() || $this->is_main_admin( $user ) ) {
			return $roles;
		}
		foreach ( self::PROTECTED_ROLES as $r ) {
			unset( $roles[ $r ] );
		}
		if ( $this->is_sub_admin( $user ) ) {
			$allowed = $this->creatable_roles();
			foreach ( array_keys( $roles ) as $slug ) {
				if ( ! in_array( (string) $slug, $allowed, true ) ) {
					unset( $roles[ $slug ] );
				}
			}
		}
		return $roles;
	}

	private function restrict_query_args( $args ) {
		$user = wp_get_current_user();
		if ( ! $user->exists() || $this->is_main_admin( $user ) ) {
			return $args;
		}
		$not                  = isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array();
		$args['role__not_in'] = array_values( array_unique( array_merge( $not, self::PROTECTED_ROLES ) ) );
		if ( $this->is_sub_admin( $user ) && 'own' === $this->settings['scope'] ) {
			$mq   = ( isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ) ? $args['meta_query'] : array();
			$mq[] = array(
				'key'     => self::META_ROOT,
				'value'   => (string) $user->ID,
				'compare' => '=',
			);
			$args['meta_query'] = $mq;
		}
		return $args;
	}

	public function filter_user_query( $query ) {
		global $pagenow;
		if ( ! is_admin() || 'users.php' !== $pagenow ) {
			return;
		}
		$query->query_vars = $this->restrict_query_args( $query->query_vars );
	}

	public function filter_rest_user_query( $args ) {
		return $this->restrict_query_args( $args );
	}

	public function guard_default_role( $new, $old ) {
		if ( is_user_logged_in() && ! $this->is_main_admin() && in_array( $new, self::PROTECTED_ROLES, true ) ) {
			return $old;
		}
		return $new;
	}

	public function track_creator( $user_id ) {
		$actor = wp_get_current_user();
		if ( ! $actor->exists() || (int) $actor->ID === (int) $user_id ) {
			return;
		}
		$root = 0;
		if ( $this->is_sub_admin( $actor ) ) {
			$root = (int) $actor->ID;
		} else {
			$root = (int) get_user_meta( $actor->ID, self::META_ROOT, true );
		}
		if ( $root ) {
			update_user_meta( $user_id, self::META_BY, (int) $actor->ID );
			update_user_meta( $user_id, self::META_ROOT, $root );
		}
	}

	/** Prevent direct programmatic creation of protected roles by users below the main admin. */
	public function guard_registered_role( $user_id ) {
		$actor = wp_get_current_user();
		if ( ! $actor->exists() || $this->is_main_admin( $actor ) ) {
			return;
		}
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return;
		}
		if ( array_intersect( self::PROTECTED_ROLES, (array) $user->roles ) ) {
			$role = $this->creatable_roles();
			$fallback = ! empty( $role ) ? reset( $role ) : get_option( 'default_role', 'subscriber' );
			if ( in_array( $fallback, self::PROTECTED_ROLES, true ) || ! get_role( $fallback ) ) {
				$fallback = 'subscriber';
			}
			$user->set_role( $fallback );
		}
	}

	/** Catch any later protected-role assignment performed by another pathway in the same request. */
	public function guard_role_change( $user_id, $role, $old_roles ) {
		$actor = wp_get_current_user();
		if ( ! $actor->exists() || $this->is_main_admin( $actor ) || ! in_array( $role, self::PROTECTED_ROLES, true ) ) {
			return;
		}
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return;
		}
		$fallback = '';
		foreach ( (array) $old_roles as $old_role ) {
			if ( ! in_array( $old_role, self::PROTECTED_ROLES, true ) && get_role( $old_role ) ) {
				$fallback = $old_role;
				break;
			}
		}
		if ( '' === $fallback ) {
			$creatable = $this->creatable_roles();
			$fallback = ! empty( $creatable ) ? reset( $creatable ) : get_option( 'default_role', 'subscriber' );
		}
		if ( in_array( $fallback, self::PROTECTED_ROLES, true ) || ! get_role( $fallback ) ) {
			$fallback = 'subscriber';
		}
		remove_action( 'set_user_role', array( $this, 'guard_role_change' ), 10 );
		$user->set_role( $fallback );
		add_action( 'set_user_role', array( $this, 'guard_role_change' ), 10, 3 );
	}

	public function users_column( $cols ) {
		if ( $this->is_main_admin() ) {
			$cols['wpsa_by'] = 'Created by';
		}
		return $cols;
	}

	public function users_column_value( $out, $column, $user_id ) {
		if ( 'wpsa_by' !== $column ) {
			return $out;
		}
		$by = (int) get_user_meta( $user_id, self::META_BY, true );
		if ( ! $by ) {
			return '&mdash;';
		}
		$u = get_userdata( $by );
		return $u ? esc_html( $u->display_name ) : '&mdash;';
	}

	/* =====================================================================
	 * Admin bar
	 * =================================================================== */

	public function filter_admin_bar( $show ) {
		if ( empty( $this->settings['hide_bar'] ) || ! is_user_logged_in() ) {
			return $show;
		}
		return $this->is_below_line() ? false : $show;
	}

	/**
	 * show_admin_bar() is the front-end API, while wp-admin has its own toolbar
	 * initialization path. Force the global state off for below-line users in
	 * wp-admin as well, using the documented admin_init timing.
	 */
	public function force_hide_admin_bar() {
		if ( empty( $this->settings['hide_bar'] ) || ! is_user_logged_in() || ! $this->is_below_line() ) {
			return;
		}
		show_admin_bar( false );
	}

	/** Extra CSS fallback for the dashboard toolbar. This handles current WordPress
	 * behavior where the toolbar cannot be disabled through show_admin_bar() alone
	 * inside wp-admin.
	 */
	public function admin_head_css() {
		if ( empty( $this->settings['hide_bar'] ) || ! is_user_logged_in() || ! $this->is_below_line() ) {
			return;
		}
		?>
		<style id="wpsa-hide-admin-bar">
			#wpadminbar{display:none!important;}
			html.wp-toolbar{padding-top:0!important;}
		</style>
		<?php
	}

	/* =====================================================================
	 * Menu snapshot (a full list of menus, captured while an Administrator browses wp-admin)
	 * =================================================================== */

	private function get_snapshot() {
		$s = get_option( self::SNAP, array() );
		return is_array( $s ) ? $s : array();
	}

	private function clean_title( $html ) {
		$t = wp_strip_all_tags( (string) $html );
		$t = preg_replace( '/\s*\d+$/u', '', $t );
		return trim( (string) $t );
	}

	public function save_snapshot() {
		if ( ! $this->is_main_admin() ) {
			return;
		}
		global $menu, $submenu;
		$rows = array();
		foreach ( (array) $menu as $item ) {
			if ( empty( $item[2] ) || ( isset( $item[4] ) && false !== strpos( $item[4], 'wp-menu-separator' ) ) ) {
				continue;
			}
			$slug = (string) $item[2];
			if ( self::PAGE === $slug ) {
				continue;
			}
			$title = $this->clean_title( isset( $item[0] ) ? $item[0] : '' );
			$row   = array(
				'title'    => '' !== $title ? $title : $slug,
				'children' => array(),
			);
			if ( ! empty( $submenu[ $slug ] ) ) {
				foreach ( (array) $submenu[ $slug ] as $sub ) {
					if ( empty( $sub[2] ) ) {
						continue;
					}
					$ct = $this->clean_title( isset( $sub[0] ) ? $sub[0] : '' );
					$row['children'][ (string) $sub[2] ] = '' !== $ct ? $ct : (string) $sub[2];
				}
			}
			$rows[ $slug ] = $row;
		}
		if ( $rows !== $this->get_snapshot() ) {
			update_option( self::SNAP, $rows, false );
		}
	}

	private function all_keys() {
		$keys = array();
		foreach ( $this->get_snapshot() as $top => $row ) {
			$top    = (string) $top;
			$keys[] = $top;
			foreach ( array_keys( (array) $row['children'] ) as $c ) {
				$keys[] = $top . self::SEP . $c;
			}
		}
		return $keys;
	}

	/** A top-level item with children is visible only if at least one child is; ticking a child ticks its parent. */
	private function normalize_visible( array $visible ) {
		$vis = array_flip( $visible );
		foreach ( $this->get_snapshot() as $top => $row ) {
			$top = (string) $top;
			if ( empty( $row['children'] ) ) {
				continue;
			}
			$any = false;
			foreach ( array_keys( $row['children'] ) as $c ) {
				if ( isset( $vis[ $top . self::SEP . $c ] ) ) {
					$any = true;
					break;
				}
			}
			if ( $any ) {
				$vis[ $top ] = true;
			} else {
				unset( $vis[ $top ] );
			}
		}
		return array_map( 'strval', array_keys( $vis ) );
	}

	/* =====================================================================
	 * Permissions
	 * =================================================================== */

	private function default_allows( $key ) {
		$parts = explode( self::SEP, $key, 2 );
		if ( ! in_array( $parts[0], self::DEFAULT_TOPS, true ) ) {
			return false;
		}
		return ! ( isset( $parts[1] ) && 'update-core.php' === $parts[1] );
	}

	private function sub_admin_allows( $key ) {
		$perm = $this->settings['perm'];
		if ( isset( $perm[ self::ROLE ]['keys'] ) ) {
			return in_array( $key, (array) $perm[ self::ROLE ]['keys'], true );
		}
		return $this->default_allows( $key );
	}

	private function role_shows( $role, $key ) {
		if ( self::ROLE === $role ) {
			return $this->sub_admin_allows( $key );
		}
		$hidden = isset( $this->settings['perm'][ $role ]['keys'] ) ? (array) $this->settings['perm'][ $role ]['keys'] : array();
		return ! in_array( $key, $hidden, true );
	}

	private function hidden_keys_for( $user ) {
		$hidden = array();
		foreach ( (array) $user->roles as $role ) {
			if ( self::ROLE === $role ) {
				continue;
			}
			if ( ! empty( $this->settings['perm'][ $role ]['keys'] ) ) {
				$hidden = array_merge( $hidden, (array) $this->settings['perm'][ $role ]['keys'] );
			}
		}
		return array_values( array_unique( array_map( 'strval', $hidden ) ) );
	}

	/* =====================================================================
	 * Hiding menus
	 * =================================================================== */

	public function apply_hiding() {
		global $menu, $submenu;
		$this->allowed = array();
		$this->denied  = array();

		$user = wp_get_current_user();
		if ( ! $user->exists() || $this->is_main_admin( $user ) ) {
			return;
		}
		$is_sub             = $this->is_sub_admin( $user );
		$hidden              = $is_sub ? array() : $this->hidden_keys_for( $user );
		$has_valid_landing   = $is_sub && '' !== $this->landing_url( $user );
		if ( ! $is_sub && empty( $hidden ) ) {
			return;
		}

		foreach ( (array) $menu as $item ) {
			if ( empty( $item[2] ) || ( isset( $item[4] ) && false !== strpos( $item[4], 'wp-menu-separator' ) ) ) {
				continue;
			}
			$top      = (string) $item[2];
			$top_ok   = $is_sub ? $this->sub_admin_allows( $top ) : ! in_array( $top, $hidden, true );
			if ( $has_valid_landing && 'index.php' === $top ) {
				// Once a Sub-Admin has an explicit landing module, keep the
				// generic WordPress Dashboard out of the menu. Direct visits are
				// still redirected by deny_request()/redirect_dashboard().
				$top_ok = false;
			}
			$children = isset( $submenu[ $top ] ) ? (array) $submenu[ $top ] : array();
			$kept     = 0;
			$shares   = false;

			foreach ( $children as $sub ) {
				if ( empty( $sub[2] ) ) {
					continue;
				}
				$child = (string) $sub[2];
				if ( $child === $top ) {
					$shares = true;
				}
				$ckey = $top . self::SEP . $child;
				$ok   = $top_ok && ( $is_sub ? $this->sub_admin_allows( $ckey ) : ! in_array( $ckey, $hidden, true ) );
				if ( $ok ) {
					$kept++;
					$this->allowed[] = $child;
				} else {
					$this->denied[] = $child;
					if ( $top_ok ) {
						remove_submenu_page( $top, $child );
					}
				}
			}

			if ( $top_ok && $children && 0 === $kept ) {
				$top_ok = false;
			}
			if ( ! $shares ) {
				if ( $top_ok ) {
					$this->allowed[] = $top;
				} else {
					$this->denied[] = $top;
				}
			}
			if ( ! $top_ok ) {
				remove_menu_page( $top );
			}
		}

		$this->clean_separators();
		$this->first_url = $this->compute_first_url();
	}

	private function clean_separators() {
		global $menu;
		uksort( $menu, 'strnatcasecmp' );
		$prev_sep = true; // Also removes a leading separator.
		$last_sep = null;
		foreach ( $menu as $k => $item ) {
			$is_sep = isset( $item[4] ) && false !== strpos( $item[4], 'wp-menu-separator' );
			if ( $is_sep ) {
				if ( $prev_sep ) {
					unset( $menu[ $k ] );
				} else {
					$prev_sep = true;
					$last_sep = $k;
				}
			} else {
				$prev_sep = false;
			}
		}
		if ( $prev_sep && null !== $last_sep && isset( $menu[ $last_sep ] ) ) {
			unset( $menu[ $last_sep ] ); // Trailing separator.
		}
	}

	private function compute_first_url() {
		global $menu, $submenu;
		$m = (array) $menu;
		uksort( $m, 'strnatcasecmp' );
		foreach ( $m as $item ) {
			if ( empty( $item[2] ) || ( isset( $item[4] ) && false !== strpos( $item[4], 'wp-menu-separator' ) ) ) {
				continue;
			}
			$top  = (string) $item[2];
			$subs = isset( $submenu[ $top ] ) ? array_values( (array) $submenu[ $top ] ) : array();
			if ( $subs && ! empty( $subs[0][2] ) ) {
				return $this->menu_url( $top, (string) $subs[0][2] );
			}
			return $this->menu_url( '', $top );
		}
		return '';
	}

	/* =====================================================================
	 * URL helpers and request matching
	 * =================================================================== */

	private function is_file_slug( $slug ) {
		static $cache = array();
		if ( ! isset( $cache[ $slug ] ) ) {
			$path           = (string) strtok( $slug, '?' );
			$cache[ $slug ] = ( false !== strpos( $path, '.php' ) ) && file_exists( ABSPATH . 'wp-admin/' . $path );
		}
		return $cache[ $slug ];
	}

	private function menu_url( $parent, $slug ) {
		if ( preg_match( '#^https?://#i', $slug ) ) {
			return $slug;
		}
		if ( $this->is_file_slug( $slug ) ) {
			return admin_url( $slug );
		}
		if ( $parent && $this->is_file_slug( $parent ) && 'admin.php' !== strtok( $parent, '?' ) ) {
			return admin_url( $parent . ( false === strpos( $parent, '?' ) ? '?' : '&' ) . 'page=' . $slug );
		}
		return admin_url( 'admin.php?page=' . $slug );
	}

	private function request_params() {
		$out = array();
		foreach ( $_GET as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification
			if ( is_scalar( $v ) ) {
				$out[ (string) $k ] = sanitize_text_field( wp_unslash( (string) $v ) );
			}
		}
		return $out;
	}

	/** The current request, plus the "parent" screens it belongs to (editing a post belongs to its Posts/Pages/Products menu, etc.). */
	private function virtual_requests() {
		global $pagenow;
		$p    = $this->request_params();
		$reqs = array( array( $pagenow, $p ) );

		switch ( $pagenow ) {
			case 'term.php':
				$reqs[] = array( 'edit-tags.php', $p );
				break;
			case 'post.php':
			case 'media.php':
				$id = 0;
				if ( isset( $p['post'] ) ) {
					$id = (int) $p['post'];
				} elseif ( isset( $p['attachment_id'] ) ) {
					$id = (int) $p['attachment_id'];
				} elseif ( isset( $_POST['post_ID'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
					$id = (int) $_POST['post_ID']; // phpcs:ignore WordPress.Security.NonceVerification
				}
				$pt = $id ? get_post_type( $id ) : '';
				if ( 'attachment' === $pt ) {
					$reqs[] = array( 'upload.php', array() );
				} elseif ( $pt ) {
					$reqs[] = array( 'edit.php', 'post' === $pt ? array() : array( 'post_type' => $pt ) );
				}
				break;
			case 'user-edit.php':
				$reqs[] = array( 'users.php', array() );
				break;
			case 'comment.php':
				$reqs[] = array( 'edit-comments.php', array() );
				break;
		}
		return $reqs;
	}

	private function request_matches( $slug, $file, $params ) {
		$args = array();

		if ( $this->is_file_slug( $slug ) ) {
			$path = (string) strtok( $slug, '?' );
			$q    = strpos( $slug, '?' );
			if ( false !== $q ) {
				parse_str( substr( $slug, $q + 1 ), $args );
			}
			if ( $path !== $file ) {
				return false;
			}
			foreach ( $args as $k => $v ) {
				if ( ! is_scalar( $v ) ) {
					continue;
				}
				if ( ! isset( $params[ $k ] ) || $params[ $k ] !== (string) $v ) {
					return false;
				}
			}
			if ( in_array( $path, array( 'edit.php', 'post-new.php' ), true ) && ! isset( $args['post_type'] ) ) {
				$pt = isset( $params['post_type'] ) ? $params['post_type'] : 'post';
				if ( 'post' !== $pt ) {
					return false;
				}
			}
			return true;
		}

		// Plugin pages: "my-page" or "wc-admin&path=/customers".
		$page = $slug;
		$amp  = strpos( $slug, '&' );
		if ( false !== $amp ) {
			$page = substr( $slug, 0, $amp );
			parse_str( substr( $slug, $amp + 1 ), $args );
		}
		if ( ! isset( $params['page'] ) || $params['page'] !== $page ) {
			return false;
		}
		foreach ( $args as $k => $v ) {
			if ( ! is_scalar( $v ) ) {
				continue;
			}
			if ( ! isset( $params[ $k ] ) || $params[ $k ] !== (string) $v ) {
				return false;
			}
		}
		return true;
	}

	private function match_slugs( array $slugs, array $reqs ) {
		foreach ( array_unique( $slugs ) as $slug ) {
			foreach ( $reqs as $req ) {
				if ( $this->request_matches( (string) $slug, $req[0], $req[1] ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/* =====================================================================
	 * Blocking hidden pages by URL
	 * =================================================================== */

	public function enforce_access() {
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		$user = wp_get_current_user();
		if ( ! $user->exists() || $this->is_main_admin( $user ) ) {
			return;
		}

		// options.php is handled after admin_menu so its submitted settings group
		// can be checked against the same live permission matrix as normal screens.
	}

	/**
	 * Enforce menu permissions after all admin_menu callbacks have populated and
	 * this plugin has removed forbidden entries. This is intentionally later than
	 * admin_init: the previous build checked $this->denied too early, when it was
	 * still empty, making direct URL access bypass the permission matrix.
	 */
	public function enforce_menu_access() {
		global $pagenow;
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		$user = wp_get_current_user();
		if ( ! $user->exists() || $this->is_main_admin( $user ) ) {
			return;
		}
		if ( empty( $this->settings['enforce'] ) ) {
			return;
		}
		if ( in_array( $pagenow, array( 'admin-post.php', 'admin-ajax.php', 'async-upload.php', 'load-scripts.php', 'load-styles.php' ), true ) ) {
			return;
		}

		if ( 'options.php' === $pagenow && $this->is_sub_admin( $user ) ) {
			$this->guard_options_screen();
		}

		$reqs = $this->virtual_requests();
		if ( $this->match_slugs( $this->denied, $reqs ) && ! $this->match_slugs( $this->allowed, $reqs ) ) {
			$this->deny_request( $user );
		}

		// Generic admin.php without a page is an internal dispatcher, not a user
		// destination. Do not expose it as a back-door route to the WP dashboard.
		if ( $this->is_sub_admin( $user ) && 'admin.php' === $pagenow && empty( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$landing = $this->landing_url( $user );
			if ( $landing ) {
				wp_safe_redirect( $landing );
				exit;
			}
			wp_die( 'You do not have permission to access this page.', 'Access denied', array( 'response' => 403, 'back_link' => true ) );
		}
	}

	/**
	 * Protect the special options.php endpoint without breaking legitimate Settings API forms.
	 * WordPress uses options.php as the POST target for both core and third-party settings pages.
	 */
	private function guard_options_screen() {
		global $pagenow;
		if ( 'options.php' !== $pagenow || ! $this->is_sub_admin() ) {
			return;
		}

		$group = ( isset( $_POST['option_page'] ) && is_string( $_POST['option_page'] ) ) ? sanitize_key( wp_unslash( $_POST['option_page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$map   = array(
			'general'    => 'options-general.php',
			'writing'    => 'options-writing.php',
			'reading'    => 'options-reading.php',
			'discussion' => 'options-discussion.php',
			'media'      => 'options-media.php',
		);

		// Unregistered core options are never permitted through a Sub-Admin route.
		if ( '' === $group || 'options' === $group ) {
			wp_die( 'You do not have permission to change these settings.', 'Access denied', array( 'response' => 403, 'back_link' => true ) );
		}

		// Core settings groups map cleanly to their WordPress settings screen.
		if ( isset( $map[ $group ] ) ) {
			if ( ! in_array( $map[ $group ], $this->allowed, true ) ) {
				wp_die( 'You do not have permission to change these settings.', 'Access denied', array( 'response' => 403, 'back_link' => true ) );
			}
			return;
		}

		// Third-party Settings API groups are allowed only when the originating admin
		// screen was itself granted by the matrix. The core options.php capability/nonce
		// checks still apply after this guard. settings_fields() supplies this referer.
		$referer = isset( $_POST['_wp_http_referer'] ) && is_string( $_POST['_wp_http_referer'] ) ? wp_unslash( $_POST['_wp_http_referer'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$req     = $this->request_from_admin_referer( $referer );
		if ( ! $req || ! $this->match_slugs( $this->allowed, array( $req ) ) || $this->match_slugs( $this->denied, array( $req ) ) ) {
			wp_die( 'You do not have permission to change these settings.', 'Access denied', array( 'response' => 403, 'back_link' => true ) );
		}
	}

	/** Convert a local wp-admin referer into the same request tuple used by the access matcher. */
	private function request_from_admin_referer( $referer ) {
		$referer = trim( (string) $referer );
		if ( '' === $referer ) {
			return null;
		}

		$parts = wp_parse_url( $referer );
		if ( false === $parts ) {
			return null;
		}
		$admin_url_parts = wp_parse_url( admin_url() );
		$home_url_parts  = wp_parse_url( home_url( '/' ) );
		$referer_host     = isset( $parts['host'] ) ? strtolower( (string) $parts['host'] ) : '';
		$admin_host       = isset( $admin_url_parts['host'] ) ? strtolower( (string) $admin_url_parts['host'] ) : '';
		if ( '' === $admin_host && isset( $home_url_parts['host'] ) ) {
			$admin_host = strtolower( (string) $home_url_parts['host'] );
		}
		$referer_port     = isset( $parts['port'] ) ? (int) $parts['port'] : 0;
		$admin_port       = isset( $admin_url_parts['port'] ) ? (int) $admin_url_parts['port'] : 0;
		if ( '' === $referer_host || '' === $admin_host || $referer_host !== $admin_host || $referer_port !== $admin_port ) {
			return null;
		}

		$path       = isset( $parts['path'] ) ? (string) $parts['path'] : '';
		$admin_path = isset( $admin_url_parts['path'] ) ? (string) $admin_url_parts['path'] : '';
		$admin_path = '/' . trim( (string) $admin_path, '/' );
		$path       = '/' . ltrim( $path, '/' );
		if ( '/' === $admin_path || 0 !== strpos( $path, $admin_path . '/' ) ) {
			return null;
		}

		$file   = ltrim( substr( $path, strlen( $admin_path ) ), '/' );
		$params = array();
		$query  = isset( $parts['query'] ) ? (string) $parts['query'] : '';
		if ( '' !== $query ) {
			parse_str( $query, $raw );
			foreach ( (array) $raw as $key => $value ) {
				if ( is_scalar( $value ) ) {
					$params[ (string) $key ] = sanitize_text_field( (string) $value );
				}
			}
		}
		return array( $file, $params );
	}

	private function deny_request( $user ) {
		global $pagenow;
		if ( 'index.php' === $pagenow ) {
			$to = $this->landing_url( $user );
			if ( ! $to ) {
				$to = $this->first_url;
			}
			if ( $to && admin_url( 'index.php' ) !== $to ) {
				wp_safe_redirect( $to );
				exit;
			}
		}
		wp_die( 'You do not have permission to access this page.', 'Access denied', array( 'response' => 403, 'back_link' => true ) );
	}

	/* =====================================================================
	 * Landing module
	 * =================================================================== */

	private function snapshot_has_key( $key ) {
		return in_array( $key, $this->all_keys(), true );
	}

	private function landing_url( $user ) {
		$key = (string) get_user_meta( $user->ID, self::META_LANDING, true );
		if ( '' === $key ) {
			return '';
		}
		$snap = $this->get_snapshot();
		if ( false !== strpos( $key, self::SEP ) ) {
			list( $parent, $child ) = explode( self::SEP, $key, 2 );
			if ( ! isset( $snap[ $parent ]['children'][ $child ] ) ) {
				return '';
			}
			return $this->menu_url( $parent, $child );
		}
		if ( ! isset( $snap[ $key ] ) ) {
			return '';
		}
		$kids = array_keys( (array) $snap[ $key ]['children'] );
		if ( $kids ) {
			return $this->menu_url( $key, (string) $kids[0] );
		}
		return $this->menu_url( '', $key );
	}

	private function landing_label( $key ) {
		$snap = $this->get_snapshot();
		if ( false !== strpos( (string) $key, self::SEP ) ) {
			list( $parent, $child ) = explode( self::SEP, $key, 2 );
			if ( isset( $snap[ $parent ]['children'][ $child ] ) ) {
				return $snap[ $parent ]['title'] . ' › ' . $snap[ $parent ]['children'][ $child ];
			}
		} elseif ( isset( $snap[ $key ] ) ) {
			return $snap[ $key ]['title'];
		}
		return '';
	}

	public function filter_login_redirect( $redirect_to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User ) || ! $this->is_sub_admin( $user ) ) {
			return $redirect_to;
		}
		$url = $this->landing_url( $user );
		if ( ! $url ) {
			return $redirect_to;
		}
		$default = untrailingslashit( admin_url() );
		if ( '' === (string) $requested || untrailingslashit( (string) $requested ) === $default || untrailingslashit( (string) $redirect_to ) === $default ) {
			return $url;
		}
		return $redirect_to;
	}

	public function redirect_dashboard() {
		$user = wp_get_current_user();
		if ( ! $this->is_sub_admin( $user ) ) {
			return;
		}
		$url = $this->landing_url( $user );
		if ( ! $url || admin_url( 'index.php' ) === $url ) {
			return;
		}
		wp_safe_redirect( $url );
		exit;
	}

	private function ensure_allowed_for_sub_admin( $key ) {
		$cur = array();
		foreach ( $this->all_keys() as $k ) {
			if ( $this->sub_admin_allows( $k ) ) {
				$cur[] = $k;
			}
		}
		if ( in_array( $key, $cur, true ) ) {
			return;
		}
		$cur[] = $key;
		$this->settings['perm'][ self::ROLE ] = array(
			'mode' => 'allow',
			'keys' => $this->normalize_visible( $cur ),
		);
		$this->persist();
		set_transient( 'wpsa_notice_' . get_current_user_id(), 'The chosen landing module was added to the Sub-Admin menu permissions so it can be opened.', 60 );
	}

	/* ---- landing field on user-new.php / user-edit.php ---- */

	public function render_landing_field_new( $type = '' ) {
		if ( $this->is_main_admin() ) {
			$this->print_landing_field( '', true );
		}
	}

	public function render_landing_field_edit( $profile_user ) {
		if ( $this->is_main_admin() && $profile_user instanceof WP_User ) {
			$this->print_landing_field( (string) get_user_meta( $profile_user->ID, self::META_LANDING, true ), false );
		}
	}

	private function print_landing_field( $selected, $is_new ) {
		$snap = $this->get_snapshot();
		wp_nonce_field( 'wpsa_user_fields', 'wpsa_user_nonce', false );
		?>
		<table class="form-table" role="presentation" id="wpsa-landing-row" style="display:none">
			<tr>
				<th scope="row"><label for="wpsa_landing">Sub-Admin Landing Module</label></th>
				<td>
					<select name="wpsa_landing" id="wpsa_landing">
						<option value="">&mdash; WordPress Dashboard (default) &mdash;</option>
						<?php
						foreach ( $snap as $top => $row ) {
							$top = (string) $top;
							if ( ! empty( $row['children'] ) ) {
								echo '<optgroup label="' . esc_attr( $row['title'] ) . '">';
								foreach ( $row['children'] as $cs => $ct ) {
									$k = $top . self::SEP . $cs;
									printf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $selected, $k, false ), esc_html( $ct ) );
								}
								echo '</optgroup>';
							} else {
								printf( '<option value="%s"%s>%s</option>', esc_attr( $top ), selected( $selected, $top, false ), esc_html( $row['title'] ) );
							}
						}
						?>
					</select>
					<p class="description">The page this Sub-Admin lands on after login and whenever they open the Dashboard (for example a plugin's own dashboard).</p>
				</td>
			</tr>
		</table>
		<script>
		(function () {
			var isNew = <?php echo $is_new ? 'true' : 'false'; ?>;
			var row = document.getElementById('wpsa-landing-row');
			var role = document.getElementById('role');
			if (!row) { return; }
			if (!role) { row.style.display = ''; return; }
			function sync() { row.style.display = (role.value === 'sub_admin') ? '' : 'none'; }
			role.addEventListener('change', sync);
			if (isNew && /[?&]wpsa_new=1/.test(window.location.search)) { role.value = 'sub_admin'; }
			sync();
		})();
		</script>
		<?php
	}

	private function save_landing( $user_id ) {
		if ( ! $this->is_main_admin() ) {
			return;
		}
		if ( ! isset( $_POST['wpsa_user_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wpsa_user_nonce'] ) ), 'wpsa_user_fields' ) ) {
			return;
		}
		$key = isset( $_POST['wpsa_landing'] ) && is_string( $_POST['wpsa_landing'] ) ? wp_unslash( $_POST['wpsa_landing'] ) : '';
		if ( '' === $key || ! $this->snapshot_has_key( $key ) ) {
			delete_user_meta( $user_id, self::META_LANDING );
			return;
		}
		update_user_meta( $user_id, self::META_LANDING, $key );
		$this->ensure_allowed_for_sub_admin( $key );
	}

	public function save_landing_new( $user_id ) {
		$this->save_landing( $user_id );
	}

	public function save_landing_edit( $user_id ) {
		$this->save_landing( $user_id );
	}

	/* =====================================================================
	 * Custom menu links
	 * =================================================================== */

	private function resolve_link_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( preg_match( '#^(https?:)?//#i', $url ) || 0 === strpos( $url, 'mailto:' ) || 0 === strpos( $url, 'tel:' ) ) {
			$out = $url;
		} elseif ( '/' === $url[0] ) {
			$out = home_url( $url );
		} elseif ( '#' === $url[0] ) {
			$out = $url;
		} else {
			$out = admin_url( $url );
		}
		return esc_url( $out );
	}

	public function add_custom_links() {
		global $menu, $submenu;
		$user = wp_get_current_user();
		if ( ! $user->exists() ) {
			return;
		}
		$roles = (array) $user->roles;
		$top_i = 0;
		$bot_i = 0;

		foreach ( (array) $this->settings['links'] as $link ) {
			if ( empty( $link['title'] ) || empty( $link['url'] ) ) {
				continue;
			}
			$link_roles = isset( $link['roles'] ) ? (array) $link['roles'] : array();
			if ( ! array_intersect( $roles, $link_roles ) ) {
				continue;
			}
			$url = $this->resolve_link_url( $link['url'] );
			if ( '' === $url ) {
				continue;
			}
			$title = esc_html( $link['title'] );

			if ( ! empty( $link['target'] ) ) {
				$this->new_tab_urls[] = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
			}

			if ( ! empty( $link['parent'] ) ) {
				$parent     = (string) $link['parent'];
				$parent_there = false;
				foreach ( (array) $menu as $item ) {
					if ( isset( $item[2] ) && (string) $item[2] === $parent ) {
						$parent_there = true;
						break;
					}
				}
				if ( $parent_there && isset( $submenu[ $parent ] ) ) {
					$submenu[ $parent ][] = array( $title, 'read', $url );
				}
				continue;
			}

			$icon = ( isset( $link['icon'] ) && preg_match( '/^dashicons-[a-z0-9-]+$/', $link['icon'] ) ) ? $link['icon'] : 'dashicons-admin-links';
			if ( isset( $link['placement'] ) && 'bottom' === $link['placement'] ) {
				$pos = sprintf( '%.2f', 1000 + ( $bot_i++ ) / 100 );
			} else {
				$pos = sprintf( '%.2f', 3 + ( $top_i++ ) / 100 );
			}
			$id = 'wpsa-link-' . sanitize_key( isset( $link['id'] ) ? $link['id'] : $pos );
			$menu[ $pos ] = array( $title, 'read', $url, '', 'menu-top wpsa-custom-link', $id, $icon );
		}

		// Log Out link, since the admin bar (and its Log Out) is hidden for these users.
		if ( ! empty( $this->settings['add_logout'] ) && ! empty( $this->settings['hide_bar'] ) && $this->is_below_line( $user ) ) {
			$menu['9999'] = array( 'Log Out', 'read', esc_url( wp_logout_url() ), '', 'menu-top wpsa-logout', 'wpsa-logout', 'dashicons-exit' );
		}

		uksort( $menu, 'strnatcasecmp' );
	}

	public function footer_script() {
		if ( empty( $this->new_tab_urls ) ) {
			return;
		}
		?>
		<script>
		(function () {
			var urls = <?php echo wp_json_encode( array_values( array_unique( $this->new_tab_urls ) ) ); ?>;
			var abs = urls.map(function (u) { try { return new URL(u, window.location.href).href; } catch (e) { return u; } });
			document.querySelectorAll('#adminmenu a').forEach(function (a) {
				if (abs.indexOf(a.href) > -1) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
			});
		})();
		</script>
		<?php
	}

	/* =====================================================================
	 * Login branding
	 * =================================================================== */

	private function login_branding_enabled() {
		return ! empty( $this->settings['login_branding'] );
	}

	/**
	 * Neutral accessible label for the login logo link.
	 * Visible brand/site-name text is intentionally not rendered by the plugin.
	 */
	private function login_accessible_label() {
		return 'Login';
	}

	private function login_logo_url() {
		$logo_id = isset( $this->settings['login_logo_id'] ) ? absint( $this->settings['login_logo_id'] ) : 0;
		if ( $logo_id ) {
			$url = wp_get_attachment_image_url( $logo_id, 'full' );
			if ( $url ) {
				return $url;
			}
		}

		if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) {
			$theme_logo = absint( get_theme_mod( 'custom_logo' ) );
			if ( $theme_logo ) {
				$url = wp_get_attachment_image_url( $theme_logo, 'full' );
				if ( $url ) {
					return $url;
				}
			}
		}

		if ( function_exists( 'get_site_icon_url' ) ) {
			$icon = get_site_icon_url( 512 );
			if ( $icon ) {
				return $icon;
			}
		}

		return '';
	}

	public function login_header_url( $url ) {
		return home_url( '/' );
	}

	public function login_header_text( $text ) {
		if ( ! $this->login_branding_enabled() ) {
			return $text;
		}
		return $this->login_accessible_label();
	}

	public function login_title( $login_title, $title = '' ) {
		if ( ! $this->login_branding_enabled() ) {
			return $login_title;
		}
		$screen = trim( wp_strip_all_tags( (string) $title ) );
		if ( '' === $screen ) {
			$screen = 'Log In';
		}
		return $screen;
	}

	/** Replace WordPress's site-title footer text with neutral wording on the branded login. */
	public function login_site_html_link( $link ) {
		if ( ! $this->login_branding_enabled() ) {
			return $link;
		}
		return '<a href="' . esc_url( home_url( '/' ) ) . '">&larr; Back to website</a>';
	}

	public function login_body_class( $classes, $action ) {
		if ( $this->login_branding_enabled() ) {
			$classes[] = 'wpsa-login-branded';
			$classes[] = 'wpsa-login-' . sanitize_html_class( $action );
		}
		return array_values( array_unique( $classes ) );
	}

	public function login_enqueue_styles() {
		if ( ! $this->login_branding_enabled() ) {
			return;
		}
		$logo = $this->login_logo_url();
		$css = <<<CSS
		html,body.login{background:#f4f6f8;}
		body.login{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box;}
		body.login #login{width:100%;max-width:430px;padding:30px;margin:0;background:#fff;border:1px solid #dfe3e8;border-radius:14px;box-shadow:0 16px 45px rgba(23,36,50,.10);box-sizing:border-box;}
		body.login #login h1{margin:0 0 18px;text-align:center;}
		body.login #login h1 a{width:240px;height:78px;background-size:contain;background-position:center;background-repeat:no-repeat;margin:0 auto;display:block;text-indent:-9999px !important;overflow:hidden !important;color:transparent !important;}
		body.login #loginform,body.login #lostpasswordform,body.login #registerform,body.login #resetpassform{margin:0;padding:0;border:0;background:transparent;box-shadow:none;}
		body.login #login label{color:#26313b;font-weight:600;}
		body.login #login input[type=text],body.login #login input[type=password],body.login #login input[type=email]{border:1px solid #cfd6dd;border-radius:8px;box-shadow:none;padding:10px 12px;min-height:44px;box-sizing:border-box;}
		body.login #login input[type=text]:focus,body.login #login input[type=password]:focus,body.login #login input[type=email]:focus{border-color:#3b82f6;box-shadow:0 0 0 1px #3b82f6;outline:0;}
		body.login #login .button.wp-hide-pw{height:44px;}
		body.login #login .button-primary{width:100%;min-height:44px;border:0;border-radius:8px;box-shadow:none;font-weight:600;padding:0 16px;}
		body.login #login .forgetmenot{margin:4px 0 14px;}
		body.login #login #nav,body.login #login #backtoblog{padding:0;text-align:center;}
		body.login #login #nav{margin:18px 0 0;}
		body.login #login #backtoblog{margin:10px 0 0;}
		body.login #login #nav a,body.login #login #backtoblog a{color:#4f5d6a;text-decoration:none;}
		body.login #login #nav a:hover,body.login #login #backtoblog a:hover{text-decoration:underline;}
		body.login .message,body.login #login_error{border-radius:9px;margin:0 0 16px;padding:12px 14px;box-shadow:none;}
		body.login .privacy-policy-page-link{margin-top:14px;}
		@media(max-width:480px){body.login{padding:18px;}body.login #login{padding:24px 20px 22px;}body.login #login h1 a{width:210px;height:68px;}}
		CSS;
		if ( $logo ) {
			$css .= '#login h1 a{background-image:url(' . wp_json_encode( $logo ) . ') !important;}';
		} else {
			$css .= '#login h1 a{display:none !important;}';
		}
		wp_add_inline_style( 'login', $css );
	}

	/* =====================================================================
	 * Admin assets
	 * =================================================================== */

	public function enqueue_admin_assets( $hook ) {
		if ( 'toplevel_page_' . self::PAGE !== $hook || ! $this->is_main_admin() ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script(
			'wpsa-admin-media',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin-media.js',
			array( 'media-editor', 'media-views' ),
			'1.1.3',
			true
		);
	}

	/* =====================================================================
	 * Notices and activation redirect
	 * =================================================================== */

	public function admin_notices() {
		if ( ! $this->is_main_admin() ) {
			return;
		}
		$key = 'wpsa_notice_' . get_current_user_id();
		$msg = get_transient( $key );
		if ( $msg ) {
			delete_transient( $key );
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
	}

	public function maybe_redirect_after_activation() {
		if ( ! get_transient( 'wpsa_activated' ) || wp_doing_ajax() || ! $this->is_main_admin() ) {
			return;
		}
		delete_transient( 'wpsa_activated' );
		if ( isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
		exit;
	}

	/* =====================================================================
	 * Admin page (main administrator only)
	 * =================================================================== */

	public function register_admin_page() {
		if ( ! $this->is_main_admin() ) {
			return;
		}
		add_menu_page( 'Sub-Admin Manager', 'Sub-Admin Manager', 'manage_options', self::PAGE, array( $this, 'render_page' ), 'dashicons-shield', 71 );
	}

	private function matrix_roles() {
		$names = wp_roles()->get_names();
		unset( $names['administrator'] );
		$out = array();
		if ( isset( $names[ self::ROLE ] ) ) {
			$out[ self::ROLE ] = $names[ self::ROLE ];
			unset( $names[ self::ROLE ] );
		}
		return $out + $names;
	}

	public function render_page() {
		if ( ! $this->is_main_admin() ) {
			wp_die( 'Only the main administrator can open this page.', '', array( 'response' => 403 ) );
		}
		$tabs = array(
			'permissions' => 'Menu Permissions',
			'links'       => 'Custom Menu Links',
			'subadmins'   => 'Sub-Admins',
			'settings'    => 'Settings',
		);
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'permissions'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'permissions';
		}

		echo '<div class="wrap"><div class="wpsa-page-heading"><h1>Sub-Admin Manager</h1><span>Developed by <a href="https://digitalbe.in" target="_blank" rel="noopener noreferrer">Digital BE</a></span></div>';
		if ( isset( $_GET['wpsa_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$m = sanitize_key( wp_unslash( $_GET['wpsa_msg'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			if ( 'saved' === $m ) {
				echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
			} elseif ( 'reset' === $m ) {
				echo '<div class="notice notice-success is-dismissible"><p>Menu permissions were reset to defaults.</p></div>';
			}
		}
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $slug => $label ) {
			printf(
				'<a href="%s" class="nav-tab%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::PAGE . '&tab=' . $slug ) ),
				$tab === $slug ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</h2>';
		$this->print_styles();
		call_user_func( array( $this, 'render_tab_' . $tab ) );
		echo '</div>';
	}

	private function print_styles() {
		?>
		<style>
			.wpsa-card{background:#fff;border:1px solid #c3c4c7;padding:12px 16px;max-width:1100px;margin:12px 0}
			.wpsa-matrix{max-width:1100px}
			.wpsa-matrix th,.wpsa-matrix td{vertical-align:middle}
			.wpsa-matrix thead th{position:sticky;top:32px;background:#fff;z-index:2}
			.wpsa-matrix .c{text-align:center}
			.wpsa-matrix tr.wpsa-top td{font-weight:600;background:#f6f7f7}
			.wpsa-matrix tr.wpsa-child td:first-child{padding-left:42px;color:#50575e}
			.wpsa-toggle{cursor:pointer;border:0;background:none;padding:0 8px 0 0;font-size:13px;width:22px}
			.wpsa-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:10px 0}
			.wpsa-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
			.wpsa-grid label{font-weight:600;display:block}
			.wpsa-roles label{display:inline-block;margin-right:14px;font-weight:400}
			.wpsa-page-heading{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
			.wpsa-page-heading h1{margin-bottom:0}
			.wpsa-page-heading>span{font-size:12px;color:#646970}
			.wpsa-login-logo-preview{display:block;max-width:220px;max-height:90px;object-fit:contain;background:#f6f7f7;border:1px solid #dcdcde;border-radius:8px;padding:10px;margin:0 0 10px}
		</style>
		<?php
	}

	/* ---- Tab: permissions ---- */

	private function render_tab_permissions() {
		$snap  = $this->get_snapshot();
		$roles = $this->matrix_roles();
		?>
		<div class="wpsa-card">
			<p><strong>Sub-Admin column:</strong> tick the modules and sub-items the Sub-Admin should <em>see and be able to open</em>. Anything unticked (including menus added by plugins you install later) is hidden and blocked.<br>
			<strong>Other role columns:</strong> everything is visible by default; <em>untick</em> an item to hide it from that role. Roles can still only use what their own WordPress capabilities allow.</p>
			<p class="description">Administrators always see everything. Ticking a sub-item also ticks its parent; unticking a parent unticks its sub-items.</p>
		</div>

		<?php if ( empty( $snap ) ) : ?>
			<div class="notice notice-warning inline"><p>The menu list is not ready yet. Reload this page once.</p></div>
			<?php return; ?>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wpsa-perm-form">
			<input type="hidden" name="action" value="wpsa_save_permissions">
			<?php wp_nonce_field( 'wpsa_perm' ); ?>
			<input type="hidden" name="wpsa_all_json" id="wpsa-all-json" value="">
			<input type="hidden" name="wpsa_vis_json" id="wpsa-vis-json" value="">

			<div class="wpsa-tools">
				<input type="search" id="wpsa-search" placeholder="Filter menu items…" class="regular-text">
				<button type="button" class="button" id="wpsa-expand">Expand all</button>
				<button type="button" class="button" id="wpsa-collapse">Collapse all</button>
			</div>

			<table class="widefat wpsa-matrix" id="wpsa-matrix">
				<thead>
					<tr>
						<th style="width:34%">Menu item</th>
						<?php foreach ( $roles as $slug => $name ) : ?>
							<th class="c">
								<?php echo esc_html( translate_user_role( $name ) ); ?><br>
								<label style="font-weight:400"><input type="checkbox" class="wpsa-col" data-role="<?php echo esc_attr( $slug ); ?>"> all</label>
							</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
				<?php
				$g = 0;
				foreach ( $snap as $top => $row ) {
					$top = (string) $top;
					$g++;
					$this->matrix_row( $top, $row['title'], $roles, 'top', $g, ! empty( $row['children'] ) );
					foreach ( $row['children'] as $cs => $ct ) {
						$this->matrix_row( $top . self::SEP . $cs, $ct, $roles, 'child', $g, false );
					}
				}
				?>
				</tbody>
			</table>

			<p>
				<?php submit_button( 'Save permissions', 'primary', 'submit', false ); ?>
				<?php submit_button( 'Reset to defaults', 'secondary', 'wpsa_reset', false, array( 'onclick' => "return confirm('Reset all menu permissions to defaults?');" ) ); ?>
			</p>
		</form>

		<script>
		(function () {
			var form = document.getElementById('wpsa-perm-form');
			var table = document.getElementById('wpsa-matrix');
			if (!form || !table) { return; }

			function cbs() { return [].slice.call(table.querySelectorAll('input.wpsa-cb')); }
			function forRole(role) { return cbs().filter(function (c) { return c.getAttribute('data-role') === role; }); }

			table.addEventListener('change', function (e) {
				var c = e.target;
				if (!c || c.type !== 'checkbox') { return; }
				if (c.classList.contains('wpsa-col')) {
					forRole(c.getAttribute('data-role')).forEach(function (x) { x.checked = c.checked; });
					return;
				}
				var tr = c.closest('tr'), g = tr.getAttribute('data-group'), role = c.getAttribute('data-role');
				var sameGroup = forRole(role).filter(function (x) { return x.closest('tr').getAttribute('data-group') === g; });
				if (tr.getAttribute('data-level') === 'top') {
					sameGroup.forEach(function (x) { x.checked = c.checked; });
				} else if (c.checked) {
					sameGroup.forEach(function (x) { if (x.closest('tr').getAttribute('data-level') === 'top') { x.checked = true; } });
				}
			});

			// Expand / collapse + filter.
			var groups = {}, q = '';
			[].slice.call(table.querySelectorAll('tbody tr')).forEach(function (tr) {
				var g = tr.getAttribute('data-group');
				groups[g] = groups[g] || { top: null, kids: [], collapsed: false };
				if (tr.getAttribute('data-level') === 'top') { groups[g].top = tr; } else { groups[g].kids.push(tr); }
			});
			function hit(tr) { return tr.textContent.toLowerCase().indexOf(q) > -1; }
			function render() {
				Object.keys(groups).forEach(function (g) {
					var G = groups[g], topHit = !q || hit(G.top), anyKid = false;
					G.kids.forEach(function (k) { if (q && hit(k)) { anyKid = true; } });
					var showGroup = !q || topHit || anyKid;
					G.top.style.display = showGroup ? '' : 'none';
					var btn = G.top.querySelector('.wpsa-toggle');
					if (btn) { btn.textContent = G.collapsed ? '▸' : '▾'; }
					G.kids.forEach(function (k) {
						var show = showGroup && (q ? (topHit || hit(k)) : !G.collapsed);
						k.style.display = show ? '' : 'none';
					});
				});
			}
			table.addEventListener('click', function (e) {
				var b = e.target.closest ? e.target.closest('.wpsa-toggle') : null;
				if (!b) { return; }
				var g = b.closest('tr').getAttribute('data-group');
				groups[g].collapsed = !groups[g].collapsed;
				render();
			});
			document.getElementById('wpsa-search').addEventListener('input', function () { q = this.value.toLowerCase().trim(); render(); });
			document.getElementById('wpsa-expand').addEventListener('click', function () { Object.keys(groups).forEach(function (g) { groups[g].collapsed = false; }); render(); });
			document.getElementById('wpsa-collapse').addEventListener('click', function () { Object.keys(groups).forEach(function (g) { groups[g].collapsed = true; }); render(); });
			render();

			// Send everything as two JSON fields (avoids PHP's max_input_vars limit on big menus).
			form.addEventListener('submit', function () {
				var all = [], vis = {};
				table.querySelectorAll('tbody tr').forEach(function (tr) {
					var cb = tr.querySelector('input.wpsa-cb');
					if (cb) { all.push(cb.getAttribute('data-key')); }
				});
				cbs().forEach(function (cb) {
					var r = cb.getAttribute('data-role');
					vis[r] = vis[r] || [];
					if (cb.checked) { vis[r].push(cb.getAttribute('data-key')); }
				});
				document.getElementById('wpsa-all-json').value = JSON.stringify(all);
				document.getElementById('wpsa-vis-json').value = JSON.stringify(vis);
			});
		})();
		</script>
		<?php
	}

	private function matrix_row( $key, $title, $roles, $level, $group, $has_children ) {
		?>
		<tr class="wpsa-row wpsa-<?php echo esc_attr( $level ); ?>" data-group="<?php echo esc_attr( $group ); ?>" data-level="<?php echo esc_attr( $level ); ?>">
			<td>
				<?php if ( 'top' === $level ) : ?>
					<?php if ( $has_children ) : ?>
						<button type="button" class="wpsa-toggle" aria-label="Toggle sub-items">▾</button>
					<?php else : ?>
						<span style="display:inline-block;width:30px"></span>
					<?php endif; ?>
				<?php else : ?>
					&ndash;
				<?php endif; ?>
				<?php echo esc_html( $title ); ?>
			</td>
			<?php foreach ( $roles as $role => $name ) : ?>
				<td class="c">
					<input type="checkbox" class="wpsa-cb"
						data-role="<?php echo esc_attr( $role ); ?>"
						data-key="<?php echo esc_attr( $key ); ?>"
						<?php checked( $this->role_shows( (string) $role, $key ) ); ?>>
				</td>
			<?php endforeach; ?>
		</tr>
		<?php
	}

	/* ---- Tab: custom links ---- */

	private function render_tab_links() {
		$links = array_values( (array) $this->settings['links'] );
		?>
		<div class="wpsa-card">
			<p>Add your own items to the left menu: an internal page, a wp-admin screen (e.g. <code>edit.php?post_type=page</code>) or an external website. Each link is shown only to the roles you tick.</p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpsa_save_links">
			<?php wp_nonce_field( 'wpsa_links' ); ?>
			<datalist id="wpsa-icons">
				<?php
				foreach ( array( 'admin-links', 'external', 'admin-home', 'admin-site', 'admin-page', 'admin-post', 'admin-media', 'admin-users', 'admin-tools', 'admin-generic', 'admin-comments', 'email', 'cart', 'chart-bar', 'chart-line', 'calendar-alt', 'book', 'phone', 'location', 'sos', 'info', 'star-filled', 'heart', 'download', 'welcome-learn-more', 'portfolio' ) as $ic ) {
					echo '<option value="dashicons-' . esc_attr( $ic ) . '">';
				}
				?>
			</datalist>
			<div id="wpsa-links">
				<?php
				foreach ( $links as $i => $link ) {
					$this->render_link_row( $i, (array) $link );
				}
				?>
			</div>
			<p><button type="button" class="button" id="wpsa-add-link">+ Add menu link</button></p>
			<?php submit_button( 'Save links' ); ?>
		</form>

		<template id="wpsa-link-tpl"><?php $this->render_link_row( '__i__', array() ); ?></template>

		<script>
		(function () {
			var wrap = document.getElementById('wpsa-links');
			var tpl = document.getElementById('wpsa-link-tpl');
			var n = 1000;
			document.getElementById('wpsa-add-link').addEventListener('click', function () {
				var d = document.createElement('div');
				d.innerHTML = tpl.innerHTML.replace(/__i__/g, String(n++));
				while (d.firstElementChild) { wrap.appendChild(d.firstElementChild); }
			});
			wrap.addEventListener('click', function (e) {
				if (e.target.classList.contains('wpsa-remove')) {
					var card = e.target.closest('.wpsa-link');
					if (card) { card.remove(); }
				}
			});
			wrap.addEventListener('change', function (e) {
				if (e.target.classList.contains('wpsa-pick') && e.target.value) {
					var card = e.target.closest('.wpsa-link');
					card.querySelector('.wpsa-url').value = e.target.value;
					e.target.value = '';
				}
			});
		})();
		</script>
		<?php
	}

	private function render_link_row( $i, $link ) {
		$link  = wp_parse_args(
			$link,
			array(
				'id'        => '',
				'title'     => '',
				'url'       => '',
				'icon'      => 'dashicons-admin-links',
				'target'    => 0,
				'roles'     => array( self::ROLE ),
				'parent'    => '',
				'placement' => 'top',
			)
		);
		$n     = 'links[' . $i . ']';
		$snap  = $this->get_snapshot();
		$roles = wp_roles()->get_names();
		static $pages = null;
		if ( null === $pages ) {
			$pages = get_pages( array( 'number' => 300, 'sort_column' => 'post_title' ) );
		}
		?>
		<div class="wpsa-card wpsa-link">
			<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $link['id'] ); ?>">
			<div class="wpsa-grid">
				<div>
					<label>Menu title</label>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $n ); ?>[title]" value="<?php echo esc_attr( $link['title'] ); ?>">
				</div>
				<div>
					<label>Link URL</label>
					<input type="text" class="regular-text wpsa-url" name="<?php echo esc_attr( $n ); ?>[url]" value="<?php echo esc_attr( $link['url'] ); ?>" placeholder="https://… or /contact/ or edit.php?post_type=page">
					<select class="wpsa-pick" style="margin-top:4px;max-width:100%">
						<option value="">Pick a site page…</option>
						<?php
						if ( $pages ) {
							foreach ( $pages as $pg ) {
								echo '<option value="' . esc_attr( get_permalink( $pg ) ) . '">' . esc_html( $pg->post_title ) . '</option>';
							}
						}
						?>
					</select>
				</div>
				<div>
					<label>Icon (Dashicon class)</label>
					<input type="text" list="wpsa-icons" name="<?php echo esc_attr( $n ); ?>[icon]" value="<?php echo esc_attr( $link['icon'] ); ?>">
				</div>
				<div>
					<label>Place it</label>
					<select name="<?php echo esc_attr( $n ); ?>[parent]">
						<option value="">As a main menu item</option>
						<?php
						foreach ( $snap as $top => $row ) {
							if ( empty( $row['children'] ) ) {
								continue;
							}
							printf( '<option value="%s"%s>Inside: %s</option>', esc_attr( (string) $top ), selected( $link['parent'], (string) $top, false ), esc_html( $row['title'] ) );
						}
						?>
					</select>
					<select name="<?php echo esc_attr( $n ); ?>[placement]">
						<option value="top" <?php selected( $link['placement'], 'top' ); ?>>Near the top</option>
						<option value="bottom" <?php selected( $link['placement'], 'bottom' ); ?>>At the bottom</option>
					</select>
				</div>
			</div>
			<p>
				<label style="font-weight:600"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[target]" value="1" <?php checked( ! empty( $link['target'] ) ); ?>> Open in a new tab</label>
			</p>
			<p class="wpsa-roles"><strong>Show to:</strong>
				<?php foreach ( $roles as $slug => $name ) : ?>
					<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[roles][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( (string) $slug, array_map( 'strval', (array) $link['roles'] ), true ) ); ?>> <?php echo esc_html( translate_user_role( $name ) ); ?></label>
				<?php endforeach; ?>
			</p>
			<p><button type="button" class="button-link-delete wpsa-remove">Remove this link</button></p>
		</div>
		<?php
	}

	/* ---- Tab: sub-admins ---- */

	private function render_tab_subadmins() {
		$users = get_users( array( 'role' => self::ROLE, 'orderby' => 'display_name' ) );
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'user-new.php?wpsa_new=1' ) ) . '">Add Sub-Admin</a> ';
		echo '<span class="description">Fill in the username, email and password as for any user; the role "Sub-Admin" is preselected and a Landing Module field appears.</span></p>';
		if ( ! $users ) {
			echo '<p>No Sub-Admins yet.</p>';
			return;
		}
		echo '<table class="widefat striped" style="max-width:1100px"><thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Landing module</th><th>Users created</th><th></th></tr></thead><tbody>';
		foreach ( $users as $u ) {
			$label   = $this->landing_label( (string) get_user_meta( $u->ID, self::META_LANDING, true ) );
			$created = count(
				get_users(
					array(
						'meta_key'   => self::META_ROOT,
						'meta_value' => (string) $u->ID,
						'fields'     => 'ID',
					)
				)
			);
			printf(
				'<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%d</td><td><a href="%s">Edit</a></td></tr>',
				esc_html( $u->display_name ),
				esc_html( $u->user_login ),
				esc_html( $u->user_email ),
				'' !== $label ? esc_html( $label ) : '<em>Dashboard</em>',
				(int) $created,
				esc_url( get_edit_user_link( $u->ID ) )
			);
		}
		echo '</tbody></table>';
	}

	/* ---- Tab: settings ---- */

	private function render_tab_settings() {
		$s         = $this->settings;
		$creatable = $this->creatable_roles();
		$roles     = wp_roles()->get_names();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpsa_save_settings">
			<?php wp_nonce_field( 'wpsa_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Roles a Sub-Admin may create</th>
					<td>
						<?php
						foreach ( $roles as $slug => $name ) {
							if ( in_array( (string) $slug, self::PROTECTED_ROLES, true ) ) {
								continue;
							}
							printf(
								'<label style="display:block"><input type="checkbox" name="creatable[]" value="%s"%s> %s</label>',
								esc_attr( (string) $slug ),
								checked( in_array( (string) $slug, $creatable, true ), true, false ),
								esc_html( translate_user_role( $name ) )
							);
						}
						?>
						<p class="description">Administrators and Sub-Admins can never be created, edited, deleted or even seen by a Sub-Admin.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Which users can a Sub-Admin manage?</th>
					<td>
						<label style="display:block"><input type="radio" name="scope" value="all_below" <?php checked( $s['scope'], 'all_below' ); ?>> All users below the Sub-Admin level (recommended)</label>
						<label style="display:block"><input type="radio" name="scope" value="own" <?php checked( $s['scope'], 'own' ); ?>> Only users that this Sub-Admin (or their users) created</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Block hidden pages by URL</th>
					<td><label><input type="checkbox" name="enforce" value="1" <?php checked( ! empty( $s['enforce'] ) ); ?>> Hidden menu items cannot be opened by typing the address (strongly recommended)</label></td>
				</tr>
				<tr>
					<th scope="row">Admin bar</th>
					<td>
						<label style="display:block"><input type="checkbox" name="hide_bar" value="1" <?php checked( ! empty( $s['hide_bar'] ) ); ?>> Hide the admin bar for Sub-Admins and users they create</label>
						<label style="display:block"><input type="checkbox" name="add_logout" value="1" <?php checked( ! empty( $s['add_logout'] ) ); ?>> Add a "Log Out" item to the left menu for those users</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Allow <code>manage_options</code></th>
					<td>
						<label><input type="checkbox" name="allow_manage_options" value="1" <?php checked( ! empty( $s['allow_manage_options'] ) ); ?>> Give Sub-Admins the <code>manage_options</code> capability</label>
						<p class="description">Many plugins protect their settings screens with this capability, so their menus stay invisible to Sub-Admins until you enable it. It is a sensitive capability: leave it off unless you need a particular plugin's settings page. Core Settings pages remain controlled by the permission matrix, and the "All Settings" screen stays blocked.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Login screen branding</th>
					<td>
						<label style="display:block;margin-bottom:8px"><input type="checkbox" name="login_branding" value="1" <?php checked( ! empty( $s['login_branding'] ) ); ?>> Use the professional branded login screen</label>
						<?php $login_logo = $this->login_logo_url(); ?>
						<div id="wpsa-login-logo-wrap" <?php echo $login_logo ? '' : 'style="display:none"'; ?>>
							<img id="wpsa-login-logo-preview" class="wpsa-login-logo-preview" src="<?php echo esc_url( $login_logo ); ?>" alt="">
						</div>
						<input type="hidden" id="wpsa-login-logo-id" name="login_logo_id" value="<?php echo esc_attr( absint( $s['login_logo_id'] ) ); ?>">
						<p><button type="button" class="button" id="wpsa-login-logo-select">Select login logo</button> <button type="button" class="button-link-delete" id="wpsa-login-logo-remove" <?php disabled( ! $login_logo ); ?>>Remove logo</button></p>
						<p class="description">This provides the custom login experience on the standard WordPress login screen used by <code>/wp-admin</code> and <code>wp-login.php</code>. The login URL itself is not changed. Select a custom image for the login logo; when none is selected, the site's custom logo or site icon is used automatically. No website/site-name text is added by this feature.</p>
					</td>
				</tr>
			</table>
			<?php submit_button( 'Save settings' ); ?>
		</form>

		<div class="wpsa-card">
			<h3>What a Sub-Admin can never do</h3>
			<p>Install, activate, edit, update or delete plugins and themes; switch themes; run core updates; use the file editors; manage privacy tools; create, edit, delete or see Administrators and other Sub-Admins. Everything else follows the permission matrix.</p>
		</div>
		<?php
	}

	/* =====================================================================
	 * Saving (main administrator only)
	 * =================================================================== */

	private function guard_post( $action ) {
		if ( ! $this->is_main_admin() ) {
			wp_die( 'Only the main administrator can do this.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private function back( $tab, $msg = 'saved' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&tab=' . $tab . '&wpsa_msg=' . $msg ) );
		exit;
	}

	private function json_post( $field ) {
		if ( ! isset( $_POST[ $field ] ) || ! is_string( $_POST[ $field ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return array();
		}
		$data = json_decode( wp_unslash( $_POST[ $field ] ), true ); // phpcs:ignore WordPress.Security.NonceVerification
		return is_array( $data ) ? $data : array();
	}

	private function only_known( $values, array $known ) {
		$out = array();
		foreach ( (array) $values as $v ) {
			if ( is_string( $v ) && in_array( $v, $known, true ) ) {
				$out[] = $v;
			}
		}
		return array_values( array_unique( $out ) );
	}

	public function handle_save_permissions() {
		$this->guard_post( 'wpsa_perm' );

		if ( isset( $_POST['wpsa_reset'] ) ) {
			$this->settings['perm'] = array();
			$this->persist();
			$this->back( 'permissions', 'reset' );
		}

		$known = $this->all_keys();
		$all   = $this->only_known( $this->json_post( 'wpsa_all_json' ), $known );
		$vis   = $this->json_post( 'wpsa_vis_json' );
		$perm  = array();

		foreach ( $this->matrix_roles() as $role => $name ) {
			$role    = (string) $role;
			$visible = $this->only_known( isset( $vis[ $role ] ) ? $vis[ $role ] : array(), $all );
			$visible = $this->only_known( $this->normalize_visible( $visible ), $all );
			if ( self::ROLE === $role ) {
				$perm[ $role ] = array( 'mode' => 'allow', 'keys' => $visible );
			} else {
				$perm[ $role ] = array( 'mode' => 'hide', 'keys' => array_values( array_diff( $all, $visible ) ) );
			}
		}

		$this->settings['perm'] = $perm;
		$this->persist();
		$this->back( 'permissions' );
	}

	public function handle_save_links() {
		$this->guard_post( 'wpsa_links' );

		$raw       = ( isset( $_POST['links'] ) && is_array( $_POST['links'] ) ) ? wp_unslash( $_POST['links'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
		$role_keys = array_map( 'strval', array_keys( wp_roles()->get_names() ) );
		$snap      = $this->get_snapshot();
		$links     = array();

		foreach ( $raw as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$title = isset( $r['title'] ) && is_string( $r['title'] ) ? sanitize_text_field( $r['title'] ) : '';
			$url   = isset( $r['url'] ) && is_string( $r['url'] ) ? sanitize_text_field( $r['url'] ) : '';
			if ( '' === $title || '' === $url ) {
				continue;
			}
			$icon   = ( isset( $r['icon'] ) && is_string( $r['icon'] ) && preg_match( '/^dashicons-[a-z0-9-]+$/', $r['icon'] ) ) ? $r['icon'] : 'dashicons-admin-links';
			$parent = ( isset( $r['parent'] ) && is_string( $r['parent'] ) && isset( $snap[ $r['parent'] ] ) ) ? $r['parent'] : '';
			$place  = ( isset( $r['placement'] ) && 'bottom' === $r['placement'] ) ? 'bottom' : 'top';
			$roles  = array();
			if ( isset( $r['roles'] ) && is_array( $r['roles'] ) ) {
				foreach ( $r['roles'] as $rl ) {
					if ( is_string( $rl ) && in_array( $rl, $role_keys, true ) ) {
						$roles[] = $rl;
					}
				}
			}
			$id = ( isset( $r['id'] ) && is_string( $r['id'] ) && '' !== sanitize_key( $r['id'] ) ) ? sanitize_key( $r['id'] ) : substr( md5( uniqid( '', true ) ), 0, 8 );

			$links[] = array(
				'id'        => $id,
				'title'     => $title,
				'url'       => $url,
				'icon'      => $icon,
				'parent'    => $parent,
				'placement' => $place,
				'target'    => empty( $r['target'] ) ? 0 : 1,
				'roles'     => array_values( array_unique( $roles ) ),
			);
		}

		$this->settings['links'] = $links;
		$this->persist();
		$this->back( 'links' );
	}

	public function handle_save_settings() {
		$this->guard_post( 'wpsa_settings' );

		$valid     = array_values( array_diff( array_map( 'strval', array_keys( wp_roles()->get_names() ) ), self::PROTECTED_ROLES ) );
		$creatable = array();
		if ( isset( $_POST['creatable'] ) && is_array( $_POST['creatable'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			foreach ( wp_unslash( $_POST['creatable'] ) as $c ) { // phpcs:ignore WordPress.Security.NonceVerification
				if ( is_string( $c ) && in_array( $c, $valid, true ) ) {
					$creatable[] = $c;
				}
			}
		}

		$this->settings['creatable']            = array_values( array_unique( $creatable ) );
		$this->settings['scope']                = ( isset( $_POST['scope'] ) && 'own' === $_POST['scope'] ) ? 'own' : 'all_below'; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['enforce']              = empty( $_POST['enforce'] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['hide_bar']             = empty( $_POST['hide_bar'] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['add_logout']           = empty( $_POST['add_logout'] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['allow_manage_options'] = empty( $_POST['allow_manage_options'] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['login_branding']       = empty( $_POST['login_branding'] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$logo_id                                 = isset( $_POST['login_logo_id'] ) ? absint( $_POST['login_logo_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings['login_logo_id']        = ( $logo_id && wp_get_attachment_image_url( $logo_id, 'full' ) ) ? $logo_id : 0; // phpcs:ignore WordPress.Security.NonceVerification
		// login_brand_name/login_tagline were removed from the UI in 1.1.3.
		// Legacy values may remain in the database but are never rendered.

		$this->persist();
		$this->back( 'settings' );
	}
}

register_activation_hook( __FILE__, array( 'WPSA_Plugin', 'activate' ) );
WPSA_Plugin::instance();
