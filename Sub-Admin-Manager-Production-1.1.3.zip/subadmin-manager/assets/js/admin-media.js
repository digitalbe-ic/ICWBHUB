(function () {
	'use strict';

	function initLoginLogoPicker() {
		var button = document.getElementById('wpsa-login-logo-select');
		var remove = document.getElementById('wpsa-login-logo-remove');
		var field = document.getElementById('wpsa-login-logo-id');
		var wrap = document.getElementById('wpsa-login-logo-wrap');
		var preview = document.getElementById('wpsa-login-logo-preview');

		if (!button || !field || typeof window.wp === 'undefined' || typeof window.wp.media !== 'function') {
			return;
		}

		var frame = null;

		button.addEventListener('click', function (event) {
			event.preventDefault();

			if (frame) {
				frame.open();
				return;
			}

			frame = window.wp.media({
				title: 'Choose login logo',
				button: { text: 'Use this logo' },
				multiple: false,
				library: { type: 'image' }
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first();
				if (!attachment) {
					return;
				}

				attachment = attachment.toJSON();
				field.value = attachment.id || '';

				var src = attachment.sizes && attachment.sizes.full && attachment.sizes.full.url
					? attachment.sizes.full.url
					: attachment.url;

				if (src && preview) {
					preview.src = src;
				}
				if (wrap) {
					wrap.style.display = 'block';
				}
				if (remove) {
					remove.disabled = false;
				}
			});

			frame.open();
		});

		if (remove) {
			remove.addEventListener('click', function (event) {
				event.preventDefault();
				field.value = '';
				if (preview) {
					preview.removeAttribute('src');
				}
				if (wrap) {
					wrap.style.display = 'none';
				}
				remove.disabled = true;
			});
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initLoginLogoPicker);
	} else {
		initLoginLogoPicker();
	}
}());
