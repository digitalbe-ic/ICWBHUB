<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 * Sub-Admin users are moved to Editor so they are not left without a role.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$wpsa_users = get_users( array( 'role' => 'sub_admin', 'fields' => 'ID' ) );
foreach ( $wpsa_users as $wpsa_id ) {
	$wpsa_user = new WP_User( $wpsa_id );
	$wpsa_user->set_role( 'editor' );
}
remove_role( 'sub_admin' );

delete_option( 'wpsa_settings' );
delete_option( 'wpsa_menu_snapshot' );

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key IN ('_wpsa_landing','_wpsa_created_by','_wpsa_root')" );
