<?php
/** Declarative bilingual collection schema; values are never collected from UI labels. */
return [
    'version' => '1.0.0',
    'roles' => [
        'applicant' => ['en' => 'Applicant', 'hi' => 'आवेदक'],
        'co_applicant' => ['en' => 'Co-applicant', 'hi' => 'सह-आवेदक'],
        'guarantor_1' => ['en' => 'Guarantor 1', 'hi' => 'गारंटर 1'],
        'guarantor_2' => ['en' => 'Guarantor 2', 'hi' => 'गारंटर 2'],
    ],
    'sections' => [
        'application' => [
            'label' => ['en' => 'Loan request', 'hi' => 'ऋण अनुरोध'],
            'fields' => [
                ['name' => 'product', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Loan product', 'hi' => 'ऋण उत्पाद']],
                ['name' => 'branch', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Branch', 'hi' => 'शाखा']],
                ['name' => 'requested_amount_paise', 'type' => 'money', 'required' => true, 'min' => 1, 'label' => ['en' => 'Requested amount (INR)', 'hi' => 'अनुरोधित राशि (रुपये)']],
                ['name' => 'purpose', 'type' => 'textarea', 'required' => true, 'label' => ['en' => 'Loan purpose', 'hi' => 'ऋण का उद्देश्य']],
            ],
        ],
        'personal' => [
            'label' => ['en' => 'Party details', 'hi' => 'सदस्य विवरण'],
            'fields' => [
                ['name' => 'legal_name', 'type' => 'text', 'required' => true, 'maxLength' => 160, 'label' => ['en' => 'Legal name', 'hi' => 'दस्तावेज़ के अनुसार नाम']],
                ['name' => 'dob', 'type' => 'date', 'required' => true, 'label' => ['en' => 'Date of birth', 'hi' => 'जन्म तिथि']],
                ['name' => 'gender', 'type' => 'select', 'required' => false, 'required_for' => ['credit-report'], 'pattern' => '^(male|female|other)$', 'options' => ['male' => ['en' => 'Male', 'hi' => 'पुरुष'], 'female' => ['en' => 'Female', 'hi' => 'महिला'], 'other' => ['en' => 'Other', 'hi' => 'अन्य']], 'label' => ['en' => 'Gender (optional; required by some bureau providers)', 'hi' => 'लिंग (वैकल्पिक; कुछ ब्यूरो प्रदाताओं के लिए आवश्यक)']],
                ['name' => 'occupation', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Occupation', 'hi' => 'व्यवसाय']],
                ['name' => 'mobile', 'type' => 'tel', 'required' => true, 'pattern' => '^[6-9][0-9]{9}$', 'sensitive' => true, 'label' => ['en' => 'Mobile number', 'hi' => 'मोबाइल नंबर']],
                ['name' => 'email', 'type' => 'email', 'required' => false, 'sensitive' => true, 'label' => ['en' => 'Email address', 'hi' => 'ईमेल पता']],
                ['name' => 'relationship', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Relationship with applicant', 'hi' => 'आवेदक के साथ संबंध']],
                ['name' => 'pan', 'type' => 'text', 'required' => false, 'pattern' => '^[A-Z]{5}[0-9]{4}[A-Z]$', 'sensitive' => true, 'label' => ['en' => 'PAN', 'hi' => 'पैन']],
                ['name' => 'aadhaar_last4', 'type' => 'text', 'required' => true, 'pattern' => '^[0-9]{4}$', 'sensitive' => true, 'label' => ['en' => 'Aadhaar last four digits', 'hi' => 'आधार के अंतिम चार अंक']],
                ['name' => 'voter_id', 'type' => 'text', 'required' => false, 'sensitive' => true, 'label' => ['en' => 'Voter ID', 'hi' => 'मतदाता पहचान पत्र']],
                ['name' => 'aadhaar_linked_mobile_declared', 'type' => 'checkbox', 'required' => false, 'label' => ['en' => 'I declare this mobile is linked to my Aadhaar (not independently verified)', 'hi' => 'मैं घोषणा करता/करती हूं कि यह मोबाइल मेरे आधार से जुड़ा है (स्वतंत्र सत्यापन नहीं)']],
                ['name' => 'annual_household_income_paise', 'type' => 'money', 'required' => true, 'min' => 0, 'label' => ['en' => 'Annual household income (INR)', 'hi' => 'वार्षिक घरेलू आय (रुपये)']],
            ],
        ],
        'address' => [
            'label' => ['en' => 'Residence', 'hi' => 'निवास'],
            'fields' => [
                ['name' => 'current_address', 'type' => 'textarea', 'required' => true, 'sensitive' => true, 'label' => ['en' => 'Current address', 'hi' => 'वर्तमान पता']],
                ['name' => 'permanent_address', 'type' => 'textarea', 'required' => true, 'sensitive' => true, 'label' => ['en' => 'Permanent address', 'hi' => 'स्थायी पता']],
                ['name' => 'years_at_address', 'type' => 'number', 'required' => true, 'min' => 0, 'max' => 120, 'label' => ['en' => 'Years at current address', 'hi' => 'वर्तमान पते पर वर्ष']],
                ['name' => 'residence_owner_name', 'type' => 'text', 'required' => false, 'label' => ['en' => 'Residence owner name', 'hi' => 'मकान मालिक का नाम']],
                ['name' => 'owner_relationship', 'type' => 'text', 'required' => false, 'label' => ['en' => 'Owner relationship', 'hi' => 'मकान मालिक से संबंध']],
            ],
        ],
        'bank' => [
            'label' => ['en' => 'Bank account', 'hi' => 'बैंक खाता'],
            'fields' => [
                ['name' => 'holder_name', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Account holder name', 'hi' => 'खाता धारक का नाम']],
                ['name' => 'bank_name', 'type' => 'text', 'required' => true, 'label' => ['en' => 'Bank name', 'hi' => 'बैंक का नाम']],
                ['name' => 'account_number', 'type' => 'text', 'required' => true, 'sensitive' => true, 'pattern' => '^[0-9]{6,20}$', 'label' => ['en' => 'Account number', 'hi' => 'खाता संख्या']],
                ['name' => 'account_number_confirm', 'type' => 'text', 'required' => true, 'sensitive' => true, 'transient' => true, 'label' => ['en' => 'Confirm account number', 'hi' => 'खाता संख्या की पुष्टि']],
                ['name' => 'ifsc', 'type' => 'text', 'required' => true, 'pattern' => '^[A-Z]{4}0[A-Z0-9]{6}$', 'label' => ['en' => 'IFSC', 'hi' => 'आईएफएससी']],
            ],
        ],
    ],
    'documents' => [
        'aadhaar_front' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Aadhaar front', 'hi' => 'आधार का आगे का भाग']],
        'aadhaar_back' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Aadhaar back', 'hi' => 'आधार का पीछे का भाग']],
        'identity_proof' => ['required' => true, 'capture' => 'original_camera', 'choices' => ['pan', 'voter_id', 'passport', 'driving_licence'], 'label' => ['en' => 'PAN / approved identity proof', 'hi' => 'पैन / स्वीकृत पहचान प्रमाण']],
        'live_photo' => ['required' => true, 'capture' => 'live_camera', 'label' => ['en' => 'Live photograph (not a liveness certification)', 'hi' => 'लाइव फोटो (जीवंतता प्रमाणीकरण नहीं)']],
        'relationship_proof' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Relationship proof', 'hi' => 'संबंध प्रमाण']],
        'address_proof' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Address proof', 'hi' => 'पता प्रमाण']],
        'signature_specimen' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Signature specimen (not eSign)', 'hi' => 'हस्ताक्षर नमूना (ई-साइन नहीं)']],
        'bank_passbook' => ['required' => true, 'capture' => 'original_camera', 'label' => ['en' => 'Bank passbook', 'hi' => 'बैंक पासबुक']],
    ],
    'consents' => [
        'data_processing' => ['en' => 'Processing of my data for this application', 'hi' => 'इस आवेदन के लिए मेरे डेटा का प्रसंस्करण'],
        'kyc' => ['en' => 'Identity and bank verification with the named KYC provider', 'hi' => 'नामित केवाईसी प्रदाता के साथ पहचान और बैंक सत्यापन'],
        'credit_bureau' => ['en' => 'Separate credit bureau enquiry with the named provider', 'hi' => 'नामित प्रदाता के साथ अलग क्रेडिट ब्यूरो जाँच'],
        'esign' => ['en' => 'Electronic execution of the exact approved document with the named eSign provider', 'hi' => 'नामित ई-साइन प्रदाता के साथ सटीक स्वीकृत दस्तावेज़ का इलेक्ट्रॉनिक निष्पादन'],
        'camera' => ['en' => 'Camera capture for original-document photographs and live photo', 'hi' => 'मूल दस्तावेज़ों और लाइव फोटो के लिए कैमरा कैप्चर'],
        'communications' => ['en' => 'Application communications through the specified approved channels', 'hi' => 'निर्दिष्ट स्वीकृत माध्यमों से आवेदन संबंधी संचार'],
        'loan_terms' => ['en' => 'Acceptance of the specified loan terms and document version', 'hi' => 'निर्दिष्ट ऋण शर्तों और दस्तावेज़ संस्करण की स्वीकृति'],
        'initial_mandate' => ['en' => 'Separate initial-loan repayment mandate authorization', 'hi' => 'प्रारंभिक ऋण चुकौती के लिए अलग मैंडेट अनुमति'],
        'bc_mandate' => ['en' => 'Separate final BC-loan repayment mandate authorization', 'hi' => 'अंतिम बीसी ऋण चुकौती के लिए अलग मैंडेट अनुमति'],
        'return_collection' => ['en' => 'Separate INR 10,000 return collection for the named entity and purpose', 'hi' => 'नामित संस्था और उद्देश्य के लिए अलग 10,000 रुपये की वापसी राशि का संग्रह'],
        'slt_membership' => ['en' => 'Separate SLT membership terms', 'hi' => 'अलग एसएलटी सदस्यता शर्तें'],
        'slt_mandate' => ['en' => 'Separate one-time INR 25,000 SLT authorization', 'hi' => 'अलग एकमुश्त 25,000 रुपये एसएलटी अनुमति'],
        'visit_location' => ['en' => 'Optional verification visit photos/location', 'hi' => 'वैकल्पिक सत्यापन यात्रा फोटो/स्थान'],
        'recording' => ['en' => 'Optional counselling recording', 'hi' => 'वैकल्पिक परामर्श रिकॉर्डिंग'],
    ],
    'capture_instruction' => [
        'en' => 'Photograph the original document clearly. Photocopies and screenshots are not accepted. Camera metadata alone does not prove originality; staff review is required.',
        'hi' => 'मूल दस्तावेज़ की स्पष्ट फोटो लें। फोटोकॉपी और स्क्रीनशॉट स्वीकार नहीं हैं। कैमरा मेटाडेटा से मूल होने का प्रमाण नहीं मिलता; कर्मचारी समीक्षा आवश्यक है।',
    ],
];
