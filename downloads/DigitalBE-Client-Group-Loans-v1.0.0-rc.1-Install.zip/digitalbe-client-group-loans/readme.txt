=== digital BE Client & Group Loans ===
Contributors: digitalbe
Tags: loan, onboarding, kyc, group-loan, workflow
Requires at least: 6.5
Tested up to: 6.9
Requires PHP: 8.1
Stable tag: 1.0.0-rc.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Four-party loan onboarding, Surepass KYC and staff workflow with separate loan, return and SLT contribution records.

== Description ==

digital BE Client & Group Loans provides a protected applicant portal and staff operations console for an applicant, co-applicant and two guarantors. It includes original-document capture/review, individual consent, assignment, BC/counselling evidence, document versioning, mandates, verifications, queries, DB-kit acceptance and independent financial reconciliation.

The INR 10,000 initial loan, separate INR 10,000 return, initial lender repayment, final BC loan and INR 25,000 one-time SLT contribution remain separate. The return does not close the lender's loan or reduce the contribution. Submitted or unknown payments are not treated as settled.

This release candidate requires operations UAT and production integration review. No live Surepass request, signature, mandate, transfer or debit was executed during development. AU Bank eNACH and bank payment APIs are not bundled or guessed. Local provider tests use mocks. No public website was deployed.

Source, test commands, configuration details and the feature/dependency matrix are included in README.md and docs/PROJECT-PLAN.md.

== Installation ==

1. Use WordPress 6.5+, PHP 8.1+ with OpenSSL/mysqli/Fileinfo, HTTPS and MySQL/MariaDB with transactional tables.
2. Configure recoverable encryption material and DBCL_PRIVATE_DIR outside public document roots; back up both data and the original encryption key.
3. Upload/activate the plugin. Add [digitalbe_client_group_loans] to a protected page.
4. Assign separate staff roles and independent participant accounts. Configure organization/branch scope, verified mobile authentication, staff MFA and malware scanning integrations.
5. Publish approved lender/SLT policies, consent text, templates and signer matrices. A different finance checker approves financial policy revisions; a supervisor explicitly applies updated policy to existing cases.
6. Configure the contracted provider securely and perform sandbox/UAT checks before any live operation. See README.md for remaining release prerequisites.

== Frequently Asked Questions ==

= Does this plugin automatically issue loans or move money? =

No bank-transfer or AU Bank eNACH service is enabled by default. Financial records and gates support controlled evidence-backed operations. Actual execution requires approved provider adapters and product configuration. An initiation or mandate registration does not establish settlement.

= Does it include approved lender legal documents? =

It generates versioned printable documents from supplied approved text. The sample ISF form informed field coverage; its legal wording, identity and commercial charges are not adopted automatically. Approved-PDF eSign is separate from printable HTML and specimen signatures.

= How are records protected? =

Sensitive case state and private files use authenticated encryption, scoped object access, expected record versions and audited evidence downloads. A stable encryption key or the original WordPress salts must be retained for recovery. MFA, mobile authentication, malware scanning, retention/deletion, backups and monitoring require deployment configuration.

= What happens on uninstall? =

Loan, consent, audit and private-evidence records are retained. Apply an approved export/retention/deletion procedure before deliberate data removal.

== External Services ==

Surepass verification and eSign are optional external integrations. When an authorized user initiates a configured operation after the party's relevant consent, the server sends only that operation's mapped identity/bank/contact or approved document data to the configured Surepass endpoint. The integration may use DigiLocker for Aadhaar retrieval and the provider's signing flow for an approved PDF. Provider redirects and tokens are private to the authorized session.

Production Surepass host: https://kyc-api.surepass.app
Sandbox Surepass host: https://sandbox.surepass.io
Provider website: https://surepass.io

Configure and review your contracted provider terms/privacy policy before activation. docs/SUREPASS.md lists recovered RC11 request contracts, active products, consent boundaries, supported hosts and live validation requirements. Additional eNACH, bank, BC, communication and meeting adapters are external integrations requiring their own contracts and disclosures. No external provider credentials are included.

== Changelog ==

= 1.0.0-rc.1 =
* Initial client/group onboarding and staff workflow implementation.
* Separate loan, return, lender repayment, final BC and SLT financial records and gates.
* Surepass request contracts recovered from the supplied digital BE Loan Engine RC11.
* Private encrypted evidence, purpose-specific consent, document snapshots, audit and local integration tests.
