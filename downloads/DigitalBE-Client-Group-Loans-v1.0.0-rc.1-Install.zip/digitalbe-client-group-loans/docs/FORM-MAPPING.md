# Form and document mapping

The supplied JLG specification and client/group workflow define the application. The sample `2026_ISF-LBA-Retail-201026.docx` informs field coverage and document structure; its ISF identity, commercial rates and legal text are not adopted as digital BE terms.

| Sample / specification item | Collection schema / generated output |
| --- | --- |
| Application date, number, LSP, product, amount, purpose, tenure | Case identifiers and metadata; `application` section; loan term snapshot |
| Applicant, co-borrower, two guarantors | Four separate application-party roles: `applicant`, `co_applicant`, `guarantor_1`, `guarantor_2` |
| Name, occupation, DOB, relationship and identity | `personal` section; full Aadhaar is not a profile field; retain last four digits only |
| Current/permanent addresses, residence years, residence owner | `address` section |
| Bank, account holder, account number, IFSC | `bank` section; confirmation is transient and must not be persisted; print views mask identifiers |
| Annual household income and Aadhaar-linked mobile | Separate declared fields; a mobile OTP does not prove Aadhaar linkage |
| Mandatory identity and address evidence | Role-specific document checklist in `config/form-schema.php` |
| Original document photographs | Capture instruction, independent image-quality/originality review and preserved source evidence; metadata is not originality proof |
| Application declarations and data sharing | Purpose-specific individual consents with exact approved text/version; no preselected acceptance |
| Sanction letter, KFS, agreement, DPN, indemnity | `Documents::render()` / `snapshot()`; initial/BC loan context is separate |
| KFS charges, repayment dates, APR | Configured integer-paise fees, reducing-balance schedule, actual-date effective annual IRR illustration |
| SLT membership | Separate one-time INR 25,000 contribution and authorization; INR 10,000 return remains additional |
| Payment acknowledgement | Settlement receipt only after confirmed settlement reference, date, amount, obligation and recipient are present |
| DB kit | Versioned evidence inventory and financial status snapshot; submission does not imply partner acceptance |

## Template approval and integrity

`Documents::snapshot(type, case, settings)` returns printable HTML, a SHA-256 hash, source case version, template/terms versions and required signer matrix. The calling service stores this as an immutable generated version. Generate a new version after material source data changes; never silently edit an executed document.

Supported types are `application`, `sanction`, `kfs`, `agreement`, `dpn`, `indemnity`, `membership`, `receipt` and `db_kit`. Prefix loan document types with `initial_` or `bc_`, or pass `settings.loan_kind`. Initial-loan execution never satisfies final BC-loan document requirements.

The default print output is marked **DRAFT — NOT FOR EXECUTION**. Configure lender identity, an approved template version, explicitly approved terms and the document-specific signer matrix before execution. For legal documents provide `document_templates[type] = {text, version, approved}`. Approved text supports only a small set of literal placeholders: `{{application_id}}`, `{{group_id}}`, `{{lender_name}}`, `{{borrower_name}}`, `{{loan_id}}`, `{{loan_amount}}`, `{{slt_amount}}`. Text is escaped and is never interpreted as PHP or executable HTML.

Sample commercial terms require reconciliation: the sample lists loan cancellation as NIL in one place and an INR 1,000 plus interest formula elsewhere. No sample processing, penal, foreclosure or cancellation rate is hardcoded. DPN wording, stamp requirements, indemnity terms, lender identity, grievance details and SLT purpose/refund/participation rules require the appropriate approved source text.

## Repayment illustration

`Documents::schedule(terms)` accepts positive integer `amount_paise`, `tenure_months` (1–600), annual nominal `annual_rate`, `frequency` (`monthly` or `semi_monthly`) and `first_due_date` (`YYYY-MM-DD`). Monthly dates retain the first-due-day anchor and clamp only for short months. Semi-monthly dates use two distinct configured `semi_monthly_days` from 1–28, defaulting to 1 and 15; the first due date must match one of them. Principal components reconcile exactly to the original principal, with rounding reconciled in the last instalment.

The APR additionally requires `disbursement_date` and either a valid `net_disbursed_paise` or the disclosed deducted fees (`processing_fee_paise`, `tax_paise`, `insurance_fee_paise`, `stamp_fee_paise`, `other_fee_paise`). It uses actual UTC calendar dates and a 365-day annualization. Incomplete dates cannot produce a verified KFS. These are fixed reducing-balance illustrations; lender-specific broken periods, holidays and day-count conventions require the lender-approved schedule. The application must not treat an illustration as a lender-approved offer.

## Access and consent

Whole-group application documents include party names and addresses. Serve them only to authorized staff or under the approved joint-document sharing policy; a guarantor's membership must not expose another party's private KYC evidence. All direct evidence downloads still require scoped authorization and an audit entry. Identifiers are masked in print output, and no public file URL is generated by this module.

Each party must accept applicable versioned terms from that party's own authenticated session. A signature specimen, meeting attendance or browser return URL is not completed eSign. eSign, mandate authorization and settlement remain separate authenticated evidence records.
