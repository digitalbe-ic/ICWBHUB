# digital BE Client & Group Loans 1.0.0-rc.1

This release implements the supplied client/group loan workflow as a standalone WordPress plugin, using the supplied Loan Engine RC11 visual and Surepass integration patterns. It is ready for installation on a test site and operations UAT. It has not been deployed or certified against a live provider account.

## Included

- Four independent participant accounts, bilingual collection forms, individual versioned consents and expiring invitations.
- Private encrypted evidence, original-document review, Surepass PAN/bank/DigiLocker adapters, and document-bound eSign with encrypted executed PDFs.
- Staff scope, assignments, BC/counselling tasks, FVR/BVR results, queries, versioned DB-kit gates, printable lender documents, KFS/APR calculations and receipts.
- Separate initial-loan, return, lender-repayment, final-BC and SLT records; maker/checker approval, idempotency, settlement/reversal history and one-time contribution protection.
- Payer mandate-withdrawal requests, terminal-state protection, current mandate/document-version callback correlation, sandbox/production evidence separation, scoped CSV export, audit/access records, in-app notices and SLA reminders.
- Tested local setup/start/test scripts and source/distribution packaging.

## Validation completed

Validation used WordPress 6.9.4, PHP 8.4.27 and MariaDB 11.8.6 in a disposable local installation:

| Check | Result |
| --- | --- |
| PHP syntax | Passed |
| WordPress integration assertions | 482 passed, 0 failed |
| Storage integrity assertions | 17 passed, 0 failed |
| Notification assertions | 42 passed, 0 failed |
| Real authenticated HTTP assertions | 17 passed, 0 failed |
| DOM JavaScript assertions | 17 passed, 0 failed |
| Fresh setup, repeated setup, service restart and readiness | Passed |

The 541 PHP assertions and 34 HTTP/DOM assertions executed and completed. Provider tests intercepted HTTP with synthetic fixtures; no live KYC enquiry, signature, message, mandate, transfer or debit was executed. DOM checks do not establish visual-browser, real-camera or accessibility certification. No separate new-task snapshot restoration or production hosting validation is claimed.

## Before production

Supply the Surepass credential securely and validate the entitled provider contracts in the approved account. AU Bank eNACH and payment execution remain unavailable until their actual contracts/adapters are supplied. Finalize actual lender/BC/return/SLT identities, product terms, borrower allocations, signer/checklist rules and release approvals. Configure verified mobile authentication, staff MFA, scanning, private storage, retention/backup and any external delivery adapters. Complete provider sandbox certification and operations/security UAT described in PROJECT-PLAN.md.

The install ZIP excludes test runners and development setup scripts. The source ZIP includes them for development. Neither package contains uploaded source documents, customer evidence, local WordPress/database files, salts or provider credentials.
