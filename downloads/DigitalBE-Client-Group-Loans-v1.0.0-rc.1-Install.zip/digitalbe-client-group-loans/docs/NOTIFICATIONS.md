# In-app notifications and SLA reminders

The plugin records customer-safe stage/exception notices inside the encrypted application. Notices contain fixed text, application status, recipients, per-user read acknowledgements and delivery metadata. They do not copy private officer notes, KYC identifiers, documents or arbitrary command inputs. The initial loan, separate INR 10,000 return, BC loan and separate INR 25,000 SLT contribution remain distinct in notice text.

The API calls `Notifications::append($case, $event)` before its versioned case save. The method only adds a notice when the stage or exception code changes, with a deduplication key derived from application, event and next version. It performs no external delivery. Register the module once with `Notifications::register()`.

- `GET /wp-json/digitalbe-loans/v1/applications/{application_id}/notifications` returns the independently authenticated user's notices and unread count, after ordinary organization/branch/case authorization.
- `POST /wp-json/digitalbe-loans/v1/notifications/{notification_id}/read` accepts `application_id` and `expected_version` in JSON. A user can mark only their own recipient notice as read. Other recipients and internal delivery references are never exposed by these endpoints. `read_at` records the current user's acknowledgement timestamp when available; legacy acknowledgements without a timestamp are represented as `true`, without inventing a historical time.

The `dbcl_run_reminders` cron hook scans applications through internal paginated storage access. `sla_hours` defaults to 48 and is bounded to 1–720 hours. A reminder requires both an overdue stage/exception and absence of a recent reminder for this interval. `notification_state.stage_entered_at` changes only when the stage or exception changes; older records fall back to application creation time. Reading a notice, recording delivery or editing an unrelated field does not postpone an outstanding stage SLA. Terminal completed/rejected/expired/abandoned/client-declined cases are excluded. Reminders do not approve a loan, execute a payment or imply settlement. WordPress cron depends on site traffic; schedule a real server cron to invoke WordPress cron for reliable timing.

## Optional external delivery adapter

External channels are disabled by default. At delivery time the module rechecks current case membership/assignment and excludes client parties without accepted `communications` consent. Assigned staff are eligible for configured operational delivery. Each user sees only their own external delivery eligibility/state, rather than a delivery to another recipient. The adapter remains responsible for authorized channels, verified destinations and channel-specific template/consent requirements. No email, SMS, WhatsApp or meeting invitation is sent by the built-in module. To use a production channel, explicitly set `notifications_enabled: true` and register a reviewed `dbcl_deliver_notification` filter. The filter receives:

```php
add_filter('dbcl_deliver_notification', function ($unused, array $notice, array $context) {
    // Resolve the authorized recipients securely; do not return identity data.
    // Use $context['idempotency_key'] for provider-side deduplication.
    // Invoke the approved channel and confirm its documented result here.
    return ['status' => 'DELIVERED', 'reference' => 'provider-reference'];
}, 10, 3);
```

This example is an adapter contract, not an implemented provider. `DELIVERED` must reflect the provider's documented confirmed delivery result; an accepted request alone is insufficient. A fan-out adapter must confirm delivery for every supplied recipient before reporting the notice as `DELIVERED`; partial or uncertain delivery is `UNKNOWN` until reconciled. An adapter must not report success simply because it submitted a message. Return `FAILED` only for a confirmed failure; return `UNKNOWN` for an uncertain result. Provider errors and exceptions are reduced to safe reason codes rather than copied into ordinary audit logs.

A notice has `PENDING`, `DISABLED`, `PROCESSING`, `DELIVERED`, `FAILED` or `UNKNOWN` external delivery state. Before invoking the adapter, the module durably claims `PROCESSING` using the application's optimistic version. The notice ID is its stable provider idempotency key. Failed concurrency claims never invoke the adapter. Completed/failed/unknown notices are not automatically retried. Stale processing attempts become `UNKNOWN` after `notification_processing_timeout_seconds` (default 300, bounded 60–3600), preventing blind resend after a process crash or uncertain provider outcome. Operators must reconcile with their provider before an explicit supported retry. Historical `DISABLED` notices are not automatically sent when a channel is enabled later.

Current instance tests must use a local mock filter, with synthetic recipients. Live provider credentials, channel permissions, customer communication consent, channel-specific templates and delivery/reconciliation contracts remain deployment configuration dependencies.
