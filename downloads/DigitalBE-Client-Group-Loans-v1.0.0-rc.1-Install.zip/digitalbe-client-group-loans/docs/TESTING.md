# Development runtime and verification

Use an isolated WordPress database. Tests create synthetic users, documents and loan records; never point them at a live lending site. The PHP test bootstrap suppresses `wp_mail`, and all provider HTTP calls in the integration suite are intercepted by WordPress HTTP mocks. Notification adapters in tests return synthetic outcomes. No actual KYC enquiry, SMS, email, debit or transfer is sent.

## Prepare and start

On this Debian environment, the complete reproducible local setup is:

```sh
cd /workspace/ICWBHUB/digitalbe-client-group-loans
./tools/setup-local.sh
```

The script downloads packages through signed Debian repositories, preserves APT signatures/checksums and HTTPS verification, extracts PHP/MariaDB locally, checks the pinned official WordPress core commit, creates a disposable private-socket database, generates test salts and an administrator password outside the repository, activates the plugin and checks real HTTP login output. Existing configuration, credentials and database contents are retained on repeat runs.

After a task restart, restore the retained services with:

```sh
./tools/start-local.sh
```

This starts only missing local services, checks a MariaDB query and WordPress login response, and leaves existing databases and credentials unchanged. It refuses to replace another service occupying the HTTP port. `DBCL_RUNTIME_DIR` defaults to `/workspace/.runtime`; `DBCL_HTTP_PORT` defaults to `8087`. A different port should be selected when preparing a separate disposable runtime, since WordPress stores its site URL during setup. No localhost preview is required.

First installation into an empty second runtime, repeat installation, stopped-service restart and repeated startup have all been exercised. The primary runtime is PHP 8.4.27, MariaDB 11.8.6 and official WordPress 6.9.4 (tag commit `97b7f62adb5d8864c3fac554bc7182d9fd754a41`). The database uses a directory-restricted Unix socket with networking disabled. Runtime files, package caches, core checkout, keys/salts, test credentials, private files and database contents remain outside the plugin checkout. This is a development runtime rather than production hosting configuration.

## Functional integration suite

```sh
PHP_BIN=/workspace/.runtime/bin/php \
DBCL_WP_ROOT=/workspace/.runtime/wordpress \
./tools/test.sh
```

On another machine, provide PHP 8.1+ with OpenSSL, mysqli and Fileinfo, plus WordPress 6.5+ backed by MySQL/MariaDB; set `PHP_BIN` and `DBCL_WP_ROOT` accordingly. The runner first lints PHP and then reports the executed assertion count, exiting nonzero on any failure. Syntax validation alone is not the functional check.

Coverage includes authenticated encryption/tamper rejection, private original-document uploads, scope and role isolation, dual-role party restrictions, optimistic concurrency, one-time invitations, settings CAS/independent approval, callback replay and atomic commit/rollback, source-derived Surepass payloads and KYC verdicts, durable KYC reservations/unknown outcomes, document-bound eSign evidence, in-app notices and controlled mock delivery, SLA intervals, amortization/date/APR calculations, and the complete four-party business journey. Financial checks preserve distinct loan/return/SLT ledgers, maker/checker separation, idempotency, unknown-result reconciliation, confirmed disbursement prerequisites, and one successful SLT collection.

## HTTP and JavaScript checks

With the local runtime running and plugin activated:

```sh
DBCL_TEST_ALLOW=1 python tools/http-smoke.py
```

The HTTP smoke uses a private local test password file without printing it. It performs a real WordPress login, obtains a REST nonce, creates a synthetic application, saves a profile, checks CSRF/version/permission errors, uploads an actual multipart PNG through `is_uploaded_file()`, and verifies private authenticated download bytes and anonymous denial. These smoke records remain visibly synthetic in the disposable database.

The optional DOM test uses jsdom outside the plugin dependency tree:

```sh
npm install --prefix /workspace/.runtime/ui-tests \
  --cache /workspace/.runtime/npm-cache --no-audit --no-fund jsdom@26.1.0
DBCL_TEST_ALLOW=1 node tools/ui-smoke.cjs
```

It executes the shipped JavaScript against the real local WordPress REST API, checking queue/application creation, labelled forms, party isolation, original-document instructions, separate financial amounts, signature navigation, Hindi text and absence of browser storage. It validates JavaScript/DOM behavior; it is not a visual browser or accessibility certification.

Live Surepass credentials/subscriptions, actual provider-host access and actual bank/eNACH, mobile authentication, staff MFA, malware scanning and communication adapters require their own configured sandbox/hosting validation. Synthetic integration results do not establish live KYC, signature, message delivery or settlement readiness.
