# Surepass and external-provider integration

This plugin sends Surepass requests from WordPress. The server Bearer credential is never returned to the browser. Live service behaviour has **not** been validated with customer credentials. A successful mocked integration test validates the request and interpretation code, not subscription access, customer identity, a signature, or a payment.

## Source contracts and active subscriptions

The uploaded `surepass_apis_active-Status 181026.csv` has 21 Active rows representing 19 distinct product codes. Duplicate rows describe DigiLocker link/SDK and eSign/stamp variants. All other CSV products are excluded from the catalog.

| Active code | Product |
| --- | --- |
| `ocr-aadhaar-masking` | Aadhaar masking |
| `address-comparator` | Address comparison |
| `bank-verification` | Bank account verification |
| `bulk` | Bulk requests |
| `credit-report-cibil-pdf` | CIBIL PDF |
| `credit-report-crif-pdf` | CRIF PDF |
| `credit-report-experian-pdf` | Experian PDF |
| `digilocker` | DigiLocker link / web SDK |
| `credit-report` | Equifax JSON |
| `credit-report-pdf` | Equifax PDF |
| `esign` | eSign / eStamp |
| `face-liveness-v6` | Face liveness V6 |
| `face-match` | Face match |
| `bank-verification-find-ifsc` | IFSC lookup |
| `pan-advanced-v2` | PAN Advanced V2 |
| `pan-advanced` | PAN Advanced |
| `pan-advanced-v3` | PAN Advanced V3 |
| `reverse-penny-drop` | Reverse penny drop |
| `voter-id-text` | Voter ID text |

The CSV supplies product codes, not endpoint routes or request/response schemas. The user subsequently supplied `DigitalBE-Loan-Engine-v2.1.10-RC11-Install.zip`. Its `class-api.php`, `class-phase.php`, and `class-v2.php` provide the following default mappings. These are reused source contracts; this does not establish that a later Surepass account/schema is unchanged.

| Operation | Method and path | Application inputs | Interpretation |
| --- | --- | --- | --- |
| `pan-advanced-v3` | POST `/api/v1/pan/pan-adv` | `pan` → `id_number` | Requires explicit valid PAN status, holder name matching the expected party name, and no conflicting echoed PAN. |
| `bank-verification` | POST `/api/v1/bank-verification/` | `account_number` → `id_number`, `ifsc`; fixed `ifsc_details: true` | Requires explicit account existence, holder name matching the party, and no conflicting account/IFSC echo. |
| `digilocker` / `digilocker-initialize` | POST `/api/v1/digilocker/initialize` | Fixed `data.signup_flow: true`, `data.skip_main_screen: false` | A valid client ID plus SDK token creates a pending session, never a verified identity. |
| `digilocker-download` | GET `/api/v1/digilocker/download-aadhaar/{client_id}` | Existing `client_id` beginning `digilocker_` | Requires successful provider response and Aadhaar XML demographics with full name, DOB and masked Aadhaar. A supplied expected name must match. |
| `credit-report` | POST `/api/v1/credit-report-v2/fetch-report` | `name`, `pan` → `id_number`, `mobile`, `gender`; fixed `id_type: pan`, `consent: Y` | Production only; separate `credit_bureau` consent. A received report remains for credit review, never automatic approval. |
| `esign-status` | GET `/api/v1/esign/status/{client_id}` | Existing `client_id` beginning `esign_` | Separate `esign` consent. Only `esign_completed` verifies provider signing status; executed document retrieval and storage remain separate requirements. |
| `esign-initialize` | POST `/api/v1/esign/initialize` | Confirmed `file_id`, `full_name`, `mobile`, `email`, document-specific `positions` | Reuses the RC11 NSDL contract with `sign_type: aadhaar`, `pdf_pre_uploaded: true`, `skip_otp: false`; returns a pending session and protected signing URL. |
| `esign-document` | GET `/api/v1/esign/get-signed-document/{client_id}` | Existing `client_id` | Returns protected document metadata only; does not itself prove that an executed PDF was stored or delivered. |

No standalone Aadhaar OTP generate/submit operation is enabled: the supplied active list does not subscribe to it. Aadhaar verification uses the subscribed DigiLocker product. An OTP step within a supported eSign flow is distinct from a standalone Aadhaar verification subscription.

## Server configuration

Set `DBCL_SUREPASS_TOKEN` in server environment or as a constant in protected WordPress configuration. Do not commit a token, put it in a shortcode, send it from JavaScript, or paste it into support logs. An encrypted `dbcl_surepass_token` option is also supported through the plugin's `Crypto` service. Secrets are not migrated from the older plugin automatically.

`dbcl_settings.surepass_environment` selects `sandbox` (default) or `production`. Production uses `https://kyc-api.surepass.app`, matching the supplied RC11 plugin. Sandbox uses `https://sandbox.surepass.app`, as confirmed by the official DigiBoost SDK repository README (HEAD `1466a72`, inspected during development). The older RC11 also allowed a legacy `.io` sandbox host; this implementation uses the current documented `.app` sandbox destination. No automatic host fallback is performed for billable enquiries. Configure the runtime network policy to permit the selected destination before live testing. Browser DigiLocker also requires its approved SDK and Surepass/DigiLocker destinations.

`Providers::request($operation, $payload, $context)` requires recorded consent plus application and party IDs. The calling controller must authorize access to those exact records. Bank and PAN verification should pass the party's legal name in `context.expected_name`; missing or uncertain name matching gives `review_required`, not `verified`.

Additional subscribed operations require a confirmed mapping in `dbcl_settings.surepass_mappings[operation]`. A mapping contains:

- `confirmed`: strict boolean `true` after checking the current Surepass contract.
- `path`: a relative `/api/v1/...` path with no query, credentials, hostname, or traversal.
- `method`: `POST`, or reference-only `GET` follow-up.
- `field_map`: application input name → provider field name; dotted provider names create nested objects.
- `required_fields`: required application input names, all mapped explicitly.
- `fixed_values`: optional non-secret scalar values required by the provider contract.
- For GET follow-ups, `reference_input` and `reference_prefix`; only a provider reference is appended to the path. Identity data never enters a query string.
- For custom responses, `verdict_path` and exact typed `verified_values`, `failed_values`, `pending_values`. HTTP 200 or `success: true` alone does not verify an identity.
- Optional `reference_path` (default `data.client_id`) and `redirect_path`. Returned action URLs are accepted only on HTTPS Surepass, DigiLocker, or MeriPehchaan domains.

Do not use `success` as a verification verdict: it can mean that a request was accepted. Response contracts must distinguish initiation, pending work, a valid identity, mismatch, and rejection. The built-in normalizers enforce the recovered RC11 identity checks. Ambiguous results remain `review_required`; a transport timeout remains unknown and must be reconciled before repeating a paid request.

Built-in PAN/bank/DigiLocker/eSign normalizers cannot be removed through configuration. Transport-only fields such as `success` and `status_code` cannot become custom verification verdicts. Bank and PAN field mappings retain the source-confirmed identity field binding; signing retains its uploaded-file, signer-contact, coordinate and mandatory authorization bindings. DigiLocker compares returned DOB and masked Aadhaar against the typed party data when present. A verified result must have a correlation reference, and eSign status must explicitly echo the same client ID.

The provider boundary forwards only explicitly mapped input fields. It enforces TLS validation, disables redirects, limits response size, and returns generic errors without the raw provider response. It does not persist payloads. The controller must reserve paid attempts before calling it, rate-limit user requests, and save normalized evidence against the relevant party. The DigiLocker `sdk_token` is a scoped browser session credential; deliver it only to the authorized session, keep it out of audit logs and exports, and never confuse it with the server API key.

For the source-proven document-first eSign sequence, `Providers::upload_esign_document($accepted_pdf, $context)` sends a binary multipart PDF to production `/api/v1/files/esign/upload`. It requires a confirmed `uploaded: true` response and a `files_...` reference before initialize. The controller must bind that file ID and SHA256 to the exact accepted document and signer; a typed file ID alone is not evidence of an upload. Signing positions must come from the actual approved PDF, not sample coordinates. A returned signing URL is restricted to Surepass-hosted sites or the source-approved exact `esign-client.aadhaarkyc.io` host, and is private.

After confirmed signing, `Providers::download_signed_document($client_id, $context)` rechecks status, retrieves metadata, accepts only HTTPS S3 destinations from the source contract, downloads without forwarding the Surepass Bearer credential, and validates the PDF magic and size. Its returned `pdf` bytes must be stored immediately through the encrypted document service; never put them, the temporary URL, or SDK/signing tokens into audit payloads or ordinary JSON exports. The application's own signed-document hash, authorized signer matrix and delivery records remain separate controls.

The dedicated signature centre implements that lifecycle at `GET/POST /digitalbe-loans/v1/applications/{id}/esign` and multipart `POST .../esign/documents`. An operations officer uploads an approved PDF with purpose, party role, actual positions and an approval reference. Independently accepted current terms and current eSign/data-processing consent are prerequisites. Accounts acting as a case party cannot approve their own source even if they also have a staff role. Only the independently signed-in signer begins signing or receives the private hosted link; authorized operations staff may poll provider status.

The centre reserves upload and initialize phases durably before network calls and holds uncertain outcomes for reconciliation. It pins the source PDF SHA256, party/contact profile, approved template version, obligation and accepted terms hash. Material changes hide obsolete signing links and prevent stale execution evidence from satisfying current gates. Provider completion is applied only after actual executed-PDF retrieval and encrypted artifact storage. All signature evidence uses the original pinned terms hash; a delayed event cannot silently inherit a newer terms version.

An unscanned source stays `SOURCE_REVIEW_REQUIRED` unless the configured scanner returns `CLEAN` or the explicitly enabled manual-review policy is satisfied. Staff can POST `action: review_source`, the session ID, current `expected_version`, and—when permitted—`review_confirmed: true` plus an approval reference after configuring scanning/review. Manual review is recorded as operator attestation, never as a clean scanner result. An infected source remains blocked through later scanner outages; only an actual clean scanner result can clear that condition. This reviews the same immutable encrypted PDF, without another provider call.

## eNACH, payment, BC, eSign, and communication extensions

AU Bank's eNACH contract has not been supplied. No bank mandate or debit endpoint is guessed. `Providers::external()` exposes the `dbcl_provider_request` filter for a separately installed authenticated adapter. Supported adapter types are `enach`, `payment`, `bc`, `esign`, and `communication`. Without an adapter, requests return `provider_not_configured`. eNACH/payment additionally require the approved financial-operation configuration. This filter alone does not establish provider certification, settlement or customer authorization.

An adapter must bind each mandate/payment to its actual purpose, account, entity and record. The initial loan, separate return collection, initial lender repayment, final BC loan, and SLT contribution cannot reuse one another's authorizations or settlement records. An unknown submission result must be reconciled before a new request. A mandate registration is not a debit and an initiation acknowledgement is not settlement.

`Providers::verify_callback()` provides an **extension callback convention**, not a representation of AU Bank's eventual signature format:

```
signature = hex(HMAC-SHA256(secret, timestamp + "." + event_id + "." + exact_raw_request_body))
```

The controller supplies the raw bytes, hex signature (optionally prefixed `sha256=`), Unix timestamp, and event ID. Configure `DBCL_WEBHOOK_SECRET` as a protected server secret, or its encrypted option. Verification uses constant-time comparison and a five-minute timestamp window. The controller must also durably deduplicate event IDs, check record/reference/amount/currency/purpose matches, reject invalid state transitions, and perform transactional reconciliation. Do not expose a callback before the concrete provider's authentication scheme has been implemented and tested.

## Live validation still required

Use the selected provider sandbox first, then separately authorized production acceptance tests. Verify each enabled subscription and schema, confirmed party-specific consents, mismatched identities, bank beneficiary matching, incomplete DigiLocker sessions, duplicate requests, expired/forged callbacks, replay handling, timeouts, provider failures, and encrypted evidence storage. Test eSign's executed-document delivery separately from signing status. Test eNACH registration, due-date authorization, debit and settlement only after the actual provider contract is supplied.

No paid enquiry, external communication, mandate, debit, or payment was sent while developing these adapters.
