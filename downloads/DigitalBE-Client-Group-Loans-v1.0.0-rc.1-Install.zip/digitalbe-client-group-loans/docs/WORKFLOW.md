# Client and group workflow

The WordPress REST namespace is `digitalbe-loans/v1`. The command registry is `DigitalBE\ClientGroupLoans\Workflow::specs()`. Its field descriptions are consumed by the operations interface. A command has one capability, fixed allowed values, required evidence and server-side gates. There is no unrestricted status-update command.

## Case and party records

An application has an application UUID, group UUID, organization, branch, owner, current version, assigned credit officer and a frozen product-policy version. Every party has its own UUID, authenticated WordPress user ID, declared profile, original-document versions, purpose-specific consent, provider KYC results and bank account. The four roles are `applicant`, `co_applicant`, `guarantor_1` and `guarantor_2`.

`profile`, `consent`, `documents`, invitation and KYC endpoints are implemented by the API layer. A client cannot act as another party to accept terms, acknowledge counselling or authorize a mandate. Staff-assisted data entry does not substitute for individual acceptance.

Document capture and review can proceed before external KYC is configured. Accepted mandatory documents and a verified identity result for every party are required before assignment and BC enrolment. Identity KYC is an actual provider result with `status: verified` and a provider reference, normally PAN Advanced V3 or a verified DigiLocker document download. A redirect or session initialization is not KYC success. Policy can require additional operations. `profile_hash` binds each result to the verified profile. API material-change invalidation clears stale KYC, acceptance and signatures; current bank hashes independently invalidate bank verification and mandates.

Cases retain their Surepass environment in the policy snapshot. Sandbox verification supports sandbox UAT only. A production policy accepts identity results only when the provider evidence explicitly records `environment: production`; verified sandbox or legacy untagged results cannot become live KYC by changing settings. Production bank gates likewise require production-tagged verification, or an explicitly permitted manual bank review with `source: OFFICER_REPORTED` and authoritative evidence. A manual review keeps its honest source/environment labels and is never described as production-provider verification. Switching policy environments requires fresh affected checks; sandbox success does not establish live provider readiness.

Original-document observation and malware status remain separate. A clean scan cannot prove originality. Review retains prior versions and records correction/rejection reasons. Accepting unscanned evidence requires an explicit reviewed product setting.

## Journey and command groups

| Stage | Commands | Required authority/evidence |
| --- | --- | --- |
| Group submission | `submit_documents` | Applicant; four complete profiles, original-document checklist and processing consents |
| Document review | `review_document` | `dbcl_review`; item-specific decision, original observation, reason and permitted scan state |
| Assignment | `assign_officer` | `dbcl_assign`; accepted group documents and identity KYC; API validates target staff scope |
| Bank ownership | `record_bank_verification` or provider KYC endpoint | Current account/IFSC hash, actual verification reference; source explicitly labeled |
| BC enrolment | `record_bc_enrolment` | `dbcl_review`; partner, external reference, response and evidence; pending is not rejection |
| Counselling | `schedule_counselling`, `complete_counselling`, `acknowledge_counselling` | BC eligibility pass; Google Meet reference, four attendees, disclosures and each party's own acknowledgement |
| Initial and BC terms | `set_loan_terms`, `accept_terms` | Actual lender, actual borrower allocation, accepted version, amount/charges/repayment and beneficiary |
| Document execution | `record_signature` | `dbcl_operate`; mandatory exact `terms_hash`, immutable executed-document hash, individual signer and external evidence |
| Mandate registration | `prepare_mandate`, `accept_mandate`, `record_mandate` | Purpose-bound obligation, verified payer account, exact payer authorization, mandatory current `mandate_id`, external result and evidence |
| Mandate withdrawal | `withdraw_mandate` | Named payer's own authenticated party, exact current mandate ID and reason; locally blocks use immediately while external cancellation remains unconfirmed |
| Separate return | `set_return_collection` and finance commands | Exactly INR 10,000, named recipient, contractual purpose, verified bank reference and separate acceptance |
| SLT membership | `set_slt_terms`, `accept_terms`, `record_signature` | Shubh Labh Trust; exactly INR 25,000, separate terms, payer and membership execution |
| FVR/BVR | `assign_verification`, `record_verification` | Assigned officer, checklist answers, distinct completed task and PASS/FAIL result |
| BC queries | `open_query`, `respond_query`, `close_query` | One record per query; response is not closure; partner closure evidence required |
| DB kit | `prepare_kit`, `submit_kit`, `accept_kit` | All required gates, immutable snapshot/hash, exact pack version and partner acceptance |
| Finance | `prepare_payment`, `check_payment`, `record_submission`, `record_settlement` | Frozen purpose/amount/beneficiary, independent checker, bank/lender reconciliation |
| Initial closure | `close_initial_loan` | Separately reconciled lender repayment, zero lender balance and lender/LMS closure evidence |
| SLT notice | `record_slt_notice` | Actual notice delivery time/reference/evidence matching accepted SLT terms |
| Reversals | `record_reversal` | Original settled instruction, independent checker, linked amount and bank evidence |
| Exceptions | `set_exception` | Supervisor capability and reason; clearing a hold never overrides a missing business gate |

The `gate-evaluation` representation is included in application reads as `gates`. Each key has `passed` and a list of stable blocker codes. Stages are derived from those components; they are a summary and never proof of an external event.

The DB kit hashes party profiles/documents/KYC, bank fingerprints, accepted terms/signatures, mandates, BC approval, counselling, verifications and queries. A changed input makes acceptance stale. Executed versions and settled events are retained rather than edited.

## Independent obligations and ledgers

| Purpose | Obligation | Amount | Meaning |
| --- | --- | --- | --- |
| `initial_disbursement` | `loans.initial.id` | INR 10,000 | Actual initial loan disbursement to its verified borrower beneficiary |
| `initial_repayment` | Same initial loan, separate `repayment` ledger | Up to initial principal outstanding per instruction | Repayment to the actual lender's verified receiving account; lender closure is a separate event |
| `return_collection` | `return_collection.id` | INR 10,000 total | Separate receiving entity and accepted contractual purpose; partial settlement remains partial |
| `bc_disbursement` | `loans.bc.id` | Accepted net BC disbursement | Independent final BC loan and beneficiary |
| `slt_contribution` | `slt.id` | INR 25,000, one time | Separate trust contribution; no netting against the return |

Return collection never posts lender repayment. The INR 10,000 return and INR 25,000 SLT contribution remain distinct, totaling INR 35,000 in proposed collections. They never become a INR 15,000 contribution. A group does not create four initial loans: actual borrower allocation must sum to the single recorded loan principal.

The initial disbursement and initial repayment share an obligation ID but have separate ledger kinds. `Workflow::settled_total($loan)` reads disbursement; `Workflow::settled_total($loan, 'repayment')` reads lender repayment. Closure additionally needs authoritative lender evidence. The policy's `initial_closure_required` controls whether that closure blocks the final BC loan; it does not infer closure from a return receipt.

## Mandate authorization withdrawal

The named payer can request withdrawal for their initial-loan, BC-loan or SLT mandate using `withdraw_mandate`, with `purpose`, the exact `mandate_id` and a reason. Another group party or a staff member cannot substitute their session for this request. The command records the payer, reason, request timestamp and history, changes the effective state to `WITHDRAWAL_REQUESTED`, and preserves the last recorded `provider_status`. A locally prepared mandate with no external submission is explicitly `NOT_SUBMITTED` at the provider layer. The request never claims that a bank or provider has already cancelled the mandate.

The withdrawal marker immediately blocks new dependent instructions, approvals and submissions, even if a stale status flag says ACTIVE. Repeating the request preserves its original timestamp and one history entry. Stale ACTIVE or PENDING provider results and repeat consent on the original mandate ID cannot restore authorization. Staff may record an evidence-backed CANCELLED result; replacing the registration requires that confirmation, a new mandate ID and fresh independent payer acceptance. Cancelled, rejected and failed mandate records cannot be reopened through PENDING or ACTIVE; they need a new registration.

Withdrawal does not undo money movement. Existing in-flight or unknown instructions must still be reconciled against bank/provider evidence, and a settled event, initial lender closure or historical receipt is never rewritten. The withdrawal affects future authorization and remains separately visible from settlement and provider cancellation.

`record_mandate` requires the exact currently registered `mandate_id`; an ACTIVE or CANCELLED callback for an older registration returns a conflict and cannot change its replacement. Verified callback adapters must provide that correlated internal registration ID from their pinned mapping, not infer it from the latest purpose. `record_signature` similarly requires the exact executed `terms_hash`; a delayed signature of an older document cannot sign a newly accepted terms version. The eSign session supplies its pinned terms hash. Neither a callback nor a manual evidence action may infer the signed version from whichever terms happen to be current.

## Finance state and duplicate controls

New instructions are disabled by default. Enabling approved configuration permits recording controlled external instructions; no Workflow command calls a bank or eNACH API. AU Bank/eNACH execution remains adapter-dependent until its actual contract, credentials and verification rules are supplied.

A prepared instruction freezes amount, obligation, beneficiary, terms hash, idempotency key and maker. A different checker must approve it. Submission is recorded separately and remains `SUBMITTED` or `UNKNOWN`, without a receipt or ledger credit. The incoming settlement command remains available while new financial submissions are suspended so operations can reconcile in-flight payments.

A settlement matches exact amount, INR currency, instruction ID, receiving account and unique authoritative reference. `settled_at` is the actual bank value/settlement date, never the date the officer entered the record. Manual evidence is labeled `OFFICER_REPORTED`; only a verified provider actor produces `PROVIDER_CONFIRMED`. Screenshot/notes observations can be recorded with `record_financial_observation`; observations do not satisfy settlement gates.

Idempotency keys are application-wide and bind the financial payload. Reusing one with different details returns a conflict. An in-flight or unknown instruction blocks another attempt. A successful settlement is immutable. Duplicate settlement callbacks cannot add another ledger entry. Reversals retain the original settled record and receipt and append a separate reversal entry/notice.

The SLT instruction gate additionally requires:

1. Confirmed final BC disbursement.
2. Accepted separate SLT membership terms and execution evidence.
3. An active separately authorized one-time INR 25,000 mandate for this obligation, current payer account and exact beneficiary.
4. Authorized due date reached, valid mandate window and delivered notice for the required notice interval.
5. No outstanding/unknown attempt, no previous successful contribution and no reversal requiring review.

Application storage uses optimistic versions and a database transaction to persist the aggregate, audit event and outbox event. Two concurrent financial commands cannot both claim the same expected version. This is a guard around local state; a provider adapter must still use its own idempotency and reconciliation contract when network execution is introduced.

## Command request example

```json
{
  "expected_version": 42,
  "command": "record_settlement",
  "input": {
    "purpose": "return_collection",
    "instruction_id": "00000000-0000-4000-8000-000000000001",
    "result": "SETTLED",
    "amount_paise": 1000000,
    "currency": "INR",
    "beneficiary_ref": "approved-return-bank-reference",
    "settled_at": "2026-10-26T09:00:00Z",
    "payment_mode": "NEFT",
    "reference": "authoritative-bank-utr",
    "evidence_ref": "private-bank-statement-evidence-id"
  }
}
```

Send this body to `POST /wp-json/digitalbe-loans/v1/applications/{id}/commands` using WordPress authentication and a REST nonce. Synthetic examples are not executable payment instructions. API access checks additionally enforce organization, branch, assignment, role and independent-party ownership. A stale `expected_version` returns a conflict; refresh the current case rather than overwriting another actor's work.

Receipts are frozen in `case.receipts` only at settlement. Select the actual receipt/instruction when printing. `case.reversal_notices` links later bank reversals to the original receipt. Neither mandate registration nor a pending payment gets a settlement receipt.

## Pending release configuration

The implementation preserves the confirmed financial boundaries while the following remain deployment-specific: lender and BC agreements; actual borrower allocation and approved terms; named return recipient/purpose; SLT membership/notice/refund terms; FVR/BVR definitions/checklists; approved document templates/signers; eSign/eNACH/payment/OTP contracts; verified MFA and mobile identity integration; malware scanning; retention and recovery targets. Unconfigured external services remain pending or fail closed. They do not fabricate eligibility, signatures, mandates, identity verification or payments.
