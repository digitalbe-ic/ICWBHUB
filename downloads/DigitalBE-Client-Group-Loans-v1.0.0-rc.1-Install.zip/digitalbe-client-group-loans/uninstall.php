<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
// Financial, consent and evidence records are deliberately retained. An approved
// retention/export/deletion process must run before destructive data removal.
wp_clear_scheduled_hook('dbcl_daily_tasks');
