<?php
namespace DigitalBE\ClientGroupLoans;

if (!defined('ABSPATH')) {
    exit;
}

/** Shared, authenticated applicant portal and staff workspace. */
final class UI
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_shortcode('digitalbe_client_group_loans', [self::class, 'shortcode']);
    }

    public static function menu(): void
    {
        add_menu_page(__('digital BE Loans', 'digitalbe-client-group-loans'), __('digital BE Loans', 'digitalbe-client-group-loans'), 'read', 'dbcl-workspace', [self::class, 'workspace'], 'dashicons-groups', 27);
        add_submenu_page('dbcl-workspace', __('Loan configuration', 'digitalbe-client-group-loans'), __('Configuration', 'digitalbe-client-group-loans'), 'manage_options', 'dbcl-settings', [self::class, 'settings']);
    }

    public static function workspace(): void
    {
        if (!current_user_can('read')) {
            wp_die(esc_html__('Please sign in to access your loan workspace.', 'digitalbe-client-group-loans'));
        }
        echo '<div class="wrap">' . self::mount('workspace') . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped static mount.
    }

    public static function settings(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You cannot edit loan configuration.', 'digitalbe-client-group-loans'));
        }
        echo '<div class="wrap">' . self::mount('settings') . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    public static function shortcode(): string
    {
        if (!is_user_logged_in()) {
            return '<section class="dbcl-login"><h2>' . esc_html__('Client and Group Loan Application', 'digitalbe-client-group-loans') . '</h2><p>' . esc_html__('Sign in with your own WordPress account to access your application or claim a participant invitation. Each participant must sign in separately.', 'digitalbe-client-group-loans') . '</p>' . wp_login_form(['echo' => false, 'remember' => false]) . '</section>';
        }
        return self::mount('workspace');
    }

    private static function mount(string $view): string
    {
        self::enqueue();
        return '<div id="dbcl-app" data-view="' . esc_attr($view) . '"><p role="status">' . esc_html__('Loading your secure loan workspace…', 'digitalbe-client-group-loans') . '</p><noscript>' . esc_html__('JavaScript is required to use this loan workspace.', 'digitalbe-client-group-loans') . '</noscript></div>';
    }

    private static function enqueue(): void
    {
        $root = dirname(__DIR__);
        $entry = $root . '/digitalbe-client-group-loans.php';
        wp_enqueue_style('dbcl-app', plugins_url('assets/app.css', $entry), [], (string) filemtime($root . '/assets/app.css'));
        wp_enqueue_script('dbcl-app', plugins_url('assets/app.js', $entry), [], (string) filemtime($root . '/assets/app.js'), true);
        $user = wp_get_current_user();
        $caps = array_keys(array_filter((array) $user->allcaps));
        $staff = current_user_can('manage_options');
        foreach (['dbcl_review', 'dbcl_assign', 'dbcl_verify', 'dbcl_operate', 'dbcl_finance_make', 'dbcl_finance_check', 'dbcl_audit'] as $cap) {
            $staff = $staff || current_user_can($cap);
        }
        wp_localize_script('dbcl-app', 'DBCL', [
            'root' => esc_url_raw(rest_url('digitalbe-loans/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'user' => ['id' => get_current_user_id(), 'name' => $user->display_name, 'staff' => $staff, 'capabilities' => $caps, 'configure' => current_user_can('manage_options')],
            'schema' => Documents::schema(),
            'commands' => Workflow::specs(),
            'catalog' => Providers::catalog(),
            'loginUrl' => wp_login_url(),
            'workspaceUrl' => admin_url('admin.php?page=dbcl-workspace'),
        ]);
    }
}
