<?php
/** Server-side provider boundaries. No provider response body is persisted here. */
namespace DigitalBE\ClientGroupLoans;

defined('ABSPATH') || exit;

final class Providers
{
    /** Active subscriptions supplied in surepass_apis_active-Status 181026.csv. */
    public static function products(): array
    {
        return [
            'ocr-aadhaar-masking' => 'Aadhaar Masking',
            'address-comparator' => 'AI Address Match',
            'bank-verification' => 'Bank Verification',
            'bulk' => 'Bulk',
            'credit-report-cibil-pdf' => 'Credit Report CIBIL PDF',
            'credit-report-crif-pdf' => 'Credit Report CRIF PDF',
            'credit-report-experian-pdf' => 'Credit Report Experian PDF',
            'digilocker' => 'DigiLocker (link / web SDK)',
            'credit-report' => 'Equifax Credit Report',
            'credit-report-pdf' => 'Equifax Credit Report PDF',
            'esign' => 'eSign / eStamp',
            'face-liveness-v6' => 'Face Liveness V6',
            'face-match' => 'Face Match',
            'bank-verification-find-ifsc' => 'Find IFSC',
            'pan-advanced-v2' => 'PAN Advanced V2',
            'pan-advanced' => 'PAN Advanced',
            'pan-advanced-v3' => 'PAN Advanced V3',
            'reverse-penny-drop' => 'Reverse Penny Drop',
            'voter-id-text' => 'Voter ID Text',
        ];
    }

    /** Product codes are not endpoint paths. Multi-step products need separate mappings. */
    public static function catalog(): array
    {
        $catalog = [];
        foreach (self::products() as $code => $name) {
            $catalog[$code] = ['label' => $name, 'product' => $code, 'configured_by_default' => false];
        }
        foreach ([
            'digilocker-initialize' => ['DigiLocker: initialize', 'digilocker'],
            'digilocker-status' => ['DigiLocker: status', 'digilocker'],
            'digilocker-documents' => ['DigiLocker: list documents', 'digilocker'],
            'digilocker-download' => ['DigiLocker: download document', 'digilocker'],
            'esign-initialize' => ['eSign: initialize', 'esign'],
            'esign-status' => ['eSign: status', 'esign'],
            'esign-document' => ['eSign: signed document metadata', 'esign'],
            'esign-stamp' => ['eStamp', 'esign'],
        ] as $operation => $entry) {
            $catalog[$operation] = ['label' => $entry[0], 'product' => $entry[1], 'configured_by_default' => false];
        }
        return $catalog;
    }

    /** Contracts recovered from the user-supplied RC11 Loan Engine, not invented routes. */
    public static function default_mappings(): array
    {
        $source = 'DigitalBE Loan Engine 2.1.10 RC11 source; current credentials not live-tested';
        $digilocker = ['confirmed' => true, 'path' => '/api/v1/digilocker/initialize', 'field_map' => [], 'fixed_values' => ['data.signup_flow' => true, 'data.skip_main_screen' => false], 'required_fields' => [], 'normalizer' => 'digilocker-initialize', 'source' => $source];
        return [
            'bank-verification' => ['confirmed' => true, 'path' => '/api/v1/bank-verification/', 'field_map' => ['account_number' => 'id_number', 'ifsc' => 'ifsc'], 'fixed_values' => ['ifsc_details' => true], 'required_fields' => ['account_number', 'ifsc'], 'normalizer' => 'bank', 'source' => $source],
            'pan-advanced-v3' => ['confirmed' => true, 'path' => '/api/v1/pan/pan-adv', 'field_map' => ['pan' => 'id_number'], 'required_fields' => ['pan'], 'normalizer' => 'pan', 'source' => $source],
            'digilocker' => $digilocker,
            'digilocker-initialize' => $digilocker,
            'digilocker-download' => ['confirmed' => true, 'path' => '/api/v1/digilocker/download-aadhaar/', 'method' => 'GET', 'reference_input' => 'client_id', 'reference_prefix' => 'digilocker_', 'field_map' => [], 'required_fields' => [], 'normalizer' => 'digilocker-download', 'source' => $source],
            'credit-report' => ['confirmed' => true, 'path' => '/api/v1/credit-report-v2/fetch-report', 'production_only' => true, 'field_map' => ['name' => 'name', 'pan' => 'id_number', 'mobile' => 'mobile', 'gender' => 'gender'], 'fixed_values' => ['id_type' => 'pan', 'consent' => 'Y'], 'required_fields' => ['name', 'pan', 'mobile', 'gender'], 'normalizer' => 'equifax', 'consent_purpose' => 'credit_bureau', 'source' => $source],
            'esign-status' => ['confirmed' => true, 'path' => '/api/v1/esign/status/', 'method' => 'GET', 'reference_input' => 'client_id', 'reference_prefix' => 'esign_', 'field_map' => [], 'required_fields' => [], 'normalizer' => 'esign-status', 'consent_purpose' => 'esign', 'source' => $source],
            'esign-initialize' => ['confirmed' => true, 'path' => '/api/v1/esign/initialize', 'field_map' => ['file_id' => 'file_id', 'full_name' => 'prefill_options.full_name', 'mobile' => 'prefill_options.mobile_number', 'email' => 'prefill_options.user_email', 'positions' => 'config.positions'], 'fixed_values' => ['pdf_pre_uploaded' => true, 'sign_type' => 'aadhaar', 'config.reason' => 'Loan agreement acceptance', 'config.accept_virtual_sign' => false, 'config.skip_otp' => false, 'config.allow_download' => true], 'required_fields' => ['file_id', 'full_name', 'mobile', 'email', 'positions'], 'normalizer' => 'esign-initialize', 'consent_purpose' => 'esign', 'redirect_path' => 'data.url', 'source' => $source],
            'esign-document' => ['confirmed' => true, 'path' => '/api/v1/esign/get-signed-document/', 'method' => 'GET', 'reference_input' => 'client_id', 'reference_prefix' => 'esign_', 'field_map' => [], 'required_fields' => [], 'normalizer' => 'esign-document', 'consent_purpose' => 'esign', 'source' => $source],
        ];
    }

    /**
     * Request a subscribed Surepass operation with an operator-confirmed API contract.
     * The controller must check object access; this boundary independently checks consent.
     * A successful HTTP response is never itself a verified KYC result.
     */
    public static function request(string $operation, array $payload, array $context = []): array|\WP_Error
    {
        $catalog = self::catalog();
        if (!isset($catalog[$operation])) {
            return self::error('surepass_operation_unavailable', 'This Surepass operation is not in the supplied active API list.', 400);
        }
        if (($context['consent'] ?? false) !== true || !self::valid_object_id($context['party_id'] ?? null) || !self::valid_object_id($context['application_id'] ?? null)) {
            return self::error('surepass_consent_required', 'Recorded, purpose-specific party consent is required before verification.', 403);
        }
        $settings = self::settings($context);
        $mapping = $settings['surepass_mappings'][$operation] ?? self::default_mappings()[$operation] ?? null;
        if (!is_array($mapping) || ($mapping['confirmed'] ?? false) !== true) {
            return self::error('surepass_mapping_required', 'Confirm this operation against your current Surepass API documentation before enabling it.', 409);
        }
        // Mapping edits cannot turn a transport acknowledgement into an identity verdict.
        $normalizer = self::normalizer_for($operation, $mapping);
        if (($normalizer === 'bank' && (($mapping['field_map']['account_number'] ?? '') !== 'id_number' || ($mapping['field_map']['ifsc'] ?? '') !== 'ifsc')) || ($normalizer === 'pan' && ($mapping['field_map']['pan'] ?? '') !== 'id_number')) {
            return self::error('surepass_identity_contract_invalid', 'The identity input must remain bound to the recovered provider field names. Use a reviewed adapter for a different request schema.', 409);
        }
        if (str_starts_with($operation, 'esign-')) {
            $known = self::default_mappings()[$operation] ?? null;
            if (is_array($known) && (($mapping['path'] ?? '') !== $known['path'] || strtoupper((string) ($mapping['method'] ?? 'POST')) !== ($known['method'] ?? 'POST'))) {
                return self::error('surepass_esign_contract_invalid', 'The document-bound eSign service requires its recovered endpoint contract. Configure a separately reviewed adapter for another contract.', 409);
            }
            if ($operation === 'esign-initialize' && (($mapping['fixed_values']['pdf_pre_uploaded'] ?? null) !== true || ($mapping['fixed_values']['sign_type'] ?? '') !== 'aadhaar' || ($mapping['fixed_values']['config.skip_otp'] ?? null) !== false || ($mapping['fixed_values']['config.accept_virtual_sign'] ?? null) !== false || ($mapping['field_map']['file_id'] ?? '') !== 'file_id' || ($mapping['field_map']['positions'] ?? '') !== 'config.positions' || ($mapping['field_map']['full_name'] ?? '') !== 'prefill_options.full_name' || ($mapping['field_map']['mobile'] ?? '') !== 'prefill_options.mobile_number' || ($mapping['field_map']['email'] ?? '') !== 'prefill_options.user_email')) {
                return self::error('surepass_esign_contract_invalid', 'Signing must use the confirmed uploaded PDF, actual positions, and mandatory provider authorization. No request was sent.', 409);
            }
        }
        $path = $mapping['path'] ?? '';
        if (!is_string($path) || !preg_match('#^/api/v[1-9][0-9]*/[A-Za-z0-9_/-]+$#D', $path)) {
            return self::error('surepass_invalid_path', 'A confirmed relative Surepass API path is required.', 400);
        }
        $environment = $settings['surepass_environment'] ?? 'sandbox';
        $hosts = ['sandbox' => 'sandbox.surepass.app', 'production' => 'kyc-api.surepass.app'];
        if (!isset($hosts[$environment])) {
            return self::error('surepass_invalid_environment', 'Select sandbox or production for Surepass.', 400);
        }
        if (!empty($mapping['production_only']) && $environment !== 'production') {
            return self::error('surepass_production_required', 'This recovered provider contract supports production only; no fallback enquiry will be sent.', 409);
        }
        if (!empty($mapping['consent_purpose']) && ($context['consent_purpose'] ?? '') !== $mapping['consent_purpose']) {
            return self::error('surepass_specific_consent_required', 'This operation requires its separately recorded purpose-specific consent.', 403);
        }
        $method = strtoupper((string) ($mapping['method'] ?? 'POST'));
        if (!in_array($method, ['POST', 'GET'], true) || ($method === 'GET' && empty($mapping['reference_input']))) {
            return self::error('surepass_unsupported_method', 'Use POST or a confirmed GET follow-up with a provider reference in the path; identity data must not be placed in query strings.', 400);
        }
        $requestReference = '';
        if ($method === 'GET') {
            $requestReference = $payload[$mapping['reference_input']] ?? '';
            $prefix = $mapping['reference_prefix'] ?? '';
            if (!is_string($requestReference) || !preg_match('/^[A-Za-z0-9_-]{5,128}$/D', $requestReference) || !is_string($prefix) || $prefix === '' || !str_starts_with($requestReference, $prefix)) {
                return self::error('surepass_reference_invalid', 'The saved provider session reference is invalid.', 400);
            }
            $path = rtrim($path, '/') . '/' . $requestReference;
        }
        $token = self::secret('DBCL_SUREPASS_TOKEN', 'dbcl_surepass_token');
        if (is_wp_error($token)) {
            return $token;
        }
        $validation = self::validate_known_inputs($normalizer, $payload);
        if (is_wp_error($validation)) {
            return $validation;
        }
        $body = $method === 'POST' ? self::map_payload($payload, $mapping) : [];
        if (is_wp_error($body)) {
            return $body;
        }
        $json = wp_json_encode($body);
        if (!is_string($json) || strlen($json) > 2 * 1024 * 1024) {
            return self::error('surepass_payload_invalid', 'The verification payload is invalid or exceeds the two-megabyte limit.', 400);
        }
        $args = [
            'method' => $method,
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'data_format' => 'body',
            'timeout' => 35,
            'redirection' => 0,
            'sslverify' => true,
            'limit_response_size' => 2 * 1024 * 1024,
        ];
        if ($method === 'POST') {
            $args['body'] = $json;
        }
        $response = wp_safe_remote_request('https://' . $hosts[$environment] . $path, $args);
        if (is_wp_error($response)) {
            // Transport messages may contain URLs or payload fragments; never relay them.
            return self::error('surepass_transport_unknown', 'The provider request outcome is unknown. Reconcile the existing attempt before any paid retry; no automatic retry was made.', 502);
        }
        $http = (int) wp_remote_retrieve_response_code($response);
        if ($http < 200 || $http >= 300) {
            $code = in_array($http, [401, 403], true) ? 'surepass_access_denied' : 'surepass_provider_error';
            return self::error($code, 'Surepass did not accept this verification request. Check credentials, subscription, and the confirmed API mapping.', 502, ['provider_http_status' => $http]);
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
            return self::error('surepass_invalid_response', 'Surepass returned an unreadable response. Verification remains incomplete.', 502);
        }
        $status = 'review_required';
        if (($data['success'] ?? null) === false) {
            $status = 'failed';
        } elseif (!empty($mapping['verdict_path']) && is_string($mapping['verdict_path']) && !preg_match('/(^|\.)(success|status_code|http_status)$/iD', $mapping['verdict_path'])) {
            $verdict = self::at($data, $mapping['verdict_path']);
            if ($verdict !== null && self::matches($verdict, $mapping['verified_values'] ?? [])) {
                $status = 'verified';
            } elseif ($verdict !== null && self::matches($verdict, $mapping['failed_values'] ?? [])) {
                $status = 'failed';
            } elseif ($verdict !== null && self::matches($verdict, $mapping['pending_values'] ?? [])) {
                $status = 'pending';
            }
        }
        if ($normalizer !== '') {
            $status = self::known_verdict($normalizer, $data, $payload, $context);
        }
        $referencePath = (string) ($mapping['reference_path'] ?? 'data.client_id');
        $reference = self::safe_reference(self::at($data, $referencePath));
        $echoReference = self::safe_reference($data['data']['client_id'] ?? '');
        if ($requestReference !== '' && $echoReference !== '' && !hash_equals($requestReference, $echoReference)) {
            return self::error('surepass_reference_mismatch', 'The response belongs to a different provider session. Verification remains incomplete.', 502);
        }
        if ($operation === 'esign-status' && $echoReference === '') {
            $status = 'review_required';
        }
        if ($requestReference !== '' && $reference !== '' && !hash_equals($requestReference, $reference)) {
            return self::error('surepass_reference_mismatch', 'The response belongs to a different provider session. Verification remains incomplete.', 502);
        }
        if ($reference === '' && $requestReference !== '') {
            $reference = $requestReference;
        }
        if ($status === 'verified' && $reference === '') {
            $status = 'review_required';
        }
        $result = [
            'provider' => 'surepass',
            'operation' => $operation,
            'product' => $catalog[$operation]['product'],
            'environment' => $environment,
            'status' => $status,
            'reference' => $reference,
            'checked_at' => gmdate('c'),
            'summary' => $catalog[$operation]['label'] . ': ' . str_replace('_', ' ', $status) . '. Identity details are not included in this summary.',
        ];
        if ($normalizer === 'digilocker-initialize' && $status === 'pending') {
            // Session-scoped SDK credential, not the server Bearer key. Never audit it.
            $result['sdk_token'] = $data['data']['token'];
            $result['sdk_gateway'] = $environment;
        }
        if ($normalizer === 'esign-document' && $status === 'pending') {
            $result['document_url'] = $data['data']['url'];
        }
        // A redirect is an action, never proof of verification. Keep it out of audit logs.
        if (!empty($mapping['redirect_path']) && is_string($mapping['redirect_path'])) {
            $url = self::at($data, $mapping['redirect_path']);
            if (is_string($url) && self::safe_action_url($url)) {
                $result['action_url'] = $url;
            }
        }
        return $result;
    }

    /** Upload the exact accepted PDF before starting an eSign session. No automatic retry. */
    public static function upload_esign_document(string $pdf, array $context): array|\WP_Error
    {
        if (($context['consent'] ?? false) !== true || ($context['consent_purpose'] ?? '') !== 'esign' || !self::valid_object_id($context['application_id'] ?? null) || !self::valid_object_id($context['party_id'] ?? null)) {
            return self::error('esign_consent_required', 'The exact party and document require recorded eSign consent.', 403);
        }
        if ((self::settings($context)['surepass_environment'] ?? 'sandbox') !== 'production') {
            return self::error('esign_production_required', 'The recovered PDF-upload contract supports production only. No request was sent.', 409);
        }
        if (!str_starts_with($pdf, '%PDF-') || strlen($pdf) < 100 || strlen($pdf) > 2500000) {
            return self::error('esign_pdf_invalid', 'The accepted agreement must be a PDF between 100 bytes and 2.5 MB.', 400);
        }
        $token = self::secret('DBCL_SUREPASS_TOKEN', 'dbcl_surepass_token');
        if (is_wp_error($token)) {
            return $token;
        }
        $boundary = '----dbcl' . bin2hex(random_bytes(16));
        $body = '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"file_name\"\r\n\r\nloan-agreement.pdf\r\n";
        $body .= '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"loan-agreement.pdf\"\r\nContent-Type: application/pdf\r\n\r\n" . $pdf . "\r\n--" . $boundary . "--\r\n";
        $response = wp_safe_remote_post('https://kyc-api.surepass.app/api/v1/files/esign/upload', [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json', 'Content-Type' => 'multipart/form-data; boundary=' . $boundary],
            'body' => $body, 'timeout' => 50, 'sslverify' => true, 'redirection' => 0, 'limit_response_size' => 300000,
        ]);
        if (is_wp_error($response)) {
            return self::error('esign_upload_unknown', 'The upload outcome is unknown. Reconcile this attempt before another upload or initialization.', 502);
        }
        $http = (int) wp_remote_retrieve_response_code($response);
        $result = json_decode(wp_remote_retrieve_body($response), true);
        $file = is_array($result) ? ($result['data']['file_id'] ?? '') : '';
        if ($http < 200 || $http >= 300 || !is_array($result) || ($result['success'] ?? null) !== true || (int) ($result['status_code'] ?? 0) !== 200 || ($result['data']['uploaded'] ?? null) !== true || !is_string($file) || !preg_match('/^files_[A-Za-z0-9_-]{5,100}$/D', $file)) {
            return self::error('esign_upload_unconfirmed', 'Surepass did not confirm the accepted PDF upload. Do not initialize signing or retry blindly.', 502);
        }
        return ['provider' => 'surepass', 'operation' => 'esign-upload', 'status' => 'pending', 'reference' => $file, 'sha256' => hash('sha256', $pdf), 'summary' => 'Accepted PDF upload confirmed; no signature is completed.'];
    }

    /** Returns private PDF bytes for immediate encrypted storage, never an audit payload. */
    public static function download_signed_document(string $client_id, array $context): array|\WP_Error
    {
        $status = self::request('esign-status', ['client_id' => $client_id], $context);
        if (is_wp_error($status)) {
            return $status;
        }
        if ($status['status'] !== 'verified') {
            return self::error('esign_not_completed', 'The existing signing session has not been confirmed completed.', 409);
        }
        $metadata = self::request('esign-document', ['client_id' => $client_id], $context);
        if (is_wp_error($metadata)) {
            return $metadata;
        }
        $url = $metadata['document_url'] ?? '';
        if (!is_string($url) || !self::safe_document_url($url)) {
            return self::error('esign_document_unconfirmed', 'Surepass did not return an approved signed-document URL.', 502);
        }
        // Deliberately do not attach the API Bearer key to the signed S3 URL.
        $response = wp_safe_remote_get($url, ['timeout' => 35, 'sslverify' => true, 'redirection' => 0, 'limit_response_size' => 2500001]);
        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
            return self::error('esign_document_download_failed', 'The executed document could not be retrieved. Reconcile the existing signing session.', 502);
        }
        $pdf = wp_remote_retrieve_body($response);
        if (!str_starts_with($pdf, '%PDF-') || strlen($pdf) < 100 || strlen($pdf) > 2500000) {
            return self::error('esign_document_invalid', 'The executed document response was not a valid-size PDF.', 502);
        }
        return ['provider' => 'surepass', 'reference' => $client_id, 'status' => 'verified', 'sha256' => hash('sha256', $pdf), 'pdf' => $pdf, 'summary' => 'Provider completion and executed PDF retrieval confirmed.'];
    }

    /**
     * Optional integration seam. No AU Bank/eNACH/payment endpoint is guessed here.
     * An installed adapter must implement the documented filter and actual provider contract.
     */
    public static function external(string $provider, string $operation, array $payload, array $context = []): array|\WP_Error
    {
        if (!in_array($provider, ['enach', 'bc', 'esign', 'payment', 'communication'], true)) {
            return self::error('provider_unknown', 'This external provider type is unsupported.', 400);
        }
        if (!preg_match('/^[a-z][a-z0-9_-]{0,63}$/D', $operation)) {
            return self::error('provider_operation_invalid', 'A supported provider operation is required.', 400);
        }
        $settings = self::settings($context);
        if (in_array($provider, ['enach', 'payment'], true) && ($settings['financial_operations_enabled'] ?? false) !== true) {
            return self::error('financial_operations_disabled', 'Financial provider operations are disabled until approved product and beneficiary settings are completed.', 409);
        }
        $result = apply_filters('dbcl_provider_request', null, $provider, $operation, $payload, $context);
        if (is_wp_error($result)) {
            return $result;
        }
        if (!is_array($result)) {
            return self::error('provider_not_configured', 'The provider API contract and authenticated adapter have not been configured.', 409);
        }
        if (!in_array($result['status'] ?? '', ['pending', 'processing', 'unknown', 'verified', 'failed', 'active', 'settled', 'cancelled'], true)) {
            return self::error('provider_response_invalid', 'The configured provider returned an unsupported status.', 502);
        }
        // Persist only normalized state; provider-specific response data stays in the adapter.
        return [
            'provider' => $provider,
            'operation' => $operation,
            'status' => $result['status'],
            'reference' => self::safe_reference($result['reference'] ?? ''),
            'checked_at' => gmdate('c'),
            'summary' => 'External provider result: ' . $result['status'] . '.',
        ];
    }

    /**
     * Generic extension callback signature, not a claim of an AU Bank signature scheme.
     * HMAC-SHA256(timestamp + "." + event_id + "." + exact request bytes).
     * Durable replay/event deduplication must also be enforced by the event controller.
     */
    public static function verify_callback(string $raw, string $signature, string $timestamp, string $event_id): bool|\WP_Error
    {
        if (strlen($raw) > 1024 * 1024 || !preg_match('/^[0-9]{10,12}$/D', $timestamp) || abs(time() - (int) $timestamp) > 300 || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $event_id)) {
            return self::error('callback_invalid', 'The callback envelope is invalid or expired.', 401);
        }
        if (str_starts_with($signature, 'sha256=')) {
            $signature = substr($signature, 7);
        }
        if (!preg_match('/^[A-Fa-f0-9]{64}$/D', $signature)) {
            return self::error('callback_signature_invalid', 'The callback signature is invalid.', 401);
        }
        $secret = self::secret('DBCL_WEBHOOK_SECRET', 'dbcl_webhook_secret');
        if (is_wp_error($secret)) {
            return self::error('callback_not_configured', 'Callback authentication has not been configured.', 503);
        }
        $expected = hash_hmac('sha256', $timestamp . '.' . $event_id . '.' . $raw, $secret);
        if (!hash_equals($expected, strtolower($signature))) {
            return self::error('callback_signature_invalid', 'The callback signature is invalid.', 401);
        }
        return true;
    }

    private static function settings(array $context): array
    {
        $settings = $context['settings'] ?? get_option('dbcl_settings', []);
        return is_array($settings) ? $settings : [];
    }

    private static function valid_object_id(mixed $id): bool
    {
        return (is_int($id) && $id > 0) || (is_string($id) && preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iD', $id));
    }

    private static function secret(string $name, string $option): string|\WP_Error
    {
        $value = defined($name) ? constant($name) : getenv($name);
        if ((!is_string($value) || $value === '') && class_exists(Crypto::class)) {
            $encrypted = get_option($option, '');
            if (is_string($encrypted) && $encrypted !== '') {
                try {
                    $value = Crypto::decrypt($encrypted);
                } catch (\Throwable $e) {
                    $value = null;
                }
            }
        }
        if (!is_string($value) || $value === '' || strlen($value) > 8192 || preg_match('/[\r\n]/', $value)) {
            return self::error('provider_secret_missing', 'The server-side provider credential is unavailable. Add it securely in server configuration.', 409);
        }
        return $value;
    }

    private static function map_payload(array $payload, array $mapping): array|\WP_Error
    {
        $fields = $mapping['field_map'] ?? null;
        $required = $mapping['required_fields'] ?? [];
        $fixed = $mapping['fixed_values'] ?? [];
        if (!is_array($fields) || (!$fields && !$fixed) || count($fields) > 64 || !is_array($required) || !is_array($fixed) || count($fixed) > 32) {
            return self::error('surepass_schema_required', 'Confirm the input-to-provider field map and required input fields.', 400);
        }
        foreach ($required as $key) {
            if (!is_string($key) || !array_key_exists($key, $payload) || $payload[$key] === '' || $payload[$key] === null || !array_key_exists($key, $fields)) {
                return self::error('surepass_input_missing', 'A required verification input is missing or unmapped.', 400);
            }
        }
        $body = [];
        foreach ($fixed as $target => $value) {
            if (!is_string($target) || !preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){0,5}$/D', $target) || (!is_scalar($value) && $value !== null)) {
                return self::error('surepass_schema_invalid', 'A fixed provider field is invalid.', 400);
            }
            $cursor =& $body;
            foreach (explode('.', $target) as $segment) {
                if (isset($cursor[$segment]) && !is_array($cursor[$segment])) {
                    return self::error('surepass_schema_invalid', 'Fixed provider field mappings overlap.', 400);
                }
                $cursor =& $cursor[$segment];
            }
            $cursor = $value;
            unset($cursor);
        }
        foreach ($fields as $input => $target) {
            if (!is_string($input) || !preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/D', $input) || !is_string($target) || !preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){0,5}$/D', $target)) {
                return self::error('surepass_schema_invalid', 'The confirmed field map contains an invalid field name.', 400);
            }
            if (!array_key_exists($input, $payload)) {
                continue;
            }
            $value = $payload[$input];
            if (!is_scalar($value) && !is_array($value) && $value !== null) {
                return self::error('surepass_input_invalid', 'A verification input has an unsupported value type.', 400);
            }
            if (is_string($value) && strlen($value) > 2 * 1024 * 1024) {
                return self::error('surepass_input_invalid', 'A verification input exceeds the supported size.', 400);
            }
            $cursor =& $body;
            foreach (explode('.', $target) as $segment) {
                if (isset($cursor[$segment]) && !is_array($cursor[$segment])) {
                    return self::error('surepass_schema_invalid', 'Provider field mappings overlap.', 400);
                }
                $cursor =& $cursor[$segment];
            }
            $cursor = $value;
            unset($cursor);
        }
        return $body;
    }

    private static function validate_known_inputs(string $normalizer, array $payload): bool|\WP_Error
    {
        if ($normalizer === 'pan' && (!is_string($payload['pan'] ?? null) || !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/D', $payload['pan']))) {
            return self::error('surepass_pan_invalid', 'Enter a valid uppercase PAN before verification.', 400);
        }
        if ($normalizer === 'bank' && (!is_string($payload['account_number'] ?? null) || !preg_match('/^[0-9]{6,20}$/D', $payload['account_number']) || !is_string($payload['ifsc'] ?? null) || !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/D', $payload['ifsc']))) {
            return self::error('surepass_bank_invalid', 'Enter a valid bank account number and uppercase IFSC before verification.', 400);
        }
        if ($normalizer === 'equifax') {
            if (!is_string($payload['name'] ?? null) || trim($payload['name']) === '' || strlen($payload['name']) > 150 || !is_string($payload['pan'] ?? null) || !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/D', $payload['pan']) || !is_string($payload['mobile'] ?? null) || !preg_match('/^[6-9][0-9]{9}$/D', $payload['mobile']) || !in_array($payload['gender'] ?? '', ['male', 'female'], true)) {
                return self::error('surepass_credit_fields_invalid', 'The recovered Equifax contract requires legal name, valid PAN, ten-digit mobile, and a supported gender value.', 400);
            }
        }
        if ($normalizer === 'esign-initialize') {
            if (!is_string($payload['file_id'] ?? null) || !preg_match('/^files_[A-Za-z0-9_-]{5,100}$/D', $payload['file_id']) || !is_string($payload['full_name'] ?? null) || trim($payload['full_name']) === '' || strlen($payload['full_name']) > 150 || !is_string($payload['mobile'] ?? null) || !preg_match('/^[6-9][0-9]{9}$/D', $payload['mobile']) || !is_string($payload['email'] ?? null) || !is_email($payload['email']) || !is_array($payload['positions'] ?? null) || !$payload['positions'] || count($payload['positions']) > 100) {
                return self::error('esign_inputs_invalid', 'A confirmed uploaded file ID, signer contact details and approved document-specific signing positions are required.', 400);
            }
            foreach ($payload['positions'] as $page => $positions) {
                if (!preg_match('/^[1-9][0-9]{0,3}$/D', (string) $page) || !is_array($positions) || !$positions || count($positions) > 20) {
                    return self::error('esign_positions_invalid', 'Each signing position must identify a valid PDF page and coordinate list.', 400);
                }
                foreach ($positions as $position) {
                    if (!is_array($position) || !isset($position['x'], $position['y']) || !is_numeric($position['x']) || !is_numeric($position['y']) || $position['x'] < 0 || $position['y'] < 0 || $position['x'] > 5000 || $position['y'] > 5000) {
                        return self::error('esign_positions_invalid', 'The approved PDF signing coordinates are invalid.', 400);
                    }
                }
            }
        }
        return true;
    }

    private static function normalizer_for(string $operation, array $mapping): string
    {
        return match ($operation) {
            'bank-verification' => 'bank',
            'pan-advanced', 'pan-advanced-v2', 'pan-advanced-v3' => 'pan',
            'digilocker', 'digilocker-initialize' => 'digilocker-initialize',
            'digilocker-download' => 'digilocker-download',
            'esign-initialize' => 'esign-initialize',
            'esign-status' => 'esign-status',
            'esign-document' => 'esign-document',
            'credit-report' => 'equifax',
            default => (string) ($mapping['normalizer'] ?? ''),
        };
    }

    private static function known_verdict(string $normalizer, array $body, array $payload, array $context): string
    {
        if (($body['success'] ?? null) === false) {
            return 'failed';
        }
        if (($body['success'] ?? null) !== true || (isset($body['status_code']) && (int) $body['status_code'] !== 200) || !is_array($body['data'] ?? null)) {
            return 'review_required';
        }
        $data = $body['data'];
        $expectedName = $context['expected_name'] ?? $payload['expected_name'] ?? '';
        if ($normalizer === 'digilocker-initialize') {
            $client = $data['client_id'] ?? '';
            $token = $data['token'] ?? '';
            return is_string($client) && preg_match('/^digilocker_[A-Za-z0-9_-]{5,100}$/D', $client) && is_string($token) && strlen($token) >= 20 && strlen($token) <= 8192 && !preg_match('/[\r\n]/', $token) ? 'pending' : 'review_required';
        }
        if ($normalizer === 'digilocker-download') {
            $xml = $data['aadhaar_xml_data'] ?? [];
            if (!is_array($xml) || !is_string($xml['full_name'] ?? null) || trim($xml['full_name']) === '' || !is_string($xml['dob'] ?? null) || trim($xml['dob']) === '' || !is_string($xml['masked_aadhaar'] ?? null) || !preg_match('/^X{4,}[0-9]{4}$/iD', $xml['masked_aadhaar'])) {
                return 'review_required';
            }
            $actualDob = self::date_of_birth($xml['dob']);
            if ($actualDob === '') {
                return 'review_required';
            }
            if (!empty($payload['dob']) && (!is_string($payload['dob']) || self::date_of_birth($payload['dob']) !== $actualDob)) {
                return 'review_required';
            }
            if (!empty($payload['aadhaar_last4']) && (!is_string($payload['aadhaar_last4']) || !hash_equals($payload['aadhaar_last4'], substr($xml['masked_aadhaar'], -4)))) {
                return 'review_required';
            }
            return is_string($expectedName) && $expectedName !== '' && self::same_name($expectedName, $xml['full_name']) ? 'verified' : 'review_required';
        }
        if ($normalizer === 'pan') {
            $flag = $data['pan_status'] ?? $data['status'] ?? $data['valid'] ?? $data['is_valid'] ?? null;
            $upper = is_scalar($flag) ? strtoupper((string) $flag) : '';
            if ($flag === false || in_array($upper, ['INVALID', 'INACTIVE', 'FALSE', 'DELETED'], true)) {
                return 'failed';
            }
            $valid = $flag === true || in_array($upper, ['E', 'VALID', 'ACTIVE', 'TRUE'], true);
            $desc = $data['pan_status_desc'] ?? '';
            if (is_string($desc) && preg_match('/INVALID|INACTIVE|DELET|DEACTIV/i', $desc)) {
                return 'failed';
            }
            $name = $data['full_name'] ?? $data['name'] ?? $data['pan_holder_name'] ?? '';
            $echo = $data['pan_number'] ?? $data['id_number'] ?? '';
            if (is_string($echo) && preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/D', $echo) && !hash_equals($payload['pan'], $echo)) {
                return 'failed';
            }
            return $valid && is_string($name) && trim($name) !== '' && is_string($expectedName) && $expectedName !== '' && self::same_name($expectedName, $name) ? 'verified' : 'review_required';
        }
        if ($normalizer === 'bank') {
            $flag = $data['account_exists'] ?? $data['exists'] ?? $data['is_account_valid'] ?? null;
            $lower = is_scalar($flag) ? strtolower((string) $flag) : '';
            if ($flag === false || $flag === 0 || in_array($lower, ['no', 'false', '0', 'n'], true)) {
                return 'failed';
            }
            $valid = $flag === true || $flag === 1 || in_array($lower, ['yes', 'true', '1', 'y'], true);
            $holder = $data['full_name'] ?? $data['account_holder_name'] ?? $data['account_name'] ?? $data['name'] ?? '';
            $account = $data['account_number'] ?? $data['id_number'] ?? '';
            $ifsc = $data['ifsc'] ?? '';
            if ((is_string($account) && preg_match('/^[0-9]{6,20}$/D', $account) && !hash_equals($payload['account_number'], $account)) || (is_string($ifsc) && preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/D', $ifsc) && !hash_equals($payload['ifsc'], $ifsc))) {
                return 'failed';
            }
            return $valid && is_string($holder) && trim($holder) !== '' && is_string($expectedName) && $expectedName !== '' && self::same_name($expectedName, $holder) ? 'verified' : 'review_required';
        }
        if ($normalizer === 'esign-status') {
            $status = $data['status'] ?? '';
            if ($status === 'esign_completed') {
                return 'verified';
            }
            if ($status === 'esign_failed') {
                return 'failed';
            }
            return in_array($status, ['client_intiated', 'client_initiated', 'otp_sent', 'otp_verified', 'esign_started'], true) ? 'pending' : 'review_required';
        }
        if ($normalizer === 'esign-initialize') {
            return is_string($data['client_id'] ?? null) && preg_match('/^esign_[A-Za-z0-9_-]{5,100}$/D', $data['client_id']) && is_string($data['url'] ?? null) && self::safe_action_url($data['url']) ? 'pending' : 'review_required';
        }
        if ($normalizer === 'esign-document') {
            return is_string($data['url'] ?? null) && self::safe_document_url($data['url']) ? 'pending' : 'review_required';
        }
        // A bureau report is evidence for a credit review, not a KYC/credit approval.
        return 'review_required';
    }

    private static function same_name(mixed $expected, mixed $actual): bool
    {
        if (!is_string($expected) || !is_string($actual)) {
            return false;
        }
        $normalize = static function (string $name): string {
            $name = function_exists('remove_accents') ? remove_accents($name) : $name;
            $name = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
            $name = trim((string) preg_replace('/[^\p{L}\p{N}]+/u', ' ', $name));
            $tokens = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            sort($tokens, SORT_STRING);
            return implode(' ', $tokens);
        };
        $left = $normalize($expected);
        return $left !== '' && hash_equals($left, $normalize($actual));
    }

    private static function date_of_birth(string $date): string
    {
        foreach (['Y-m-d', 'd-m-Y', 'd/m/Y'] as $format) {
            $parsed = \DateTimeImmutable::createFromFormat('!' . $format, $date, new \DateTimeZone('UTC'));
            if ($parsed !== false && $parsed->format($format) === $date && $parsed->format('Y-m-d') <= gmdate('Y-m-d')) {
                return $parsed->format('Y-m-d');
            }
        }
        return '';
    }

    private static function at(array $data, string $path): mixed
    {
        if (!preg_match('/^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+){0,8}$/D', $path)) {
            return null;
        }
        $value = $data;
        foreach (explode('.', $path) as $part) {
            if (!is_array($value) || !array_key_exists($part, $value)) {
                return null;
            }
            $value = $value[$part];
        }
        return is_scalar($value) || $value === null ? $value : null;
    }

    private static function matches(mixed $value, mixed $allowed): bool
    {
        if (!is_array($allowed) || is_array($value) || $value === null) {
            return false;
        }
        return in_array($value, $allowed, true);
    }

    private static function safe_reference(mixed $value): string
    {
        return is_scalar($value) && preg_match('/^[A-Za-z0-9_.:-]{1,160}$/D', (string) $value) ? (string) $value : '';
    }

    private static function safe_action_url(string $url): bool
    {
        if (strlen($url) > 4096) {
            return false;
        }
        $parts = wp_parse_url($url);
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || (isset($parts['port']) && (int) $parts['port'] !== 443)) {
            return false;
        }
        $host = strtolower($parts['host'] ?? '');
        if ($host === 'esign-client.aadhaarkyc.io') {
            return true;
        }
        foreach (['surepass.io', 'surepass.app', 'digilocker.gov.in', 'meripehchaan.gov.in'] as $trusted) {
            if ($host === $trusted || str_ends_with($host, '.' . $trusted)) {
                return true;
            }
        }
        return false;
    }

    private static function safe_document_url(string $url): bool
    {
        if (strlen($url) > 8192) {
            return false;
        }
        $parts = wp_parse_url($url);
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment']) || (isset($parts['port']) && (int) $parts['port'] !== 443)) {
            return false;
        }
        $host = strtolower($parts['host'] ?? '');
        return $host === 's3.amazonaws.com' || str_ends_with($host, '.s3.amazonaws.com') || preg_match('/^[a-z0-9.-]+\.s3\.[a-z0-9-]+\.amazonaws\.com$/D', $host);
    }

    private static function error(string $code, string $message, int $status, array $extra = []): \WP_Error
    {
        return new \WP_Error($code, $message, ['status' => $status] + $extra);
    }
}
