<?php
/** Immutable PDF signing sessions. Browser returns never complete a signature. */
namespace DigitalBE\ClientGroupLoans;

defined('ABSPATH') || exit;

final class ESign
{
    public static function register(): void
    {
        $base = '/applications/(?P<id>[a-f0-9-]{36})/esign';
        register_rest_route('digitalbe-loans/v1', $base, ['methods' => ['GET', 'POST'], 'callback' => [self::class, 'endpoint'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route('digitalbe-loans/v1', $base . '/documents', ['methods' => 'POST', 'callback' => [self::class, 'upload'], 'permission_callback' => [Auth::class, 'logged']]);
    }

    private static function error(string $code, string $message, int $status = 422): \WP_Error
    {
        return new \WP_Error('dbcl_esign_' . $code, $message, ['status' => $status]);
    }

    private static function params(\WP_REST_Request $request): array
    {
        return $request->get_json_params() ?: $request->get_params();
    }

    private static function load(\WP_REST_Request $request, bool $write): array|\WP_Error
    {
        $case = Store::get((string) $request['id']);
        if (is_wp_error($case)) {
            return $case;
        }
        $access = Auth::access($case, $write);
        if (is_wp_error($access)) {
            return $access;
        }
        if ($write && (int) (self::params($request)['expected_version'] ?? 0) !== (int) $case['version']) {
            return self::error('conflict', 'This application changed. Refresh before signing.', 409);
        }
        return $case;
    }

    /** The operator explicitly uploads the approved PDF; HTML previews are not PDFs. */
    public static function upload(\WP_REST_Request $request): array|\WP_Error
    {
        $case = self::load($request, true);
        if (is_wp_error($case)) {
            return $case;
        }
        if (!current_user_can('dbcl_operate') || Auth::actor($case)['party_role'] !== null) {
            return Auth::denied();
        }
        $p = self::params($request);
        $purpose = sanitize_key($p['purpose'] ?? '');
        $role = sanitize_key($p['party_role'] ?? '');
        $binding = self::preconditions($case, $purpose, $role);
        if (is_wp_error($binding)) {
            return $binding;
        }
        $settings = (array) get_option('dbcl_settings', []);
        $approval = substr(sanitize_text_field((string) ($p['approval_ref'] ?? '')), 0, 160);
        if (empty($settings['terms_approved']) || empty($settings['template_version']) || !rest_sanitize_boolean($p['approved'] ?? false) || $approval === '') {
            return self::error('approval', 'Approved lender templates and an explicit source-PDF approval reference are required.');
        }
        $positions = $p['positions'] ?? [];
        if (is_string($positions)) {
            $positions = json_decode($positions, true);
        }
        if (!self::valid_positions($positions)) {
            return self::error('positions', 'Supply the actual approved PDF page coordinates for this signer.');
        }
        foreach ($case['esign_sessions'] ?? [] as $session) {
            if (($session['purpose'] ?? '') === $purpose && ($session['party_role'] ?? '') === $role && ($session['terms_hash'] ?? '') === $binding['terms_hash']) {
                return self::error('existing', 'A signing session already exists for this party and terms. Reconcile that session before replacing it.', 409);
            }
        }
        $file = $request->get_file_params()['file'] ?? null;
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '') || (int) ($file['size'] ?? 0) > 2500000) {
            return self::error('upload', 'Upload the explicitly approved PDF, no larger than 2.5 MB.');
        }
        $record = Store::store_file($case['id'], $case['parties'][$role]['id'], 'execution_pdf', $file['tmp_name'], 'application/pdf');
        if (is_wp_error($record)) {
            return $record;
        }
        $scan = apply_filters('dbcl_scan_document', 'PENDING', $file['tmp_name'], $record);
        $scan = in_array($scan, ['CLEAN', 'INFECTED', 'PENDING'], true) ? $scan : 'PENDING';
        $sourceReady = $scan === 'CLEAN' || ($scan === 'PENDING' && !empty($settings['allow_unscanned_manual_review']));
        $id = wp_generate_uuid4();
        $case['esign_sessions'][$id] = $binding + [
            'id' => $id, 'purpose' => $purpose, 'party_role' => $role,
            'source_file_id' => $record['id'], 'source_sha256' => $record['sha256'], 'positions' => $positions,
            'source_approval_ref' => $approval, 'source_approved_by' => get_current_user_id(),
            'scan_status' => $scan, 'source_review' => $scan === 'CLEAN' ? 'SCANNER_CONFIRMED' : 'OPERATOR_ATTESTED',
            'status' => $sourceReady ? 'SOURCE_READY' : ($scan === 'INFECTED' ? 'SOURCE_BLOCKED' : 'SOURCE_REVIEW_REQUIRED'),
            'created_at' => gmdate('c'), 'updated_at' => gmdate('c'),
        ];
        $case['esign_sessions'][$id]['fingerprint'] = self::fingerprint($case['esign_sessions'][$id]);
        $saved = Store::save($case, (int) $case['version'], get_current_user_id(), 'esign_pdf_prepared', ['party_role' => $role, 'purpose' => $purpose, 'session_id' => $id, 'scan_status' => $scan]);
        return is_wp_error($saved) ? $saved : self::response($saved);
    }

    public static function endpoint(\WP_REST_Request $request): array|\WP_Error
    {
        $write = $request->get_method() !== 'GET';
        $case = self::load($request, $write);
        if (is_wp_error($case)) {
            return $case;
        }
        if (!$write) {
            return self::response($case);
        }
        $p = self::params($request);
        $id = (string) ($p['session_id'] ?? '');
        $session = $case['esign_sessions'][$id] ?? null;
        if (!is_array($session)) {
            return self::error('session', 'Choose an existing signing session.', 404);
        }
        $own = Auth::own_party($case, $session['party_role']);
        $action = $p['action'] ?? '';
        if ($action === 'begin') {
            if (is_wp_error($own)) {
                return $own;
            }
            return self::begin($case, $session);
        }
        if ($action === 'check') {
            if (is_wp_error($own) && (!current_user_can('dbcl_operate') || Auth::actor($case)['party_role'] !== null)) {
                return $own;
            }
            return self::check($case, $session);
        }
        if ($action === 'review_source') {
            if (!current_user_can('dbcl_operate') || Auth::actor($case)['party_role'] !== null) {
                return Auth::denied();
            }
            return self::review_source($case, $session, $p);
        }
        return self::error('action', 'Choose begin, check or review_source. A browser cannot mark a signature completed.');
    }

    /** Recheck the same encrypted PDF after installing a scanner or approving manual review. */
    private static function review_source(array $case, array $session, array $input): array|\WP_Error
    {
        if (!in_array($session['status'], ['SOURCE_REVIEW_REQUIRED', 'SOURCE_BLOCKED'], true)) {
            return self::error('source_review', 'Only a source awaiting security review can be reviewed.', 409);
        }
        $binding = self::validate_binding($case, $session);
        if (is_wp_error($binding)) {
            return $binding;
        }
        $source = Store::read_file($session['source_file_id']);
        if (is_wp_error($source)) {
            return $source;
        }
        if ($source['application_id'] !== $case['id'] || $source['party_id'] !== $session['party_id'] || $source['mime'] !== 'application/pdf' || !hash_equals($session['source_sha256'], $source['sha256'])) {
            return self::error('source', 'The source PDF does not match the immutable signing record.', 409);
        }
        $tmp = wp_tempnam('dbcl-sign-source-review');
        if (!$tmp) {
            return self::error('temporary_storage', 'Private temporary source review is unavailable.', 500);
        }
        try {
            @chmod($tmp, 0600);
            if (file_put_contents($tmp, $source['bytes'], LOCK_EX) !== strlen($source['bytes'])) {
                return self::error('temporary_storage', 'Source review could not prepare the same PDF.', 500);
            }
            $scan = apply_filters('dbcl_scan_document', 'PENDING', $tmp, array_diff_key($source, ['bytes' => true]));
        } finally {
            @unlink($tmp);
        }
        $scan = in_array($scan, ['CLEAN', 'INFECTED', 'PENDING'], true) ? $scan : 'PENDING';
        if (($session['scan_status'] ?? '') === 'INFECTED' && $scan === 'PENDING') {
            // A later scanner outage cannot turn known infected bytes into manual review.
            $scan = 'INFECTED';
        }
        $manual = $scan === 'PENDING' && !empty(get_option('dbcl_settings', [])['allow_unscanned_manual_review']) && rest_sanitize_boolean($input['review_confirmed'] ?? false) && trim((string) ($input['approval_ref'] ?? '')) !== '' && ($session['scan_status'] ?? '') !== 'INFECTED';
        $session['source_reviews'][] = ['reviewer_id' => get_current_user_id(), 'at' => gmdate('c'), 'scan_status' => $scan, 'manual_attestation' => $manual, 'approval_ref' => substr(sanitize_text_field((string) ($input['approval_ref'] ?? '')), 0, 160)];
        $session['scan_status'] = $scan;
        $session['status'] = $scan === 'CLEAN' || $manual ? 'SOURCE_READY' : ($scan === 'INFECTED' ? 'SOURCE_BLOCKED' : 'SOURCE_REVIEW_REQUIRED');
        $session['source_review'] = $scan === 'CLEAN' ? 'SCANNER_CONFIRMED' : 'OPERATOR_ATTESTED';
        $case['esign_sessions'][$session['id']] = $session;
        $saved = Store::save($case, (int) $case['version'], get_current_user_id(), 'esign_source_reviewed', ['session_id' => $session['id'], 'scan_status' => $scan]);
        return is_wp_error($saved) ? $saved : self::response($saved);
    }

    /** Pure source/party/terms binding check, also used before applying provider evidence. */
    public static function validate_binding(array $case, array $session): bool|\WP_Error
    {
        $binding = self::preconditions($case, (string) ($session['purpose'] ?? ''), (string) ($session['party_role'] ?? ''));
        if (is_wp_error($binding)) {
            return $binding;
        }
        foreach (['party_id', 'obligation_id', 'terms_hash', 'profile_hash', 'template_version'] as $key) {
            if (($session[$key] ?? '') !== $binding[$key]) {
                return self::error('stale', 'Party details or accepted terms changed. This immutable signing session is stale.', 409);
            }
        }
        if (empty($session['fingerprint']) || !hash_equals($session['fingerprint'], self::fingerprint($session))) {
            return self::error('integrity', 'The immutable signing-session binding cannot be confirmed.', 409);
        }
        return true;
    }

    private static function begin(array $case, array $session): array|\WP_Error
    {
        $binding = self::validate_binding($case, $session);
        if (is_wp_error($binding)) {
            return $binding;
        }
        if (!in_array($session['status'], ['SOURCE_READY', 'UPLOAD_NOT_SENT', 'FILE_UPLOADED', 'INITIALIZE_NOT_SENT'], true)) {
            return self::error('reserved', 'This session is pending, completed, or requires reconciliation. No duplicate upload or initialization was sent.', 409);
        }
        if (!in_array($session['scan_status'] ?? '', ['CLEAN', 'PENDING'], true) || (($session['scan_status'] ?? '') === 'PENDING' && empty(get_option('dbcl_settings', [])['allow_unscanned_manual_review']))) {
            return self::error('scan', 'The approved source document has not satisfied the configured malware-review policy.', 409);
        }
        $source = Store::read_file($session['source_file_id']);
        if (is_wp_error($source)) {
            return $source;
        }
        if ($source['application_id'] !== $case['id'] || $source['party_id'] !== $session['party_id'] || $source['mime'] !== 'application/pdf' || !hash_equals($session['source_sha256'], $source['sha256'])) {
            return self::error('source', 'The approved PDF does not match this application, signer and source hash.', 409);
        }
        $context = self::context($case, $session);
        if (empty($session['uploaded_file_id'])) {
            $reserved = self::reserve($case, $session, 'UPLOAD_PROCESSING');
            if (is_wp_error($reserved)) {
                return $reserved;
            }
            [$case, $session] = $reserved;
            $upload = Providers::upload_esign_document($source['bytes'], $context);
            if (is_wp_error($upload)) {
                return self::provider_failure($case, $session, $upload, 'UPLOAD');
            }
            $session['uploaded_file_id'] = $upload['reference'];
            $session['status'] = 'FILE_UPLOADED';
            $saved = self::persist($case['id'], $session, 'esign_pdf_uploaded');
            if (is_wp_error($saved)) {
                return $saved;
            }
            $case = $saved;
            $session = $case['esign_sessions'][$session['id']];
        }
        $binding = self::validate_binding($case, $session);
        if (is_wp_error($binding)) {
            return $binding;
        }
        $reserved = self::reserve($case, $session, 'INITIALIZE_PROCESSING');
        if (is_wp_error($reserved)) {
            return $reserved;
        }
        [$case, $session] = $reserved;
        $party = $case['parties'][$session['party_role']];
        $profile = $party['profile'];
        $result = Providers::request('esign-initialize', ['file_id' => $session['uploaded_file_id'], 'full_name' => $profile['legal_name'], 'mobile' => $profile['mobile'], 'email' => $profile['email'], 'positions' => $session['positions']], self::context($case, $session));
        if (is_wp_error($result)) {
            return self::provider_failure($case, $session, $result, 'INITIALIZE');
        }
        $session['provider_reference'] = $result['reference'];
        $session['status'] = $result['status'] === 'pending' && !empty($result['action_url']) && $result['reference'] !== '' ? 'SIGNING_PENDING' : 'INITIALIZE_UNCONFIRMED';
        if (!empty($result['action_url'])) {
            $session['action_url'] = $result['action_url'];
        }
        $saved = self::persist($case['id'], $session, 'esign_initialized');
        return is_wp_error($saved) ? $saved : self::response($saved);
    }

    private static function check(array $case, array $session): array|\WP_Error
    {
        $binding = self::validate_binding($case, $session);
        if (is_wp_error($binding)) {
            return $binding;
        }
        if ($session['status'] === 'COMPLETED') {
            return self::response($case);
        }
        if ($session['status'] === 'CHECKING' && time() - (int) ($session['processing_at'] ?? time()) < 120) {
            return self::error('checking', 'A check is already running. Wait before polling again.', 409);
        }
        if (!in_array($session['status'], ['SIGNING_PENDING', 'CHECKING', 'DOCUMENT_RETRIEVAL_PENDING'], true) || empty($session['provider_reference'])) {
            return self::error('not_pending', 'This session cannot be polled. Reconcile the existing upload or initialization first.', 409);
        }
        $reserved = self::reserve($case, $session, 'CHECKING');
        if (is_wp_error($reserved)) {
            return $reserved;
        }
        [$case, $session] = $reserved;
        $result = Providers::request('esign-status', ['client_id' => $session['provider_reference']], self::context($case, $session));
        if (is_wp_error($result) || $result['status'] !== 'verified') {
            $session['status'] = !is_wp_error($result) && $result['status'] === 'failed' ? 'PROVIDER_FAILED' : 'SIGNING_PENDING';
            $session['reason'] = is_wp_error($result) ? $result->get_error_code() : 'Provider signing remains incomplete.';
            $saved = self::persist($case['id'], $session, 'esign_status_checked');
            return is_wp_error($saved) ? $saved : self::response($saved);
        }
        $download = Providers::download_signed_document($session['provider_reference'], self::context($case, $session));
        if (is_wp_error($download)) {
            $session['status'] = 'DOCUMENT_RETRIEVAL_PENDING';
            $session['reason'] = $download->get_error_code();
            $saved = self::persist($case['id'], $session, 'esign_document_pending');
            return is_wp_error($saved) ? $saved : self::response($saved);
        }
        $tmp = wp_tempnam('dbcl-signed-pdf');
        if (!$tmp) {
            return self::error('temporary_storage', 'Private temporary document storage is unavailable. Keep the existing signing session for reconciliation.', 500);
        }
        try {
            @chmod($tmp, 0600);
            if (file_put_contents($tmp, $download['pdf'], LOCK_EX) !== strlen($download['pdf'])) {
                return self::error('temporary_storage', 'The executed document could not be prepared for encrypted storage.', 500);
            }
            $artifact = Store::store_file($case['id'], $session['party_id'], 'executed_agreement', $tmp, 'application/pdf');
        } finally {
            @unlink($tmp);
        }
        if (is_wp_error($artifact)) {
            $session['status'] = 'DOCUMENT_RETRIEVAL_PENDING';
            $session['reason'] = $artifact->get_error_code();
            $saved = self::persist($case['id'], $session, 'esign_document_storage_pending');
            return is_wp_error($saved) ? $saved : self::response($saved);
        }
        $session['signed_document_id'] = $artifact['id'];
        $session['signed_sha256'] = $artifact['sha256'];
        $session['status'] = 'COMPLETED';
        $session['completed_at'] = gmdate('c');
        unset($session['action_url'], $session['reason']);
        $saved = self::persist($case['id'], $session, 'esign_executed_document_stored', true);
        return is_wp_error($saved) ? $saved : self::response($saved);
    }

    private static function reserve(array $case, array $session, string $status): array|\WP_Error
    {
        $session['status'] = $status;
        $session['operation_id'] = wp_generate_uuid4();
        $session['processing_at'] = time();
        $session['updated_at'] = gmdate('c');
        $case['esign_sessions'][$session['id']] = $session;
        $saved = Store::save($case, (int) $case['version'], get_current_user_id(), 'esign_request_reserved', ['session_id' => $session['id'], 'status' => $status]);
        return is_wp_error($saved) ? $saved : [$saved, $session];
    }

    /** Only local CAS writes retry; a provider request is never repeated here. */
    private static function persist(string $application_id, array $session, string $event, bool $complete = false): array|\WP_Error
    {
        for ($try = 0; $try < 3; $try++) {
            $case = Store::get($application_id);
            if (is_wp_error($case)) {
                return $case;
            }
            $current = $case['esign_sessions'][$session['id']] ?? [];
            if (($current['operation_id'] ?? '') !== ($session['operation_id'] ?? '') || ($current['fingerprint'] ?? '') !== ($session['fingerprint'] ?? '')) {
                return self::error('reconciliation', 'The signing operation changed. Reconcile the existing provider session; do not initialize again.', 409);
            }
            $session['updated_at'] = gmdate('c');
            $binding = self::validate_binding($case, $session);
            if (is_wp_error($binding)) {
                $session['status'] = 'STALE_SOURCE';
                $session['reason'] = $binding->get_error_code();
                unset($session['action_url']);
                $complete = false;
            }
            $case['esign_sessions'][$session['id']] = $session;
            if ($complete) {
                $changed = Workflow::apply($case, 'record_signature', ['purpose' => $session['purpose'], 'party_role' => $session['party_role'], 'status' => 'COMPLETED', 'reference' => $session['provider_reference'], 'evidence_ref' => $session['signed_document_id'], 'document_hash' => $session['signed_sha256'], 'terms_hash' => $session['terms_hash']], ['id' => 0, 'capabilities' => ['dbcl_operate'], 'provider' => true]);
                if (is_wp_error($changed)) {
                    $case['esign_sessions'][$session['id']]['status'] = 'EVIDENCE_REVIEW_REQUIRED';
                    $case['esign_sessions'][$session['id']]['reason'] = $changed->get_error_code();
                } else {
                    $case = $changed;
                }
            }
            $saved = Store::save($case, (int) $case['version'], get_current_user_id(), $event, ['session_id' => $session['id'], 'status' => $case['esign_sessions'][$session['id']]['status']]);
            if (!is_wp_error($saved) || $saved->get_error_code() !== 'dbcl_conflict') {
                return $saved;
            }
        }
        return self::error('save_reconciliation', 'The provider operation finished but its local update conflicted. Reconcile the reserved session; no provider retry was made.', 409);
    }

    private static function provider_failure(array $case, array $session, \WP_Error $error, string $phase): array|\WP_Error
    {
        $notSent = in_array($error->get_error_code(), ['provider_secret_missing', 'esign_consent_required', 'esign_production_required', 'esign_pdf_invalid', 'surepass_mapping_required', 'surepass_esign_contract_invalid', 'surepass_identity_contract_invalid', 'surepass_invalid_path', 'surepass_invalid_environment', 'surepass_specific_consent_required', 'surepass_production_required', 'surepass_unsupported_method', 'surepass_schema_required', 'surepass_schema_invalid', 'surepass_input_missing', 'surepass_input_invalid', 'esign_inputs_invalid', 'esign_positions_invalid'], true);
        $session['status'] = $phase . ($notSent ? '_NOT_SENT' : '_UNCONFIRMED');
        $session['reason'] = $error->get_error_code();
        $saved = self::persist($case['id'], $session, 'esign_provider_incomplete');
        return is_wp_error($saved) ? $saved : self::response($saved);
    }

    private static function preconditions(array $case, string $purpose, string $role): array|\WP_Error
    {
        $settings = (array) get_option('dbcl_settings', []);
        if (empty($settings['terms_approved']) || empty($settings['template_version'])) {
            return self::error('template_approval', 'Approved lender templates and a published template version are required for execution.');
        }
        if (!in_array($purpose, ['initial', 'bc', 'slt'], true) || !isset($case['parties'][$role])) {
            return self::error('scope', 'Choose an existing loan/contribution purpose and party.');
        }
        $record = $purpose === 'slt' ? ($case['slt'] ?? []) : ($case['loans'][$purpose] ?? []);
        $party = $case['parties'][$role];
        $hash = $record['terms']['hash'] ?? '';
        $accepted = $record['terms']['accepted'][$role] ?? [];
        if (empty($record['id']) || !preg_match('/^[a-f0-9]{64}$/D', $hash) || empty($accepted['accepted']) || ($accepted['terms_hash'] ?? '') !== $hash || ($accepted['party_id'] ?? '') !== ($party['id'] ?? '') || (int) ($accepted['user_id'] ?? 0) !== (int) ($party['user_id'] ?? 0) || empty($party['user_id'])) {
            return self::error('terms_acceptance', 'This independently signed-in party must accept the current exact terms before execution.');
        }
        foreach (['data_processing', 'esign'] as $purposeKey) {
            $consent = $party['consents'][$purposeKey] ?? [];
            $definition = $settings['consent_texts'][$purposeKey] ?? [];
            if (empty($consent['accepted']) || empty($consent['version']) || ($consent['actor_id'] ?? 0) !== $party['user_id'] || empty($definition['version']) || $consent['version'] !== $definition['version'] || ($consent['text'] ?? '') !== ($definition['text'] ?? '')) {
                return self::error('consent', 'The party must accept the current data-processing and eSign consent versions in their own account.');
            }
        }
        $profile = $party['profile'] ?? [];
        if (empty($profile['legal_name']) || !preg_match('/^[6-9][0-9]{9}$/D', $profile['mobile'] ?? '') || !is_email($profile['email'] ?? '')) {
            return self::error('contact', 'A legal name, valid mobile and email are required for this signer.');
        }
        return ['party_id' => $party['id'], 'obligation_id' => $record['id'], 'terms_hash' => $hash, 'profile_hash' => hash('sha256', wp_json_encode([$party['id'], $profile, $party['bank'] ?? []])), 'template_version' => (string) $settings['template_version']];
    }

    private static function context(array $case, array $session): array
    {
        return ['settings' => (array) get_option('dbcl_settings', []), 'consent' => true, 'consent_purpose' => 'esign', 'application_id' => $case['id'], 'party_id' => $session['party_id']];
    }

    private static function fingerprint(array $session): string
    {
        $bound = [];
        foreach (['id', 'purpose', 'party_role', 'party_id', 'obligation_id', 'terms_hash', 'profile_hash', 'template_version', 'source_file_id', 'source_sha256', 'positions'] as $key) {
            $bound[$key] = $session[$key] ?? null;
        }
        return hash('sha256', wp_json_encode($bound));
    }

    private static function valid_positions(mixed $positions): bool
    {
        if (!is_array($positions) || !$positions || count($positions) > 100) {
            return false;
        }
        foreach ($positions as $page => $items) {
            if (!preg_match('/^[1-9][0-9]{0,3}$/D', (string) $page) || !is_array($items) || !$items || count($items) > 20) {
                return false;
            }
            foreach ($items as $item) {
                if (!is_array($item) || !isset($item['x'], $item['y']) || !is_numeric($item['x']) || !is_numeric($item['y']) || $item['x'] < 0 || $item['y'] < 0 || $item['x'] > 5000 || $item['y'] > 5000) {
                    return false;
                }
            }
        }
        return true;
    }

    public static function public_sessions(array $case): array
    {
        $staff = Auth::staff() && Auth::actor($case)['party_role'] === null;
        $out = [];
        foreach ($case['esign_sessions'] ?? [] as $session) {
            $own = (int) ($case['parties'][$session['party_role']]['user_id'] ?? 0) === get_current_user_id();
            if (!$staff && !$own) {
                continue;
            }
            $item = array_intersect_key($session, array_flip(['id', 'purpose', 'party_role', 'status', 'created_at', 'updated_at', 'source_sha256', 'signed_document_id', 'signed_sha256', 'completed_at', 'reason', 'scan_status']));
            $binding = self::validate_binding($case, $session);
            if (is_wp_error($binding)) {
                $item['status'] = 'STALE_SOURCE';
                $item['reason'] = $binding->get_error_code();
            }
            $valid = !is_wp_error($binding);
            $item['can_begin'] = $valid && $own && in_array($session['status'], ['SOURCE_READY', 'UPLOAD_NOT_SENT', 'FILE_UPLOADED', 'INITIALIZE_NOT_SENT'], true);
            $item['can_check'] = $valid && ($own || ($staff && current_user_can('dbcl_operate'))) && in_array($session['status'], ['SIGNING_PENDING', 'CHECKING', 'DOCUMENT_RETRIEVAL_PENDING'], true);
            $item['can_review_source'] = $valid && $staff && current_user_can('dbcl_operate') && in_array($session['status'], ['SOURCE_REVIEW_REQUIRED', 'SOURCE_BLOCKED'], true);
            if ($valid && $own && $session['status'] === 'SIGNING_PENDING' && !empty($session['action_url'])) {
                $item['action_url'] = $session['action_url'];
            }
            $out[] = $item;
        }
        return $out;
    }

    private static function response(array $case): array
    {
        return ['application_id' => $case['id'], 'version' => $case['version'], 'sessions' => self::public_sessions($case)];
    }
}
