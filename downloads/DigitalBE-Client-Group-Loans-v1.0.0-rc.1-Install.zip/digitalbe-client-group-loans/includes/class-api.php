<?php
namespace DigitalBE\ClientGroupLoans;
defined('ABSPATH') || exit;

/** Authenticated application commands. No endpoint provides unrestricted status writes. */
final class API {
    public static function register(): void {
        $ns = 'digitalbe-loans/v1';
        register_rest_route($ns, '/applications', [
            ['methods' => 'GET', 'callback' => [self::class, 'listing'], 'permission_callback' => [Auth::class, 'logged']],
            ['methods' => 'POST', 'callback' => [self::class, 'create'], 'permission_callback' => [Auth::class, 'logged']],
        ]);
        $base = '/applications/(?P<id>[a-f0-9-]{36})';
        register_rest_route($ns, $base, ['methods' => 'GET', 'callback' => [self::class, 'get'], 'permission_callback' => [Auth::class, 'logged']]);
        foreach (['profile', 'consent', 'documents', 'kyc', 'commands', 'generate', 'invite', 'policy', 'staff'] as $action) {
            register_rest_route($ns, $base . '/' . $action, ['methods' => 'POST', 'callback' => [self::class, $action], 'permission_callback' => [Auth::class, 'logged']]);
        }
        register_rest_route($ns, $base . '/kyc/reconcile', ['methods' => 'POST', 'callback' => [self::class, 'reconcile_kyc'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route($ns, $base . '/audit', ['methods' => 'GET', 'callback' => [self::class, 'audit'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route($ns, $base . '/snapshots/(?P<snapshot>[a-f0-9-]{36})', ['methods' => 'GET', 'callback' => [self::class, 'snapshot'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route($ns, '/files/(?P<file>[a-f0-9-]{36})', ['methods' => 'GET', 'callback' => [self::class, 'file'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route($ns, '/claim', ['methods' => 'POST', 'callback' => [self::class, 'claim'], 'permission_callback' => [Auth::class, 'logged']]);
        register_rest_route($ns, '/settings', ['methods' => ['GET', 'POST'], 'callback' => [self::class, 'settings'], 'permission_callback' => static fn() => current_user_can('manage_options')]);
        register_rest_route($ns, '/settings/approve', ['methods' => 'POST', 'callback' => [self::class, 'approve_settings'], 'permission_callback' => static fn() => current_user_can('dbcl_finance_check')]);
        register_rest_route($ns, '/settings/review', ['methods' => 'GET', 'callback' => static fn() => ['settings' => self::settings_data()], 'permission_callback' => static fn() => current_user_can('dbcl_finance_check')]);
        register_rest_route($ns, '/reports', ['methods' => 'GET', 'callback' => [self::class, 'reports'], 'permission_callback' => static fn() => current_user_can('dbcl_audit') || current_user_can('dbcl_assign')]);
        register_rest_route($ns, '/callbacks/(?P<provider>[a-z0-9_-]+)', ['methods' => 'POST', 'callback' => [self::class, 'callback'], 'permission_callback' => '__return_true']);
        add_filter('rest_pre_serve_request', [self::class, 'serve_binary'], 10, 4);
    }

    private static function error(string $code, string $message, int $status = 400): \WP_Error { return new \WP_Error('dbcl_' . $code, $message, ['status' => $status]); }
    private static function params(\WP_REST_Request $r): array { return $r->get_json_params() ?: $r->get_params(); }
    private static function settings_data(): array { return (array) get_option('dbcl_settings', []); }

    private static function current_consent(array $party, string $purpose, array $settings): bool {
        $record = $party['consents'][$purpose] ?? [];
        $published = $settings['consent_texts'][$purpose] ?? [];
        return !empty($record['accepted']) && !empty($published['version']) && !empty($published['text'])
            && (string) ($record['version'] ?? '') === (string) $published['version']
            && hash_equals(hash('sha256', $published['text']), hash('sha256', (string) ($record['text'] ?? '')))
            && (int) ($record['actor_id'] ?? 0) === (int) ($party['user_id'] ?? 0) && !empty($party['user_id']);
    }

    private static function load(\WP_REST_Request $r, bool $write = false): array|\WP_Error {
        $case = Store::get((string) $r['id']);
        if (is_wp_error($case)) { return $case; }
        $access = Auth::access($case, $write);
        if (is_wp_error($access)) { return $access; }
        if ($write) {
            $p = self::params($r);
            if (!isset($p['expected_version']) || (int) $p['expected_version'] !== (int) $case['version']) {
                return self::error('conflict', 'This record changed. Refresh it before retrying your action.', 409);
            }
        }
        return $case;
    }

    private static function view(array $case): array {
        $visible = Auth::public_case($case);
        $files = [];
        foreach ($visible['parties'] ?? [] as $role => $party) {
            foreach ($party['documents'] ?? [] as $doc) {
                $files[] = array_merge(array_intersect_key($doc, array_flip(['id', 'type', 'mime', 'sha256', 'size', 'scan_status', 'review', 'created_at', 'capture_method'])), ['role' => $role]);
            }
        }
        $snapshots = [];
        foreach ($case['snapshots'] ?? [] as $item) {
            if (!Auth::staff() || Auth::actor($case)['party_role'] !== null) { continue; }
            $snapshots[] = array_diff_key($item, ['html' => true]);
        }
        unset($visible['snapshots']);
        $published = (array) (self::settings_data()['consent_texts'] ?? []);
        $attempts = [];
        if (Auth::can_staff($case, 'dbcl_assign')) {
            foreach ($case['parties'] ?? [] as $role => $party) {
                foreach ($party['kyc_requests'] ?? [] as $operation => $attempt) {
                    if (!in_array($attempt['status'] ?? '', ['PROCESSING', 'UNKNOWN'], true)) { continue; }
                    $attempts[] = ['role' => $role, 'operation' => $operation, 'request_id' => $attempt['id'], 'status' => $attempt['status'], 'created_at' => $attempt['created_at'] ?? ''];
                }
            }
        }
        return ['application' => $visible, 'gates' => Workflow::evaluate($case), 'actor' => Auth::actor($case), 'files' => $files, 'snapshots' => $snapshots, 'consent_texts' => $published, 'verification_attempts' => $attempts];
    }

    private static function save(array $case, int $version, string $event, array $summary = []): array|\WP_Error {
        if (class_exists(Notifications::class)) { $case = Notifications::append($case, $event); }
        $updated = Store::save($case, $version, get_current_user_id(), $event, $summary);
        return is_wp_error($updated) ? $updated : self::view($updated);
    }

    public static function listing(\WP_REST_Request $r): array {
        $uid = get_current_user_id();
        $scope = ['org_id' => max(1, (int) get_user_meta($uid, 'dbcl_org_id', true))];
        if (!current_user_can('manage_options') && !current_user_can('dbcl_assign') && !current_user_can('dbcl_audit')) { $scope['user_id'] = $uid; }
        $branch = (string) get_user_meta($uid, 'dbcl_branch', true);
        if ($branch !== '') { $scope['branch'] = $branch; }
        $rows = Store::list($scope, max(1, (int) $r->get_param('page')), 25);
        $visible = [];
        foreach ($rows['rows'] ?? [] as $row) {
            $case = Store::get($row['id']);
            if (is_wp_error($case) || is_wp_error(Auth::access($case))) { continue; }
            $visible[] = array_merge($row, ['stage' => Workflow::stage($case), 'product' => $case['product'] ?? '', 'exception' => $case['exception'] ?? null]);
        }
        return ['applications' => $visible, 'total' => $rows['total'] ?? 0];
    }

    public static function create(\WP_REST_Request $r): array|\WP_Error {
        $p = self::params($r);
        if (empty($p['branch']) || empty($p['purpose'])) { return self::error('required', 'Branch and loan purpose are required.'); }
        $amount = filter_var($p['requested_amount_paise'] ?? 0, FILTER_VALIDATE_INT);
        if ($amount === false || $amount < 1 || $amount > 10000000000) { return self::error('amount', 'Enter a valid requested amount in integer paise.'); }
        $uid = get_current_user_id();
        $case = Workflow::initial([
            'branch' => substr(sanitize_text_field($p['branch']), 0, 100),
            'loan_purpose' => substr(sanitize_textarea_field($p['purpose']), 0, 2000),
            'product' => substr(sanitize_text_field($p['product'] ?? 'Client and group loan'), 0, 160),
            'requested_amount_paise' => $amount,
            'org_id' => max(1, (int) get_user_meta($uid, 'dbcl_org_id', true)),
            'policy' => self::policy_snapshot(),
        ], $uid);
        $case['policy'] = self::policy_snapshot();
        $case['org_id'] = max(1, (int) get_user_meta($uid, 'dbcl_org_id', true));
        $case['owner_id'] = $uid;
        $case['parties']['applicant']['user_id'] = $uid;
        $case = Store::create($case);
        return is_wp_error($case) ? $case : self::view($case);
    }

    public static function get(\WP_REST_Request $r): array|\WP_Error { $case = self::load($r); return is_wp_error($case) ? $case : self::view($case); }

    public static function profile(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? '');
        if (!isset($case['parties'][$role])) { return self::error('role', 'Choose a valid participant role.'); }
        $own = Auth::own_party($case, $role);
        $assisted = is_wp_error($own);
        if ($assisted && (Auth::actor($case)['party_role'] !== null || !current_user_can('dbcl_review'))) { return $own; }
        $old = $case['parties'][$role];
        $schema = Documents::schema();
        $profile = (array) ($old['profile'] ?? []);
        foreach (['personal', 'address'] as $section) {
            foreach ($schema['sections'][$section]['fields'] as $field) {
                $name = $field['name']; if (!array_key_exists($name, $p['profile'] ?? [])) { continue; }
                $raw = $p['profile'][$name];
                if (is_array($raw) || is_object($raw)) { return self::error('profile', 'A profile field has an invalid value.'); }
                if (is_string($raw) && str_contains($raw, '•')) { continue; }
                $value = $field['type'] === 'checkbox' ? rest_sanitize_boolean($raw) : substr(sanitize_textarea_field((string) $raw), 0, 2000);
            if (isset($field['pattern']) && $value !== '' && !preg_match('~' . $field['pattern'] . '~D', $value)) { return self::error('format', 'Check the format of ' . $name . '.'); }
                if (in_array($field['type'], ['money', 'number'], true) && $value !== '' && (!is_numeric($value) || (float) $value < 0 || (float) $value > 100000000000)) { return self::error('format', 'Check the amount or number in ' . $name . '.'); }
                if ($name === 'dob' && $value !== '' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value) || !checkdate((int) substr($value, 5, 2), (int) substr($value, 8, 2), (int) substr($value, 0, 4)) || $value > gmdate('Y-m-d'))) { return self::error('dob', 'Enter a valid date of birth.'); }
                if ($name === 'email' && $value !== '' && !is_email($value)) { return self::error('email', 'Enter a valid email address.'); }
                $profile[$name] = $value;
            }
        }
        $bank = (array) ($old['bank'] ?? []);
        foreach ($schema['sections']['bank']['fields'] as $field) {
            $name = $field['name']; if (!empty($field['transient']) || !array_key_exists($name, $p['bank'] ?? [])) { continue; }
            $value = substr(sanitize_text_field((string) $p['bank'][$name]), 0, 160);
            if (str_contains($value, '•')) { continue; }
            if (isset($field['pattern']) && $value !== '' && !preg_match('~' . $field['pattern'] . '~D', $value)) { return self::error('bank_format', 'Check the bank field ' . $name . '.'); }
            if ($name === 'account_number' && $value !== ($old['bank']['account_number'] ?? '') && $value !== ($p['bank']['account_number_confirm'] ?? '')) { return self::error('bank_confirmation', 'The account numbers must match.'); }
            $bank[$name] = $value;
        }
        $changed = $profile !== ($old['profile'] ?? []) || $bank !== ($old['bank'] ?? []);
        if ($changed) {
            $case['profile_history'][] = ['role' => $role, 'profile' => $old['profile'] ?? [], 'bank' => $old['bank'] ?? [], 'at' => gmdate('c')];
            unset($bank['verification']);
            $case = self::invalidate($case, $role, 'Material participant data changed');
        }
        $case['parties'][$role]['profile'] = $profile;
        $case['parties'][$role]['bank'] = $bank;
        $case['parties'][$role]['assisted_entry'] = $assisted;
        return self::save($case, (int) $p['expected_version'], 'profile_updated', ['party_role' => $role]);
    }

    private static function invalidate(array $case, string $role, string $reason): array {
        $case['parties'][$role]['kyc'] = [];
        $case['parties'][$role]['consents'] = [];
        $case['documents_submitted'] = false;
        foreach ($case['loans'] ?? [] as $type => $loan) {
            if (in_array($loan['payment']['status'] ?? '', ['SETTLED', 'CONFIRMED'], true)) { continue; }
            $case['loans'][$type]['terms']['accepted'] = [];
            foreach ($loan['signatures'] ?? [] as $signer => $signature) {
                $case['loans'][$type]['signatures'][$signer]['status'] = 'STALE';
            }
        }
        if (isset($case['db_kit'])) { $case['db_kit']['status'] = 'CORRECTION_REQUIRED'; }
        $case['invalidations'][] = ['party_role' => $role, 'reason' => $reason, 'at' => gmdate('c')];
        return $case;
    }

    public static function consent(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? '');
        $own = Auth::own_party($case, $role); if (is_wp_error($own)) { return $own; }
        $purpose = sanitize_key($p['purpose'] ?? '');
        if (!isset(Documents::schema()['consents'][$purpose])) { return self::error('consent', 'Choose an available consent purpose.'); }
        $settings = self::settings_data();
        $definition = $settings['consent_texts'][$purpose] ?? null;
        if (!is_array($definition) || empty($definition['text']) || empty($definition['version'])) { return self::error('consent_configuration', 'The administrator must publish purpose-specific consent text and version first.', 422); }
        if (($p['version'] ?? '') !== $definition['version']) { return self::error('consent_version', 'The consent text changed. Review the current version first.', 409); }
        $accepted = rest_sanitize_boolean($p['accepted'] ?? false);
        $previous = $case['parties'][$role]['consents'][$purpose] ?? null;
        if ($previous) { $case['consent_history'][] = ['role' => $role, 'purpose' => $purpose, 'record' => $previous]; }
        $case['parties'][$role]['consents'][$purpose] = ['accepted' => $accepted, 'response' => $accepted ? 'ACCEPTED' : 'DECLINED', 'version' => $definition['version'], 'text' => $definition['text'], 'at' => gmdate('c'), 'actor_id' => get_current_user_id()];
        if (!$accepted && in_array($purpose, ['kyc', 'data_processing'], true)) {
            $case['parties'][$role]['kyc'] = [];
            unset($case['parties'][$role]['bank']['verification']);
        }
        return self::save($case, (int) $p['expected_version'], 'consent_recorded', ['party_role' => $role, 'purpose' => $purpose]);
    }

    public static function documents(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? '');
        $own = Auth::own_party($case, $role);
        if (is_wp_error($own) && (Auth::actor($case)['party_role'] !== null || !current_user_can('dbcl_review'))) { return $own; }
        if (!isset($case['parties'][$role])) { return self::error('role', 'Choose a valid party.'); }
        $type = sanitize_key($p['type'] ?? '');
        if (!isset(Documents::schema()['documents'][$type]) || !rest_sanitize_boolean($p['original_confirmed'] ?? false)) { return self::error('document', 'Select a document type and confirm it was photographed from the original.'); }
        $file = $r->get_file_params()['file'] ?? null;
        if (!$file || ($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) { return self::error('upload', 'Choose a valid document upload.'); }
        $record = Store::store_file($case['id'], $case['parties'][$role]['id'], $type, $file['tmp_name'], (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']));
        if (is_wp_error($record)) { return $record; }
        $record['type'] = $type;
        $record['capture_method'] = in_array($p['capture_method'] ?? '', ['camera', 'upload'], true) ? $p['capture_method'] : 'upload';
        $record['original_confirmed'] = true;
        $record['review'] = ['status' => 'PENDING'];
        $scan = apply_filters('dbcl_scan_document', 'PENDING', $file['tmp_name'], $record);
        $record['scan_status'] = in_array($scan, ['CLEAN', 'INFECTED', 'PENDING'], true) ? $scan : 'PENDING';
        foreach ($case['parties'][$role]['documents'] ?? [] as $previous) {
            if (($previous['type'] ?? '') === $type && ($previous['review']['status'] ?? '') === 'ACCEPTED') {
                $case = self::invalidate($case, $role, 'Accepted document replaced; fresh dependent checks required');
                break;
            }
        }
        $case['parties'][$role]['documents'][$record['id']] = $record;
        if (isset($case['db_kit'])) { $case['db_kit']['status'] = 'CORRECTION_REQUIRED'; }
        return self::save($case, (int) $p['expected_version'], 'document_uploaded', ['party_role' => $role, 'document_type' => $type]);
    }

    public static function kyc(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? '');
        $own = Auth::own_party($case, $role);
        if (is_wp_error($own) && (Auth::actor($case)['party_role'] !== null || !current_user_can('dbcl_review'))) { return $own; }
        if (!isset($case['parties'][$role])) { return self::error('role', 'Choose a valid party.'); }
        $party = $case['parties'][$role];
        $settings = self::settings_data();
        $consent = self::current_consent($party, 'kyc', $settings) && self::current_consent($party, 'data_processing', $settings);
        if (!$consent) { return self::error('consent_required', 'This party must accept data-processing and KYC consent before verification.', 422); }
        $limit = 'dbcl_kyc_' . get_current_user_id(); $count = (int) get_transient($limit);
        if ($count >= 10) { return self::error('rate_limit', 'Too many verification requests. Wait a minute before trying again.', 429); }
        set_transient($limit, $count + 1, MINUTE_IN_SECONDS);
        $operation = sanitize_key($p['operation'] ?? '');
        if ($operation === 'digilocker') { $operation = 'digilocker-initialize'; }
        if (str_starts_with($operation, 'esign')) { return self::error('signing_centre', 'Use the document-bound signature centre for eSign operations.', 422); }
        if (str_starts_with($operation, 'digilocker') && is_wp_error($own)) { return Auth::denied(); }
        $input = is_array($p['payload'] ?? null) ? $p['payload'] : [];
        $payload = array_merge($input, $party['profile'] ?? [], $party['bank'] ?? []);
        $payload['name'] = $party['profile']['legal_name'] ?? '';
        $payload['expected_name'] = $payload['name'];
        if (str_starts_with($operation, 'digilocker-') && $operation !== 'digilocker-initialize') {
            $pending = $party['kyc']['digilocker-initialize']['reference'] ?? $party['kyc']['digilocker']['reference'] ?? '';
            if (!$pending || ($input['client_id'] ?? '') !== $pending) { return self::error('correlation', 'Use the DigiLocker reference issued for this party.', 422); }
        }
        $mapping = $settings['surepass_mappings'][$operation] ?? Providers::default_mappings()[$operation] ?? [];
        $mapped_keys = array_keys($mapping['field_map'] ?? []);
        if (!empty($mapping['reference_input'])) { $mapped_keys[] = $mapping['reference_input']; }
        $mapped_input = array_intersect_key($payload, array_flip($mapped_keys));
        // Unmapped browser fields and prior verification metadata must never
        // turn the same billable request into a supposedly new attempt.
        $fingerprint = hash('sha256', wp_json_encode([$operation, Workflow::identity_hash($party), Workflow::bank_hash($party['bank'] ?? []), $settings['surepass_environment'] ?? 'sandbox', $mapping, $mapped_input]));
        $previous = $party['kyc_requests'][$operation] ?? [];
        if (in_array($previous['status'] ?? '', ['PROCESSING', 'UNKNOWN'], true)) { return self::error('verification_in_flight', 'The prior verification needs reconciliation. Do not submit another paid request.', 409); }
        $action_key = 'dbcl_sdk_' . hash('sha256', $case['id'] . ':' . $party['id']);
        if (($previous['fingerprint'] ?? '') === $fingerprint && ($previous['status'] ?? '') === 'COMPLETE' && $operation !== 'digilocker-download') {
            $cached = self::view($case);
            if (!is_wp_error($own) && in_array($operation, ['digilocker', 'digilocker-initialize'], true)) {
                $encrypted = get_transient($action_key);
                if (is_string($encrypted)) { $plain = Crypto::decrypt($encrypted); if (!is_wp_error($plain)) { $cached['provider_action'] = json_decode($plain, true); } }
            }
            return $cached;
        }
        $attempt = wp_generate_uuid4();
        $case['parties'][$role]['kyc_requests'][$operation] = ['id' => $attempt, 'fingerprint' => $fingerprint, 'status' => 'PROCESSING', 'actor_id' => get_current_user_id(), 'created_at' => gmdate('c')];
        $reserved = Store::save($case, (int) $case['version'], get_current_user_id(), 'kyc_reserved', ['party_role' => $role, 'operation' => $operation]);
        if (is_wp_error($reserved)) { return $reserved; }
        $specific = str_starts_with($operation, 'credit-report') ? 'credit_bureau' : 'kyc';
        if ($specific !== 'kyc' && !self::current_consent($party, $specific, $settings)) {
            $reserved['parties'][$role]['kyc_requests'][$operation]['status'] = 'FAILED';
            Store::save($reserved, $reserved['version'], get_current_user_id(), 'kyc_consent_blocked');
            return self::error('specific_consent', 'This request requires separately accepted credit-bureau consent.', 422);
        }
        $result = Providers::request($operation, $payload, ['settings' => self::settings_data(), 'consent' => true, 'consent_purpose' => $specific, 'consents' => $party['consents'] ?? [], 'party_id' => $party['id'], 'application_id' => $case['id'], 'expected_name' => $payload['name']]);
        $case = Store::get($case['id']);
        if (is_wp_error($case)) { return $case; }
        if (($case['parties'][$role]['kyc_requests'][$operation]['id'] ?? '') !== $attempt || Workflow::identity_hash($case['parties'][$role]) !== Workflow::identity_hash($party) || Workflow::bank_hash($case['parties'][$role]['bank'] ?? []) !== Workflow::bank_hash($party['bank'] ?? [])) {
            return self::error('verification_stale', 'Participant data changed during verification. Reconcile this attempt before making another request.', 409);
        }
        if (is_wp_error($result)) {
            $uncertain = in_array($result->get_error_code(), ['surepass_transport_unknown', 'surepass_invalid_response', 'surepass_reference_mismatch'], true) || ((int) ($result->get_error_data()['provider_http_status'] ?? 0) >= 500);
            $case['parties'][$role]['kyc_requests'][$operation]['status'] = $uncertain ? 'UNKNOWN' : 'FAILED';
            $saved = Store::save($case, $case['version'], get_current_user_id(), 'kyc_result_incomplete', ['party_role' => $role, 'operation' => $operation]);
            return is_wp_error($saved) ? $saved : $result;
        }
        $case['parties'][$role]['kyc_requests'][$operation]['status'] = 'COMPLETE';
        $persist = array_intersect_key($result, array_flip(['reference', 'status', 'operation', 'product', 'summary', 'verified_fields', 'checked_at', 'environment']));
        $persist['checked_at'] = gmdate('c');
        $persist['profile_hash'] = Workflow::identity_hash($party);
        $case['parties'][$role]['kyc'][$operation] = $persist;
        if ($operation === 'bank-verification' && strtolower($result['status'] ?? '') === 'verified') {
            $case['parties'][$role]['bank']['verification'] = ['result' => 'PASS', 'reference' => $result['reference'] ?? '', 'source' => 'PROVIDER_CONFIRMED', 'environment' => $result['environment'] ?? ($settings['surepass_environment'] ?? 'sandbox'), 'bank_hash' => Workflow::bank_hash($party['bank']), 'at' => gmdate('c')];
        }
        $saved = self::save($case, (int) $case['version'], 'kyc_requested', ['party_role' => $role, 'operation' => $operation]);
        if (is_wp_error($saved)) { return $saved; }
        $saved['provider_action'] = array_intersect_key($result, array_flip(['sdk_token', 'sdk_gateway', 'action_url', 'reference', 'status']));
        if (!is_wp_error($own) && !empty($saved['provider_action']['sdk_token'])) {
            set_transient($action_key, Crypto::encrypt(wp_json_encode($saved['provider_action'])), 10 * MINUTE_IN_SECONDS);
        }
        if (is_wp_error($own)) { unset($saved['provider_action']['sdk_token'], $saved['provider_action']['action_url']); }
        return $saved;
    }

    public static function reconcile_kyc(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        if (!Auth::can_staff($case, 'dbcl_assign')) { return Auth::denied(); }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? ''); $operation = sanitize_key($p['operation'] ?? '');
        $attempt = $case['parties'][$role]['kyc_requests'][$operation] ?? null;
        if (!$attempt || !in_array($attempt['status'], ['PROCESSING', 'UNKNOWN'], true) || ($attempt['id'] ?? '') !== ($p['request_id'] ?? '')) { return self::error('reconcile', 'Select the existing unresolved verification attempt.'); }
        if ((int) ($attempt['actor_id'] ?? 0) === get_current_user_id()) { return self::error('independent_reviewer', 'A different supervisor must reconcile this interrupted request.', 403); }
        if (empty($p['evidence_ref']) || !rest_sanitize_boolean($p['provider_confirmed_not_processed'] ?? false)) { return self::error('reconcile_evidence', 'Provider evidence that this attempt was not processed is required before allowing a new request.'); }
        $case['parties'][$role]['kyc_requests'][$operation]['status'] = 'FAILED';
        $case['parties'][$role]['kyc_requests'][$operation]['reconciliation'] = ['reviewer_id' => get_current_user_id(), 'source' => 'OFFICER_REPORTED', 'evidence_ref' => substr(sanitize_text_field($p['evidence_ref']), 0, 200), 'at' => gmdate('c')];
        return self::save($case, (int) $p['expected_version'], 'kyc_reconciled', ['party_role' => $role, 'operation' => $operation]);
    }

    public static function commands(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        $p = self::params($r); $command = sanitize_key($p['command'] ?? '');
        $input = $p['input'] ?? [];
        if (!is_array($input) || strlen(wp_json_encode($input)) > 65536) { return self::error('command', 'The command input is invalid or too large.'); }
        if ($command === 'submit_documents') {
            foreach ($case['parties'] as $role => $party) {
                foreach (['personal', 'address', 'bank'] as $section) {
                    foreach (Documents::schema()['sections'][$section]['fields'] as $field) {
                        if (empty($field['required']) || !empty($field['transient'])) { continue; }
                        $source = $section === 'bank' ? ($party['bank'] ?? []) : ($party['profile'] ?? []);
                        $value = $source[$field['name']] ?? null;
                        if ($value === null || $value === '' || $value === false) { return self::error('incomplete_profile', 'Complete ' . str_replace('_', ' ', $field['name']) . ' for ' . str_replace('_', ' ', $role) . ' before submission.', 422); }
                    }
                }
            }
        }
        if (in_array($command, ['assign_officer', 'assign_verification'], true)) {
            $uid = (int) ($input['officer_id'] ?? 0);
            $cap = $command === 'assign_officer' ? 'dbcl_review' : 'dbcl_verify';
            $branch = (string) get_user_meta($uid, 'dbcl_branch', true);
            if (!user_can($uid, $cap) || max(1, (int) get_user_meta($uid, 'dbcl_org_id', true)) !== $case['org_id'] || ($branch !== '' && $branch !== $case['branch'])) { return self::error('assignment', 'Choose an eligible officer in this organization and branch.'); }
        }
        $changed = Workflow::apply($case, $command, $input, Auth::actor($case));
        if (is_wp_error($changed)) { return $changed; }
        if ($command === 'assign_verification') { $changed['staff_assignments'][(int) $input['officer_id']] = 'verification'; }
        return self::save($changed, (int) $p['expected_version'], 'workflow_' . $command, ['command' => $command]);
    }

    public static function generate(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        if (Auth::actor($case)['party_role'] !== null || (!current_user_can('dbcl_operate') && !current_user_can('dbcl_review'))) { return Auth::denied(); }
        $p = self::params($r); $type = sanitize_key($p['type'] ?? 'application');
        if (!in_array($type, ['application', 'sanction', 'kfs', 'agreement', 'dpn', 'indemnity', 'membership', 'receipt', 'db_kit', 'initial_kfs', 'bc_kfs'], true)) { return self::error('template', 'Choose a supported document template.'); }
        $settings = self::settings_data();
        $settings['loan'] = in_array($p['loan'] ?? '', ['initial', 'bc'], true) ? $p['loan'] : 'bc';
        if ($type === 'receipt') {
            $receipt = null;
            foreach ($case['receipts'] ?? [] as $candidate) {
                if ((!empty($p['receipt_id']) && ($candidate['id'] ?? '') === $p['receipt_id']) || (!empty($p['instruction_id']) && ($candidate['instruction_id'] ?? '') === $p['instruction_id'] && ($candidate['purpose'] ?? '') === ($p['purpose'] ?? ''))) { $receipt = $candidate; break; }
            }
            if (!$receipt) { return self::error('receipt', 'Select a reconciled settled instruction. Pending payments and observations cannot produce receipts.', 422); }
            $settings['receipt'] = $receipt;
        }
        if (count($case['snapshots'] ?? []) >= 200) { return self::error('archive', 'Export and archive older packs before generating further versions.'); }
        $snapshot = Documents::snapshot($type, $case, $settings);
        $snapshot['id'] = wp_generate_uuid4(); $snapshot['created_at'] = gmdate('c');
        $case['snapshots'][$snapshot['id']] = $snapshot;
        return self::save($case, (int) $p['expected_version'], 'document_generated', ['document_type' => $type]);
    }

    public static function audit(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r); if (is_wp_error($case)) { return $case; }
        if (!Auth::staff() || Auth::actor($case)['party_role'] !== null) { return Auth::denied(); }
        return ['events' => Store::audit($case['id'])];
    }

    public static function file(\WP_REST_Request $r): \WP_REST_Response|\WP_Error {
        $meta = Store::file_metadata((string) $r['file']); if (is_wp_error($meta)) { return $meta; }
        $case = Store::get($meta['application_id']); if (is_wp_error($case)) { return $case; }
        $access = Auth::access($case); if (is_wp_error($access)) { return $access; }
        $role = Auth::actor($case)['party_role'];
        if ($role !== null && ($case['parties'][$role]['id'] ?? '') !== $meta['party_id']) { return Auth::denied(); }
        $file = Store::read_file((string) $r['file']); if (is_wp_error($file)) { return $file; }
        // Downloads are logged without content or identifiers.
        $logged = Store::log_access($case['id'], get_current_user_id(), 'document_downloaded', ['document_id' => $file['id']]);
        if (is_wp_error($logged)) { return $logged; }
        return self::binary($file['bytes'], $file['mime'], 'document-' . $file['id'] . (['image/jpeg' => '.jpg', 'image/png' => '.png', 'application/pdf' => '.pdf'][$file['mime']] ?? ''));
    }

    public static function snapshot(\WP_REST_Request $r): \WP_REST_Response|\WP_Error {
        $case = self::load($r); if (is_wp_error($case)) { return $case; }
        if (!Auth::staff() || Auth::actor($case)['party_role'] !== null) { return Auth::denied(); }
        $item = $case['snapshots'][$r['snapshot']] ?? null;
        if (!$item) { return self::error('snapshot', 'Document version not found.', 404); }
        if (!hash_equals($item['sha256'], hash('sha256', $item['html']))) { return self::error('integrity', 'Document integrity check failed.', 500); }
        $logged = Store::log_access($case['id'], get_current_user_id(), 'snapshot_downloaded', ['document_id' => $item['id']]);
        if (is_wp_error($logged)) { return $logged; }
        return self::binary($item['html'], 'text/html; charset=UTF-8', $item['type'] . '-' . $item['id'] . '.html');
    }

    private static function binary(string $bytes, string $mime, string $filename): \WP_REST_Response {
        return new \WP_REST_Response($bytes, 200, ['Content-Type' => $mime, 'Content-Disposition' => 'attachment; filename="' . sanitize_file_name($filename) . '"', 'X-DBCL-Binary' => '1', 'Cache-Control' => 'private, no-store, max-age=0', 'X-Content-Type-Options' => 'nosniff', 'Content-Security-Policy' => "default-src 'none'; style-src 'unsafe-inline'; img-src data:; frame-ancestors 'none'"]);
    }
    public static function serve_binary(bool $served, \WP_HTTP_Response $response, \WP_REST_Request $request, \WP_REST_Server $server): bool {
        if (str_starts_with($request->get_route(), '/digitalbe-loans/v1/') && ($response->get_headers()['X-DBCL-Binary'] ?? '') === '1') { echo $response->get_data(); return true; }
        return $served;
    }

    public static function invite(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        if (Auth::actor($case)['party_role'] !== 'applicant' && !Auth::can_staff($case, 'dbcl_review')) { return Auth::denied(); }
        $p = self::params($r); $role = sanitize_key($p['role'] ?? '');
        if (!in_array($role, ['co_applicant', 'guarantor_1', 'guarantor_2'], true) || !empty($case['parties'][$role]['user_id'])) { return self::error('invitation', 'This participant role is unavailable.'); }
        return Store::issue_invitation($case['id'], $role, time() + DAY_IN_SECONDS);
    }

    public static function claim(\WP_REST_Request $r): array|\WP_Error {
        if (!apply_filters('dbcl_mobile_verified', false, get_current_user_id())) { return self::error('verified_mobile_required', 'Verify your own mobile using the configured authentication provider before accepting an invitation.', 422); }
        $p = self::params($r); $token = (string) ($p['token'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) { return self::error('invitation', 'This invitation is invalid or expired.'); }
        $case = Store::claim_invitation($token, get_current_user_id());
        return is_wp_error($case) ? $case : self::view($case);
    }

    private static function policy_snapshot(): array {
        $s = self::settings_data();
        $keys = ['financial_operations_enabled', 'require_initial_closure', 'return_recipient', 'return_purpose', 'slt_terms_text', 'slt_due_date', 'slt_notice_hours', 'bc_partner', 'lender_name', 'allow_unscanned_manual_review', 'require_bc_mandate', 'surepass_environment'];
        $policy = array_merge(Workflow::initial([], 1)['policy'], array_intersect_key($s, array_flip($keys)));
        $policy['initial_closure_required'] = !array_key_exists('require_initial_closure', $s) || !empty($s['require_initial_closure']);
        $policy['bc_mandate_required'] = !array_key_exists('require_bc_mandate', $s) || !empty($s['require_bc_mandate']);
        $policy['surepass_environment'] = $s['surepass_environment'] ?? 'sandbox';
        $policy['financial_operations_enabled'] = !empty($s['financial_operations_enabled']) && !empty($s['approved_by']) && ($s['approved_revision'] ?? 0) === ($s['revision'] ?? -1);
        $policy['version'] = $s['revision'] ?? 0;
        return $policy;
    }

    public static function policy(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        if (!Auth::can_staff($case, 'dbcl_assign')) { return Auth::denied(); }
        $p = self::params($r); $case['policy_history'][] = $case['policy'] ?? [];
        $case['policy'] = self::policy_snapshot();
        foreach (array_keys($case['parties']) as $role) { $case = self::invalidate($case, $role, 'Policy version updated; fresh acceptance required'); }
        if (($case['policy']['surepass_environment'] ?? '') === 'production') {
            foreach ($case['parties'] as $role => $party) {
                if (($party['bank']['verification']['environment'] ?? '') !== 'production') { unset($case['parties'][$role]['bank']['verification']); }
            }
        }
        return self::save($case, (int) $p['expected_version'], 'policy_applied');
    }

    public static function staff(\WP_REST_Request $r): array|\WP_Error {
        $case = self::load($r, true); if (is_wp_error($case)) { return $case; }
        if (!Auth::can_staff($case, 'dbcl_assign')) { return Auth::denied(); }
        $p = self::params($r); $uid = (int) ($p['user_id'] ?? 0); $role = sanitize_key($p['staff_role'] ?? '');
        $caps = ['verification' => 'dbcl_verify', 'operations' => 'dbcl_operate', 'finance_maker' => 'dbcl_finance_make', 'finance_checker' => 'dbcl_finance_check'];
        if (!isset($caps[$role]) || !user_can($uid, $caps[$role]) || max(1, (int) get_user_meta($uid, 'dbcl_org_id', true)) !== $case['org_id']) { return self::error('staff', 'Choose an eligible staff member in this organization.'); }
        $branch = (string) get_user_meta($uid, 'dbcl_branch', true);
        if ($branch !== '' && $branch !== $case['branch']) { return self::error('staff', 'The staff member belongs to another branch.'); }
        $case['staff_assignments'][$uid] = $role;
        return self::save($case, (int) $p['expected_version'], 'staff_assigned');
    }

    public static function settings(\WP_REST_Request $r): array|\WP_Error {
        if ($r->get_method() === 'GET') { return ['settings' => self::settings_data(), 'surepass_defaults' => Providers::default_mappings()]; }
        $p = self::params($r); $input = $p['settings'] ?? $p;
        if (!is_array($input) || strlen(wp_json_encode($input)) > 200000) { return self::error('settings', 'The configuration is invalid or too large.'); }
        $settings = self::settings_data(); $before = $settings;
        if ((int) ($p['expected_revision'] ?? -1) !== (int) ($settings['revision'] ?? 0)) { return self::error('conflict', 'The configuration changed. Refresh before saving.', 409); }
        if (!empty($settings['require_staff_mfa']) && !apply_filters('dbcl_mfa_verified', false, get_current_user_id())) { return self::error('mfa_required', 'A verified staff MFA session is required to change configuration.', 403); }
        $boolean = ['terms_approved', 'financial_operations_enabled', 'require_initial_closure', 'require_staff_mfa', 'allow_unscanned_manual_review', 'require_bc_mandate'];
        $text = ['lender_name', 'lender_address', 'grievance_contact', 'template_version', 'approved_terms_text', 'slt_terms_text', 'slt_due_date', 'return_recipient', 'return_purpose', 'bc_partner', 'surepass_environment'];
        foreach ($boolean as $key) { if (array_key_exists($key, $input)) { $settings[$key] = rest_sanitize_boolean($input[$key]); } }
        foreach ($text as $key) { if (array_key_exists($key, $input)) { $settings[$key] = substr(sanitize_textarea_field((string) $input[$key]), 0, 20000); } }
        if (isset($input['slt_notice_hours'])) { $settings['slt_notice_hours'] = max(0, min(720, (int) $input['slt_notice_hours'])); }
        if (isset($input['sla_hours'])) { $settings['sla_hours'] = max(1, min(8760, (int) $input['sla_hours'])); }
        if (isset($input['notifications_enabled'])) { $settings['notifications_enabled'] = rest_sanitize_boolean($input['notifications_enabled']); }
        foreach (['surepass_mappings', 'document_templates', 'signer_roles', 'consent_texts'] as $key) {
            if (!isset($input[$key])) { continue; }
            if (!is_array($input[$key])) { return self::error('settings', $key . ' must be an object.'); }
            $settings[$key] = self::clean_config($input[$key]);
        }
        $settings['revision'] = (int) ($settings['revision'] ?? 0) + 1;
        $settings['changed_by'] = get_current_user_id(); $settings['changed_at'] = gmdate('c');
        $settings['approved_by'] = 0; $settings['approved_revision'] = 0;
        $persisted = self::write_settings($settings, $before);
        if (is_wp_error($persisted)) { return $persisted; }
        return ['settings' => $settings, 'message' => 'Configuration saved. Financial policy requires independent checker approval and explicit application to existing cases.'];
    }

    private static function clean_config(array $value, int $depth = 0): array {
        if ($depth > 8) { return []; }
        $clean = [];
        foreach ($value as $key => $item) {
            if (preg_match('/token|password|secret|api_key|authorization/i', (string) $key)) { continue; }
            $key = is_int($key) ? $key : substr((string) $key, 0, 100);
            $clean[$key] = is_array($item) ? self::clean_config($item, $depth + 1) : (is_bool($item) || is_int($item) || is_float($item) ? $item : substr(sanitize_textarea_field((string) $item), 0, 20000));
        }
        return $clean;
    }

    public static function approve_settings(\WP_REST_Request $r): array|\WP_Error {
        $settings = self::settings_data(); $before = $settings; $p = self::params($r); $uid = get_current_user_id();
        if (!empty($settings['require_staff_mfa']) && !apply_filters('dbcl_mfa_verified', false, $uid)) { return self::error('mfa_required', 'A verified staff MFA session is required.', 403); }
        if ((int) ($settings['changed_by'] ?? 0) === $uid) { return self::error('maker_checker', 'A different finance checker must approve this configuration.', 403); }
        if ((int) ($p['revision'] ?? 0) !== (int) ($settings['revision'] ?? -1)) { return self::error('conflict', 'The configuration revision changed.', 409); }
        $settings['approved_by'] = $uid; $settings['approved_revision'] = $settings['revision']; $settings['approved_at'] = gmdate('c');
        $persisted = self::write_settings($settings, $before);
        if (is_wp_error($persisted)) { return $persisted; }
        return ['revision' => $settings['revision'], 'approved' => true];
    }

    private static function write_settings(array $settings, array $before): bool|\WP_Error {
        global $wpdb;
        if (get_option('dbcl_settings', null) === null) {
            return add_option('dbcl_settings', $settings, '', false) ? true : self::error('conflict', 'Configuration changed concurrently. Refresh before retrying.', 409);
        }
        $ok = $wpdb->query($wpdb->prepare('UPDATE ' . $wpdb->options . ' SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s', maybe_serialize($settings), 'dbcl_settings', maybe_serialize($before)));
        if ($ok !== 1) { return self::error('conflict', 'Configuration changed concurrently. Refresh before retrying.', 409); }
        wp_cache_delete('dbcl_settings', 'options'); wp_cache_delete('alloptions', 'options');
        return true;
    }

    public static function callback(\WP_REST_Request $r): array|\WP_Error {
        // Provider-specific authentication and payload mapping must be installed by a reviewed adapter.
        // No browser redirect or unauthenticated JSON is accepted as external financial evidence.
        $event = apply_filters('dbcl_authenticated_callback', null, $r['provider'], $r);
        if (is_wp_error($event)) { return $event; }
        if (!is_array($event) || empty($event['authenticated']) || empty($event['event_id']) || empty($event['application_id'])) { return self::error('callback_unconfigured', 'No authenticated callback adapter is configured for this provider.', 503); }
        $case = Store::get($event['application_id']); if (is_wp_error($case)) { return $case; }
        $allowed = ['record_signature', 'record_mandate', 'record_settlement'];
        if (!in_array($event['command'] ?? '', $allowed, true)) { return self::error('callback_kind', 'Unsupported callback event.'); }
        $digest = hash('sha256', $r->get_body());
        $event_id = sanitize_key($r['provider']) . ':' . (string) $event['event_id'];
        if (strlen($event_id) > 100) { return self::error('callback_id', 'The callback event ID is too long.'); }
        $seen = Store::event_status($event_id, $digest);
        if (is_wp_error($seen)) { return $seen; }
        if ($seen === true) { return ['accepted' => true, 'duplicate' => true]; }
        // Workflow idempotency and CAS protect the state if two valid callbacks race.
        $changed = Workflow::apply($case, $event['command'], (array) ($event['input'] ?? []), ['id' => 0, 'party_role' => null, 'provider' => true, 'capabilities' => Auth::CAPS]);
        if (is_wp_error($changed)) { return $changed; }
        $saved = Store::save($changed, (int) $case['version'], 0, 'provider_callback', ['provider' => sanitize_key($r['provider'])], $event_id, $digest);
        if (is_wp_error($saved)) { return $saved; }
        return ['accepted' => true, 'duplicate' => !empty($saved['_callback_duplicate'])];
    }

    public static function reports(\WP_REST_Request $r): \WP_REST_Response|\WP_Error {
        $rows = self::listing($r);
        $stream = fopen('php://temp', 'w+');
        fputcsv($stream, ['Application ID', 'Branch', 'Stage', 'Initial disbursed (paise)', 'Return received (paise)', 'Initial repaid (paise)', 'Initial lender status', 'BC disbursed (paise)', 'SLT received (paise)'], ',', '"', '');
        foreach ($rows['applications'] as $row) {
            $case = Store::get($row['id']); if (is_wp_error($case)) { continue; }
            $logged = Store::log_access($case['id'], get_current_user_id(), 'report_exported');
            if (is_wp_error($logged)) { fclose($stream); return $logged; }
            $values = [$case['id'], $case['branch'], Workflow::stage($case), Workflow::settled_total($case['loans']['initial'] ?? []), Workflow::settled_total($case['return_collection'] ?? []), Workflow::settled_total($case['loans']['initial'] ?? [], 'repayment'), $case['loans']['initial']['status'] ?? '', Workflow::settled_total($case['loans']['bc'] ?? []), Workflow::settled_total($case['slt'] ?? [])];
            $values = array_map(static fn($v) => is_string($v) && preg_match('/^[=+@\-\t\r]/', $v) ? "'" . $v : $v, $values);
            fputcsv($stream, $values, ',', '"', '');
        }
        rewind($stream); $csv = stream_get_contents($stream); fclose($stream);
        return self::binary($csv, 'text/csv; charset=UTF-8', 'digitalbe-loans-page-' . max(1, (int) $r->get_param('page')) . '.csv');
    }
}
