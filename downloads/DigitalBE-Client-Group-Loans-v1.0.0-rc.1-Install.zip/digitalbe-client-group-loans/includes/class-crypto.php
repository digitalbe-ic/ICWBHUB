<?php
/** Authenticated encryption for sensitive case state and private files. */
namespace DigitalBE\ClientGroupLoans;

if (!defined('ABSPATH')) {
    exit;
}

final class Crypto
{
    private const AAD = 'digitalbe-client-group-loans:v1';

    private static function key(): string
    {
        $encoded = defined('DBCL_ENCRYPTION_KEY') ? (string) DBCL_ENCRYPTION_KEY : (string) getenv('DBCL_ENCRYPTION_KEY');
        if ($encoded !== '') {
            $key = base64_decode($encoded, true);
            if ($key === false || strlen($key) !== 32) {
                throw new \RuntimeException('DBCL_ENCRYPTION_KEY must be base64 encoding of exactly 32 random bytes.');
            }
            return $key;
        }
        $salt = (string) wp_salt('auth');
        if (strlen($salt) < 32) {
            throw new \RuntimeException('A stable encryption key or strong WordPress authentication salts are required.');
        }
        return hash_hkdf('sha256', $salt, 32, self::AAD);
    }

    public static function encrypt(string $plaintext): string
    {
        if (!function_exists('openssl_encrypt')) {
            throw new \RuntimeException('The PHP OpenSSL extension is required.');
        }
        $iv = random_bytes(12);
        $tag = '';
        $ciphertext = openssl_encrypt($plaintext, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, self::AAD, 16);
        if ($ciphertext === false || strlen($tag) !== 16) {
            throw new \RuntimeException('Authenticated encryption failed.');
        }
        return 'v1:' . base64_encode($iv . $tag . $ciphertext);
    }

    /** @return string|\WP_Error */
    public static function decrypt(string $envelope)
    {
        if (substr($envelope, 0, 3) !== 'v1:') {
            return new \WP_Error('dbcl_ciphertext', 'Unsupported or invalid encrypted data.', ['status' => 500]);
        }
        $binary = base64_decode(substr($envelope, 3), true);
        if ($binary === false || strlen($binary) < 28) {
            return new \WP_Error('dbcl_ciphertext', 'Invalid encrypted data.', ['status' => 500]);
        }
        try {
            $value = openssl_decrypt(substr($binary, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($binary, 0, 12), substr($binary, 12, 16), self::AAD);
        } catch (\Throwable $e) {
            return new \WP_Error('dbcl_encryption_key', 'Encryption configuration is unavailable. Restore the original encryption key or WordPress salts.', ['status' => 500]);
        }
        if ($value === false) {
            return new \WP_Error('dbcl_integrity', 'Encrypted data authentication failed. Restore the original encryption key or WordPress salts.', ['status' => 500]);
        }
        return $value;
    }
}
