<?php
/** Customer-safe in-app notices, SLA reminders and optional delivery orchestration. */
namespace DigitalBE\ClientGroupLoans;
defined('ABSPATH') || exit;

final class Notifications
{
    public static function register(): void
    {
        add_action('rest_api_init', [self::class, 'routes']);
        add_action('dbcl_run_reminders', [self::class, 'run_reminders']);
    }

    public static function routes(): void
    {
        register_rest_route('digitalbe-loans/v1', '/applications/(?P<id>[a-f0-9-]{36})/notifications', [
            'methods' => 'GET', 'callback' => [self::class, 'listing'], 'permission_callback' => [Auth::class, 'logged'],
        ]);
        register_rest_route('digitalbe-loans/v1', '/notifications/(?P<notification_id>[a-f0-9-]{36})/read', [
            'methods' => 'POST', 'callback' => [self::class, 'mark_read'], 'permission_callback' => [Auth::class, 'logged'],
        ]);
    }

    /** Called before the aggregate's versioned save; it never sends externally. */
    public static function append(array $case, string $event): array
    {
        $stage = self::code($case['stage'] ?? 'DRAFT', 'DRAFT');
        $exception = self::exception($case['exception'] ?? null);
        $previous = (array) ($case['notification_state'] ?? []);
        if (($previous['stage'] ?? null) === $stage && ($previous['exception'] ?? '') === $exception) {
            return $case;
        }
        $settings = (array) get_option('dbcl_settings', []);
        $kind = $exception !== '' ? 'EXCEPTION_CHANGED' : 'STAGE_CHANGED';
        $copy = self::copy($stage, $exception);
        $case = self::add($case, $event, $kind, $copy['title'], $copy['message'], $settings, time());
        $case['notification_state'] = ['stage' => $stage, 'exception' => $exception, 'stage_entered_at' => gmdate('c')];
        return $case;
    }

    private static function recipients(array $case): array
    {
        $ids = [];
        foreach (($case['parties'] ?? []) as $party) {
            if ((int) ($party['user_id'] ?? 0) > 0) { $ids[] = (int) $party['user_id']; }
        }
        if ((int) ($case['assigned_id'] ?? 0) > 0) { $ids[] = (int) $case['assigned_id']; }
        foreach (($case['staff_assignments'] ?? []) as $id => $role) {
            if ((int) $id > 0) { $ids[] = (int) $id; }
        }
        $ids = array_values(array_unique($ids));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    /** Recheck current assignment and each party's communication consent at delivery time. */
    private static function external_recipients(array $case, array $recipients): array
    {
        $current = self::recipients($case);
        $allowed = [];
        foreach ($recipients as $uid) {
            $uid = (int) $uid;
            if (!in_array($uid, $current, true)) { continue; }
            $party_found = false;
            foreach (($case['parties'] ?? []) as $party) {
                if ((int) ($party['user_id'] ?? 0) !== $uid) { continue; }
                $party_found = true;
                if (!empty($party['consents']['communications']['accepted'])) { $allowed[] = $uid; }
                break;
            }
            // Assigned staff receive operational notices under the configured staff channel.
            if (!$party_found) { $allowed[] = $uid; }
        }
        return array_values(array_unique($allowed));
    }

    private static function code($value, string $fallback = ''): string
    {
        return is_string($value) && preg_match('/^[A-Z][A-Z0-9_]{0,63}$/D', $value) ? $value : $fallback;
    }

    private static function exception($value): string
    {
        if (is_array($value)) { $value = $value['status'] ?? $value['state'] ?? ''; }
        return self::code($value);
    }

    private static function copy(string $stage, string $exception): array
    {
        if ($exception !== '') {
            return ['title' => 'Application review update', 'message' => 'Your application needs attention. Sign in to review the current status and your next action.'];
        }
        $messages = [
            'DRAFT' => ['Application saved', 'Complete each participant profile and the original-document checklist to continue.'],
            'DOCUMENT_REVIEW' => ['Document review', 'Your original-document checklist is being reviewed. Check the portal for any correction request.'],
            'IDENTITY_KYC_PENDING' => ['Identity verification', 'Review your own verification consent and complete the requested KYC steps.'],
            'READY_FOR_ASSIGNMENT' => ['Officer assignment', 'Your application is waiting for a credit officer assignment.'],
            'BC_RESPONSE_PENDING' => ['Partner review', 'The BC partner response is pending. A pending response is not a rejection.'],
            'COUNSELLING_PENDING' => ['Counselling', 'Check your meeting details and acknowledge the information after counselling.'],
            'INITIAL_DOCUMENTATION_PENDING' => ['Initial loan documents', 'Review the initial loan terms and your required signatures.'],
            'INITIAL_MANDATE_PENDING' => ['Initial loan authorization', 'Review the separate initial-loan repayment mandate and your authorization.'],
            'INITIAL_DISBURSEMENT_PENDING' => ['Initial loan payment', 'The initial loan payment is pending. Payment initiation is not settlement confirmation.'],
            'RETURN_COLLECTION_PENDING' => ['Separate return collection', 'Review the separate INR 10,000 return collection, its named recipient and settlement status. It does not close the original loan.'],
            'SLT_MEMBERSHIP_PENDING' => ['SLT membership', 'Review the Shubh Labh Trust membership terms and separate INR 25,000 contribution obligation.'],
            'SLT_MANDATE_PENDING' => ['Separate SLT authorization', 'Review the one-time INR 25,000 SLT contribution mandate. Mandate registration is not a debit or a receipt.'],
            'VERIFICATION_PENDING' => ['Verification tasks', 'Required verification tasks are pending. Check for any visit or clarification request.'],
            'BC_QUERY_PENDING' => ['Partner clarification', 'Check the portal for customer-facing clarification requests and their due dates.'],
            'BC_DOCUMENTATION_PENDING' => ['BC loan documents', 'Review the final BC loan terms and the signatures assigned to you.'],
            'BC_MANDATE_PENDING' => ['BC repayment authorization', 'Review any separate repayment mandate required for the BC loan.'],
            'INITIAL_LENDER_CLOSURE_PENDING' => ['Initial lender confirmation', 'Initial lender repayment or closure confirmation is pending independently of the separate return collection.'],
            'DB_KIT_PENDING' => ['Disbursement kit', 'The disbursement documentation package is being prepared or awaits partner acceptance.'],
            'BC_DISBURSEMENT_PENDING' => ['BC loan disbursement', 'Final BC loan disbursement is pending. A submitted transfer is not confirmed receipt.'],
            'SLT_COLLECTION_SCHEDULED' => ['SLT contribution schedule', 'Review the separately authorized SLT contribution due date and notice. No debit is implied by this reminder.'],
            'SLT_COLLECTION_PENDING' => ['SLT contribution status', 'The one-time SLT contribution is awaiting confirmed settlement. Check its separate status and receipt.'],
            'COMPLETED' => ['Application workflow completed', 'The workflow is completed. Review your separate obligations, confirmed receipts and servicing information.'],
        ];
        $copy = $messages[$stage] ?? ['Application update', 'Sign in to review your application status and the next action assigned to you.'];
        return ['title' => $copy[0], 'message' => $copy[1]];
    }

    private static function add(array $case, string $event, string $kind, string $title, string $message, array $settings, int $now): array
    {
        $case['notifications'] = is_array($case['notifications'] ?? null) ? $case['notifications'] : [];
        $event = substr(sanitize_key($event), 0, 64);
        $key = hash('sha256', (string) ($case['id'] ?? '') . ':' . $event . ':' . ((int) ($case['version'] ?? 0) + 1));
        foreach ($case['notifications'] as $notice) {
            if (hash_equals((string) ($notice['dedupe_key'] ?? ''), $key)) { return $case; }
        }
        $enabled = !empty($settings['notifications_enabled']);
        $adapter = has_filter('dbcl_deliver_notification') !== false;
        $id = wp_generate_uuid4();
        $recipients = self::recipients($case);
        $external_recipients = self::external_recipients($case, $recipients);
        $case['notifications'][$id] = [
            'id' => $id, 'application_id' => (string) ($case['id'] ?? ''), 'dedupe_key' => $key,
            'kind' => $kind, 'event' => $event, 'stage' => self::code($case['stage'] ?? 'DRAFT', 'DRAFT'),
            'exception' => self::exception($case['exception'] ?? null), 'title' => $title, 'message' => $message,
            'recipients' => $recipients, 'read_by' => [], 'read_at' => [], 'created_at' => gmdate('c', $now),
            'delivery' => [
                'state' => $enabled && $adapter && $external_recipients ? 'PENDING' : 'DISABLED',
                'source' => 'IN_APP', 'attempted_at' => null, 'recipient_ids' => $external_recipients,
                'reason_code' => !$enabled ? 'EXTERNAL_CHANNELS_DISABLED' : (!$adapter ? 'ADAPTER_NOT_CONFIGURED' : (!$external_recipients ? 'NO_AUTHORIZED_RECIPIENTS' : '')),
            ],
        ];
        return $case;
    }

    public static function listing(\WP_REST_Request $request)
    {
        $case = Store::get((string) $request['id']);
        if (is_wp_error($case)) { return $case; }
        $access = Auth::access($case);
        if (is_wp_error($access)) { return $access; }
        return self::visible($case, get_current_user_id());
    }

    private static function visible(array $case, int $uid): array
    {
        $notices = [];
        $unread = 0;
        foreach (($case['notifications'] ?? []) as $notice) {
            if (!in_array($uid, (array) ($notice['recipients'] ?? []), true)) { continue; }
            $is_read = in_array($uid, (array) ($notice['read_by'] ?? []), true);
            if (!$is_read) { $unread++; }
            $item = array_intersect_key($notice, array_flip(['id', 'application_id', 'kind', 'stage', 'exception', 'title', 'message', 'created_at']));
            $item['read'] = $is_read;
            $item['read_at'] = $is_read ? ($notice['read_at'][$uid] ?? true) : null;
            // Customer-facing delivery status never exposes provider references or other recipients.
            $item['external_delivery_state'] = in_array($uid, (array) ($notice['delivery']['recipient_ids'] ?? []), true) ? ($notice['delivery']['state'] ?? 'DISABLED') : 'DISABLED';
            $item['delivery_status'] = $item['external_delivery_state'];
            $notices[] = $item;
        }
        usort($notices, static fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
        return ['notifications' => $notices, 'unread_count' => $unread, 'version' => (int) $case['version']];
    }

    public static function mark_read(\WP_REST_Request $request)
    {
        $p = $request->get_json_params() ?: $request->get_params();
        $case = Store::get((string) ($p['application_id'] ?? ''));
        if (is_wp_error($case)) { return $case; }
        $access = Auth::access($case, true);
        if (is_wp_error($access)) { return $access; }
        $id = (string) $request['notification_id'];
        $uid = get_current_user_id();
        if (!isset($case['notifications'][$id]) || !in_array($uid, (array) ($case['notifications'][$id]['recipients'] ?? []), true)) { return Auth::denied(); }
        if (in_array($uid, (array) ($case['notifications'][$id]['read_by'] ?? []), true)) { return self::visible($case, $uid); }
        if ((int) ($p['expected_version'] ?? 0) !== (int) $case['version']) {
            return new \WP_Error('dbcl_conflict', 'This record changed. Reload notifications before marking one as read.', ['status' => 409]);
        }
        $case['notifications'][$id]['read_by'][] = $uid;
        $case['notifications'][$id]['read_at'][$uid] = gmdate('c');
        $saved = Store::save($case, (int) $p['expected_version'], $uid, 'notification_read', ['count' => 1]);
        return is_wp_error($saved) ? $saved : self::visible($saved, $uid);
    }

    private static function timestamp($value): int
    {
        if (!is_string($value) || $value === '') { return 0; }
        try { return (new \DateTimeImmutable($value, new \DateTimeZone('UTC')))->getTimestamp(); }
        catch (\Throwable $e) { return 0; }
    }

    /** Internal cron only. It never initiates a payment or debit. */
    public static function run_reminders(string $now_utc = ''): void
    {
        $now = self::timestamp($now_utc) ?: time();
        $settings = (array) get_option('dbcl_settings', []);
        $sla = max(1, min(720, (int) ($settings['sla_hours'] ?? 48))) * HOUR_IN_SECONDS;
        $page = 1;
        do {
            $queue = Store::list(['all' => true], $page, 50);
            foreach ($queue['rows'] as $row) {
                $case = Store::get((string) $row['id']);
                if (is_wp_error($case)) { continue; }
                $updated = self::timestamp($case['notification_state']['stage_entered_at'] ?? null) ?: self::timestamp($case['created_at'] ?? null);
                $last = self::timestamp($case['last_reminder_at'] ?? null);
                $terminal = ($case['stage'] ?? '') === 'COMPLETED' || in_array(self::exception($case['exception'] ?? null), ['REJECTED', 'EXPIRED', 'ABANDONED', 'CLIENT_DECLINED'], true);
                if (!$terminal && $updated > 0 && $now - $updated >= $sla && ($last === 0 || $now - $last >= $sla)) {
                    $case = self::add($case, 'sla_reminder', 'SLA_REMINDER', 'Application action reminder', 'Your application has an outstanding action. Sign in to review its status, due dates and the next step. This reminder does not authorize any payment.', $settings, $now);
                    $case['last_reminder_at'] = gmdate('c', $now);
                    $saved = Store::save($case, (int) $case['version'], 0, 'sla_reminder_created', ['count' => 1]);
                    if (!is_wp_error($saved)) { $case = $saved; }
                }
                self::deliver((string) $case['id'], $settings, $now);
            }
            $page++;
        } while (($page - 1) * 50 < (int) $queue['total']);
    }

    private static function deliver(string $application_id, array $settings, int $now): void
    {
        $case = Store::get($application_id);
        if (is_wp_error($case)) { return; }
        $timeout = max(60, min(3600, (int) ($settings['notification_processing_timeout_seconds'] ?? 300)));
        foreach (array_keys($case['notifications'] ?? []) as $id) {
            $case = Store::get($application_id);
            if (is_wp_error($case) || !isset($case['notifications'][$id])) { continue; }
            $notice = $case['notifications'][$id];
            $state = $notice['delivery']['state'] ?? 'DISABLED';
            if ($state === 'PROCESSING') {
                $started = self::timestamp($notice['delivery']['attempted_at'] ?? null);
                if ($started === 0 || $now - $started >= $timeout) {
                    $case['notifications'][$id]['delivery']['state'] = 'UNKNOWN';
                    $case['notifications'][$id]['delivery']['reason_code'] = 'DELIVERY_OUTCOME_UNCONFIRMED';
                    $case['notifications'][$id]['delivery']['updated_at'] = gmdate('c', $now);
                    Store::save($case, (int) $case['version'], 0, 'notification_delivery_unknown', ['status' => 'UNKNOWN']);
                }
                continue;
            }
            if ($state !== 'PENDING' || empty($settings['notifications_enabled']) || has_filter('dbcl_deliver_notification') === false) { continue; }
            $external_recipients = self::external_recipients($case, (array) ($notice['recipients'] ?? []));
            if (!$external_recipients) {
                $case['notifications'][$id]['delivery']['state'] = 'DISABLED';
                $case['notifications'][$id]['delivery']['recipient_ids'] = [];
                $case['notifications'][$id]['delivery']['reason_code'] = 'NO_AUTHORIZED_RECIPIENTS';
                Store::save($case, (int) $case['version'], 0, 'notification_delivery_disabled', ['status' => 'DISABLED']);
                continue;
            }
            $attempt = wp_generate_uuid4();
            $case['notifications'][$id]['delivery'] = array_merge($notice['delivery'], [
                'state' => 'PROCESSING', 'source' => 'CONFIGURED_ADAPTER', 'attempt_id' => $attempt, 'recipient_ids' => $external_recipients,
                'attempted_at' => gmdate('c', $now), 'reason_code' => '',
            ]);
            $claimed = Store::save($case, (int) $case['version'], 0, 'notification_delivery_started', ['status' => 'PROCESSING']);
            if (is_wp_error($claimed)) { continue; }
            $payload = array_intersect_key($notice, array_flip(['id', 'application_id', 'kind', 'stage', 'exception', 'title', 'message', 'recipients', 'created_at']));
            $payload['recipients'] = $external_recipients;
            $result = ['state' => 'UNKNOWN', 'reason_code' => 'DELIVERY_OUTCOME_UNCONFIRMED'];
            try {
                $response = apply_filters('dbcl_deliver_notification', null, $payload, ['attempt_id' => $attempt, 'idempotency_key' => $id]);
                if (is_array($response) && in_array($response['status'] ?? '', ['DELIVERED', 'FAILED', 'UNKNOWN'], true)) {
                    $result['state'] = $response['status'];
                    $result['reason_code'] = $response['status'] === 'DELIVERED' ? '' : ($response['status'] === 'FAILED' ? 'ADAPTER_REPORTED_FAILURE' : 'DELIVERY_OUTCOME_UNCONFIRMED');
                    if (!empty($response['reference']) && is_scalar($response['reference'])) { $result['reference'] = substr(sanitize_text_field((string) $response['reference']), 0, 200); }
                }
            } catch (\Throwable $e) {
                // A crash or timeout can occur after a message was sent; do not resend blindly.
                $result['reason_code'] = 'ADAPTER_EXCEPTION_OUTCOME_UNKNOWN';
            }
            $result['updated_at'] = gmdate('c', $now);
            for ($retry = 0; $retry < 3; $retry++) {
                $latest = Store::get($application_id);
                if (is_wp_error($latest) || ($latest['notifications'][$id]['delivery']['attempt_id'] ?? '') !== $attempt || ($latest['notifications'][$id]['delivery']['state'] ?? '') !== 'PROCESSING') { break; }
                $latest['notifications'][$id]['delivery'] = array_merge($latest['notifications'][$id]['delivery'], $result);
                $saved = Store::save($latest, (int) $latest['version'], 0, 'notification_delivery_result', ['status' => $result['state']]);
                if (!is_wp_error($saved) || $saved->get_error_code() !== 'dbcl_conflict') { break; }
            }
        }
    }
}
