<?php
namespace DigitalBE\ClientGroupLoans;

/** Server-controlled business commands. No command initiates a bank transfer or debit. */
final class Workflow {
    public const ROLES = ['applicant', 'co_applicant', 'guarantor_1', 'guarantor_2'];
    public const DOCUMENTS = ['aadhaar_front', 'aadhaar_back', 'identity_proof', 'live_photo', 'relationship_proof', 'address_proof', 'signature_specimen', 'bank_passbook'];

    public static function initial(array $input, int $owner_id): array {
        $parties = [];
        foreach (self::ROLES as $role) {
            $parties[$role] = ['id' => self::uuid(), 'user_id' => $role === 'applicant' ? $owner_id : 0, 'profile' => [], 'consents' => [], 'documents' => [], 'kyc' => [], 'bank' => []];
        }
        return [
            'id' => self::uuid(), 'group_id' => self::uuid(), 'org_id' => max(1, (int) ($input['org_id'] ?? 1)),
            'branch' => self::text($input['branch'] ?? 'Head Office'), 'owner_id' => $owner_id, 'assigned_id' => 0,
            'version' => 1, 'stage' => 'DRAFT', 'exception' => null,
            'product' => self::text($input['product'] ?? 'Client and Group Loan'),
            'requested_amount_paise' => max(0, (int) ($input['requested_amount_paise'] ?? 0)),
            'loan_purpose' => self::text($input['loan_purpose'] ?? ''),
            'parties' => $parties, 'documents_submitted' => false,
            'policy' => [
                'version' => '1', 'financial_operations_enabled' => false, 'required_documents' => self::DOCUMENTS,
                'required_signers' => self::ROLES, 'initial_mandate_required' => true, 'bc_mandate_required' => true,
                'initial_closure_required' => true, 'allow_manual_evidence' => true,
                'allow_unscanned_manual_review' => false, 'slt_notice_hours' => 24,
                'identity_kyc_operations' => ['pan-advanced-v3', 'digilocker-download'],
                'surepass_environment' => 'sandbox',
            ],
            'bc_enrolment' => [], 'counselling' => [], 'loans' => ['initial' => [], 'bc' => []],
            'return_collection' => ['id' => self::uuid(), 'amount_paise' => 1000000, 'status' => 'PENDING'],
            'slt' => ['id' => self::uuid(), 'amount_paise' => 2500000, 'recipient' => 'Shubh Labh Trust', 'frequency' => 'ONE_TIME', 'status' => 'PENDING'],
            'mandates' => [], 'verifications' => ['fvr' => [], 'bvr' => []], 'queries' => [], 'db_kit' => [],
            'financial_observations' => [], 'created_at' => self::now(), 'updated_at' => self::now(),
        ];
    }

    /** UI/REST command metadata. Amounts are integer paise; timestamps are UTC. */
    public static function specs(): array {
        $s = [];
        $role = self::f('select', 'Party', true, self::ROLES);
        $purpose = self::f('select', 'Financial purpose', true, ['initial_disbursement', 'return_collection', 'initial_repayment', 'bc_disbursement', 'slt_contribution']);
        $loan = self::f('select', 'Loan', true, ['initial', 'bc']);
        $mandate = self::f('select', 'Mandate purpose', true, ['initial', 'bc', 'slt']);
        $ref = self::f('text', 'External/provider reference');
        $evidence = self::f('text', 'Authoritative evidence reference');
        $reason = self::f('textarea', 'Reason / observations');
        $s['submit_documents'] = self::spec('Submit group documents for review', 'party', []);
        $s['review_document'] = self::spec('Review original document', 'dbcl_review', ['party_role' => $role, 'document_id' => self::f('text', 'Document ID'), 'decision' => self::f('select', 'Review decision', true, ['ACCEPTED', 'CORRECTION_REQUIRED', 'REJECTED']), 'original_confirmed' => self::f('checkbox', 'Original document observed', false), 'reason' => $reason]);
        $s['assign_officer'] = self::spec('Assign credit officer', 'dbcl_assign', ['officer_id' => self::f('number', 'Credit officer WordPress user ID'), 'reason' => $reason]);
        $s['record_bank_verification'] = self::spec('Record bank verification evidence', 'dbcl_review', ['party_role' => $role, 'result' => self::f('select', 'Result', true, ['PASS', 'FAIL', 'REVIEW_REQUIRED']), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['record_bc_enrolment'] = self::spec('Record BC partner enrolment / eligibility', 'dbcl_review', ['partner' => self::f('text', 'BC partner legal name'), 'reference' => $ref, 'result' => self::f('select', 'Partner response', true, ['PENDING', 'PASS', 'QUERY', 'REJECTED']), 'valid_until' => self::f('datetime-local', 'Approval valid until (UTC)', false), 'evidence_ref' => $evidence, 'reason' => $reason]);
        $s['schedule_counselling'] = self::spec('Schedule Google Meet counselling', 'dbcl_review', ['meeting_url' => self::f('url', 'Google Meet HTTPS link'), 'scheduled_at' => self::f('datetime-local', 'Meeting time (UTC)'), 'reference' => $ref]);
        $s['complete_counselling'] = self::spec('Record completed counselling', 'dbcl_review', ['attended_roles' => self::f('text', 'Attended roles (comma separated)'), 'checklist_confirmed' => self::f('checkbox', 'Initial loan, separate return, BC terms and SLT obligations explained'), 'evidence_ref' => $evidence, 'notes' => self::f('textarea', 'Questions and answers', false)]);
        $s['acknowledge_counselling'] = self::spec('Acknowledge counselling for my party', 'party', ['confirmed' => self::f('checkbox', 'I attended and understood the separately disclosed obligations')]);
        $s['set_loan_terms'] = self::spec('Create / version actual loan terms', 'dbcl_review', ['loan' => $loan, 'lender' => self::f('text', 'Actual lender legal name'), 'lender_beneficiary_ref' => self::f('text', 'Verified lender receiving-account reference (required before repayment)', false), 'lender_bank_evidence_ref' => self::f('text', 'Lender receiving-account verification evidence', false), 'amount_paise' => self::f('number', 'Principal (paise; initial is 1000000)'), 'net_disbursement_paise' => self::f('number', 'Net disbursement (paise)', false), 'borrower_role' => $role, 'beneficiary_role' => $role, 'allocations_json' => self::f('textarea', 'Optional borrower allocation JSON, role: paise', false), 'terms_version' => self::f('text', 'Approved terms version'), 'terms_text' => self::f('textarea', 'Approved loan terms, repayment obligations and disclosures'), 'annual_interest_bps' => self::f('number', 'Annual interest in basis points', false), 'tenure_months' => self::f('number', 'Tenure in months'), 'repayment_frequency' => self::f('select', 'Repayment frequency', true, ['MONTHLY', 'SEMI_MONTHLY']), 'processing_fee_paise' => self::f('number', 'Processing fee in paise', false), 'other_charges_paise' => self::f('number', 'Other disclosed charges in paise', false), 'expected_disbursement_at' => self::f('datetime-local', 'Expected disbursement date for indicative KFS (UTC)', false), 'first_due_at' => self::f('datetime-local', 'First repayment date (UTC)')]);
        $s['set_return_collection'] = self::spec('Configure separate INR 10,000 return', 'dbcl_review', ['recipient' => self::f('text', 'Approved receiving legal entity'), 'purpose' => self::f('textarea', 'Approved contractual purpose'), 'beneficiary_ref' => self::f('text', 'Verified receiving bank reference'), 'evidence_ref' => $evidence, 'terms_version' => self::f('text', 'Authorization terms version'), 'terms_text' => self::f('textarea', 'Separate collection authorization terms'), 'due_at' => self::f('datetime-local', 'Due date (UTC)')]);
        $s['set_slt_terms'] = self::spec('Configure separate one-time SLT contribution', 'dbcl_operate', ['purpose' => self::f('textarea', 'Contribution / membership purpose'), 'beneficiary_ref' => self::f('text', 'SLT verified bank beneficiary reference'), 'payer_role' => $role, 'terms_version' => self::f('text', 'Approved SLT membership terms version'), 'terms_text' => self::f('textarea', 'Purpose, optional/required status, cancellation, refund and grievance terms'), 'due_at' => self::f('datetime-local', 'Authorized collection date (UTC)'), 'evidence_ref' => $evidence]);
        $s['accept_terms'] = self::spec('Accept terms as my own party', 'party', ['purpose' => self::f('select', 'Terms purpose', true, ['initial', 'bc', 'return_collection', 'slt']), 'terms_version' => self::f('text', 'Terms version shown'), 'confirmed' => self::f('checkbox', 'I accept these exact terms and separate obligations')]);
        $s['record_signature'] = self::spec('Record executed document evidence', 'dbcl_operate', ['purpose' => self::f('select', 'Execution purpose', true, ['initial', 'bc', 'slt']), 'party_role' => $role, 'status' => self::f('select', 'Signature result', true, ['COMPLETED', 'PENDING', 'FAILED', 'EXPIRED', 'DECLINED']), 'terms_hash' => self::f('text', 'Exact executed terms SHA-256'), 'reference' => $ref, 'evidence_ref' => $evidence, 'document_hash' => self::f('text', 'Executed document SHA-256')]);
        $s['prepare_mandate'] = self::spec('Prepare purpose-bound mandate record', 'dbcl_operate', ['purpose' => $mandate, 'payer_role' => $role, 'beneficiary_ref' => self::f('text', 'Verified beneficiary reference'), 'amount_paise' => self::f('number', 'Authorized ceiling / amount (paise)'), 'frequency' => self::f('select', 'Frequency', true, ['ONE_TIME', 'MONTHLY', 'SEMI_MONTHLY']), 'valid_from' => self::f('datetime-local', 'Valid from (UTC)'), 'valid_until' => self::f('datetime-local', 'Valid until (UTC)')]);
        $s['accept_mandate'] = self::spec('Authorize my separate mandate', 'party', ['purpose' => $mandate, 'mandate_id' => self::f('text', 'Mandate record ID'), 'confirmed' => self::f('checkbox', 'I authorize this stated purpose, beneficiary, amount and frequency')]);
        $s['withdraw_mandate'] = self::spec('Withdraw my mandate authorization', 'party', ['purpose' => $mandate, 'mandate_id' => self::f('text', 'Mandate record ID'), 'reason' => self::f('textarea', 'Withdrawal reason')]);
        $s['record_mandate'] = self::spec('Record external mandate result', 'dbcl_operate', ['purpose' => $mandate, 'mandate_id' => self::f('text', 'Exact registered mandate ID'), 'status' => self::f('select', 'Provider result', true, ['PENDING', 'ACTIVE', 'FAILED', 'REJECTED', 'CANCELLED']), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['record_slt_notice'] = self::spec('Record SLT collection notice delivery', 'dbcl_operate', ['delivered_at' => self::f('datetime-local', 'Delivered at (UTC)'), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['assign_verification'] = self::spec('Assign FVR / BVR task', 'dbcl_assign', ['type' => self::f('select', 'Verification', true, ['fvr', 'bvr']), 'officer_id' => self::f('number', 'Verification officer WordPress user ID'), 'due_at' => self::f('datetime-local', 'Due date (UTC)'), 'reason' => $reason]);
        $s['record_verification'] = self::spec('Record assigned FVR / BVR result', 'dbcl_verify', ['type' => self::f('select', 'Verification', true, ['fvr', 'bvr']), 'result' => self::f('select', 'Result (completion alone does not pass)', true, ['PASS', 'FAIL', 'REVIEW_REQUIRED', 'REVISIT_REQUIRED']), 'checklist' => self::f('textarea', 'Versioned checklist answers and findings'), 'evidence_ref' => $evidence]);
        $s['open_query'] = self::spec('Open blocking BC query', 'dbcl_review', ['description' => self::f('textarea', 'Partner query'), 'reference' => $ref, 'due_at' => self::f('datetime-local', 'Due date (UTC)'), 'blocking' => self::f('checkbox', 'Blocks fulfilment / disbursement', false)]);
        $s['respond_query'] = self::spec('Submit response to query', 'dbcl_review', ['query_id' => self::f('text', 'Query ID'), 'response' => self::f('textarea', 'Response'), 'evidence_ref' => $evidence]);
        $s['close_query'] = self::spec('Record partner query closure', 'dbcl_review', ['query_id' => self::f('text', 'Query ID'), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['prepare_kit'] = self::spec('Prepare immutable DB kit snapshot', 'dbcl_operate', ['reference' => self::f('text', 'Pack reference'), 'evidence_ref' => self::f('text', 'Approved checklist / pack evidence reference')]);
        $s['submit_kit'] = self::spec('Record DB kit submission', 'dbcl_operate', ['reference' => $ref, 'evidence_ref' => $evidence]);
        $s['accept_kit'] = self::spec('Record partner acceptance of current DB kit', 'dbcl_operate', ['reference' => $ref, 'evidence_ref' => $evidence]);
        $s['prepare_payment'] = self::spec('Prepare external payment / collection instruction', 'dbcl_finance_make', ['purpose' => $purpose, 'amount_paise' => self::f('number', 'Exact amount (integer paise)'), 'beneficiary_ref' => self::f('text', 'Verified beneficiary / receiving account reference'), 'idempotency_key' => self::f('text', 'Unique idempotency key'), 'reference' => self::f('text', 'External request reference'), 'evidence_ref' => $evidence]);
        $s['check_payment'] = self::spec('Independently approve frozen financial instruction', 'dbcl_finance_check', ['purpose' => $purpose, 'instruction_id' => self::f('text', 'Instruction ID'), 'evidence_ref' => $evidence]);
        $s['record_submission'] = self::spec('Record external submission / unknown result', 'dbcl_finance_make', ['purpose' => $purpose, 'instruction_id' => self::f('text', 'Instruction ID'), 'reference' => $ref, 'result' => self::f('select', 'External response', true, ['SUBMITTED', 'UNKNOWN']), 'evidence_ref' => $evidence]);
        $s['record_settlement'] = self::spec('Reconcile authoritative bank / lender result', 'dbcl_finance_check', ['purpose' => $purpose, 'instruction_id' => self::f('text', 'Instruction ID'), 'result' => self::f('select', 'Reconciled outcome', true, ['SETTLED', 'FAILED', 'UNKNOWN', 'PENDING']), 'amount_paise' => self::f('number', 'Settlement amount (paise)'), 'currency' => self::f('select', 'Currency', true, ['INR']), 'beneficiary_ref' => self::f('text', 'Settled beneficiary reference'), 'settled_at' => self::f('datetime-local', 'Actual bank settlement/value date (UTC; required for SETTLED)', false), 'payment_mode' => self::f('select', 'Actual bank payment mode', false, ['BANK_TRANSFER', 'NEFT', 'RTGS', 'IMPS', 'UPI', 'ENACH']), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['record_reversal'] = self::spec('Record linked settled-payment reversal', 'dbcl_finance_check', ['purpose' => $purpose, 'instruction_id' => self::f('text', 'Original settled instruction ID'), 'amount_paise' => self::f('number', 'Reversed amount (paise)'), 'reference' => $ref, 'evidence_ref' => $evidence]);
        $s['close_initial_loan'] = self::spec('Record original lender-confirmed closure', 'dbcl_finance_check', ['lender_balance_paise' => self::f('number', 'Authoritative lender outstanding balance (paise)'), 'reference' => self::f('text', 'Lender / LMS closure reference'), 'evidence_ref' => $evidence]);
        $s['record_financial_observation'] = self::spec('Record external financial observation (does not settle)', 'dbcl_finance_make', ['purpose' => $purpose, 'amount_paise' => self::f('number', 'Observed amount (paise)'), 'reference' => $ref, 'evidence_ref' => $evidence, 'notes' => self::f('textarea', 'Observed event; pending authoritative reconciliation')]);
        $s['set_exception'] = self::spec('Place / clear case exception', 'dbcl_assign', ['exception' => self::f('select', 'Exception', true, ['HOLD', 'CORRECTION_REQUIRED', 'REVIEW_REQUIRED', 'REJECTED', 'EXPIRED', 'ABANDONED', 'CLIENT_DECLINED', 'CLEAR']), 'reason' => $reason]);
        return $s;
    }

    /** Structured gates are derived from component evidence, never an editable stage flag. */
    public static function evaluate(array $case): array {
        $g = [];
        $missing = self::document_blockers($case, false);
        $g['documents_present'] = self::gate($missing);
        $g['documents'] = self::gate(self::document_blockers($case, true));
        $b = [];
        $allowedKyc = $case['policy']['identity_kyc_operations'] ?? ['pan-advanced-v3', 'digilocker-download'];
        foreach (self::ROLES as $role) {
            $verified = false;
            foreach ($allowedKyc as $operation) if (self::kyc_verified($case['parties'][$role] ?? [], $operation, $case['policy'] ?? [])) $verified = true;
            if (!$verified) $b[] = 'IDENTITY_KYC_REQUIRED:' . $role;
            foreach (($case['policy']['required_kyc'] ?? []) as $operation) if (!self::kyc_verified($case['parties'][$role] ?? [], $operation, $case['policy'] ?? [])) $b[] = 'KYC_REQUIRED:' . $role . ':' . $operation;
        }
        $g['identity_kyc'] = self::gate($b);
        $g['assignment'] = self::gate((int) ($case['assigned_id'] ?? 0) > 0 ? [] : ['CREDIT_OFFICER_NOT_ASSIGNED']);
        $bc = $case['bc_enrolment'] ?? [];
        $b = [];
        if (($bc['result'] ?? '') !== 'PASS') $b[] = 'BC_ELIGIBILITY_NOT_PASSED';
        if (empty($bc['reference']) || empty($bc['evidence_ref'])) $b[] = 'BC_APPROVAL_EVIDENCE_MISSING';
        if (!empty($bc['valid_until']) && self::time($bc['valid_until']) < time()) $b[] = 'BC_APPROVAL_EXPIRED';
        $g['bc_eligibility'] = self::gate($b);
        $c = $case['counselling'] ?? [];
        $b = [];
        if (($c['status'] ?? '') !== 'COMPLETED') $b[] = 'COUNSELLING_NOT_COMPLETED';
        foreach (self::ROLES as $r) if (empty($c['acknowledgements'][$r])) $b[] = 'COUNSELLING_ACK_REQUIRED:' . $r;
        $g['counselling'] = self::gate($b);
        $g['initial_documentation'] = self::gate(self::loan_blockers($case, 'initial'));
        $g['initial_mandate'] = self::gate(!empty($case['policy']['initial_mandate_required']) ? self::mandate_blockers($case, 'initial') : []);
        $g['initial_disbursement'] = self::gate(self::settled_total($case['loans']['initial'] ?? []) >= 1000000 ? [] : ['INITIAL_DISBURSEMENT_UNCONFIRMED']);
        $ret = $case['return_collection'] ?? [];
        $b = [];
        if (empty($ret['recipient']) || empty($ret['purpose']) || empty($ret['beneficiary_ref'])) $b[] = 'RETURN_RECIPIENT_PURPOSE_NOT_CONFIGURED';
        if (!self::accepted($ret['terms']['accepted']['applicant'] ?? false, $ret['terms']['hash'] ?? '')) $b[] = 'RETURN_AUTHORIZATION_MISSING';
        if (self::settled_total($ret) !== 1000000) $b[] = 'RETURN_NOT_FULLY_RECONCILED';
        $g['return_collection'] = self::gate($b);
        $sl = $case['slt'] ?? [];
        $payer = $sl['payer_role'] ?? 'applicant';
        $b = [];
        if (($sl['recipient'] ?? '') !== 'Shubh Labh Trust' || (int) ($sl['amount_paise'] ?? 0) !== 2500000) $b[] = 'SLT_AMOUNT_OR_RECIPIENT_INVALID';
        if (empty($sl['purpose']) || empty($sl['beneficiary_ref']) || empty($sl['terms']['hash'])) $b[] = 'SLT_TERMS_NOT_CONFIGURED';
        if (!self::accepted($sl['terms']['accepted'][$payer] ?? false, $sl['terms']['hash'] ?? '')) $b[] = 'SLT_TERMS_NOT_ACCEPTED';
        if (!self::signature_valid($sl['signatures'][$payer] ?? [], $sl['terms']['hash'] ?? '')) $b[] = 'SLT_MEMBERSHIP_SIGNATURE_REQUIRED';
        $g['slt_membership'] = self::gate($b);
        $g['slt_mandate'] = self::gate(self::mandate_blockers($case, 'slt'));
        $b = [];
        foreach (['fvr', 'bvr'] as $t) {
            $v = $case['verifications'][$t] ?? [];
            if (($v['status'] ?? '') !== 'COMPLETED' || ($v['result'] ?? '') !== 'PASS' || empty($v['evidence_ref'])) $b[] = strtoupper($t) . '_NOT_PASSED';
        }
        $g['verifications'] = self::gate($b);
        $b = [];
        foreach (($case['queries'] ?? []) as $q) if (!empty($q['blocking']) && ($q['status'] ?? '') !== 'CLOSED') $b[] = 'BLOCKING_QUERY_OPEN:' . ($q['id'] ?? 'unknown');
        $g['queries'] = self::gate($b);
        $g['bc_documentation'] = self::gate(self::loan_blockers($case, 'bc'));
        $g['bc_mandate'] = self::gate(!empty($case['policy']['bc_mandate_required']) ? self::mandate_blockers($case, 'bc') : []);
        $b = [];
        if (!empty($case['policy']['initial_closure_required']) && (($case['loans']['initial']['status'] ?? '') !== 'CLOSED' || empty($case['loans']['initial']['closure']['evidence_ref']))) $b[] = 'INITIAL_LENDER_CLOSURE_NOT_CONFIRMED';
        $g['initial_closure'] = self::gate($b);
        $kit = $case['db_kit'] ?? [];
        $b = [];
        if (($kit['status'] ?? '') !== 'ACCEPTED' || empty($kit['acceptance']['evidence_ref'])) $b[] = 'DB_KIT_NOT_ACCEPTED';
        if (empty($kit['snapshot_hash']) || !hash_equals((string) ($kit['snapshot_hash'] ?? ''), self::kit_hash($case))) $b[] = 'DB_KIT_SNAPSHOT_STALE';
        $g['db_kit'] = self::gate($b);
        $bcLoan = $case['loans']['bc'] ?? [];
        $expected = (int) ($bcLoan['net_disbursement_paise'] ?? $bcLoan['amount_paise'] ?? 0);
        $g['bc_disbursement'] = self::gate($expected > 0 && self::settled_total($bcLoan) === $expected ? [] : ['BC_DISBURSEMENT_UNCONFIRMED']);
        $b = [];
        if (empty($sl['due_at']) || self::time($sl['due_at']) > time()) $b[] = 'AUTHORIZED_DUE_DATE_NOT_REACHED';
        $notice = $sl['notice'] ?? [];
        $hours = max(0, (int) ($case['policy']['slt_notice_hours'] ?? 24));
        if (empty($notice['evidence_ref']) || self::time($notice['delivered_at'] ?? '') + $hours * 3600 > time()) $b[] = 'SLT_NOTICE_NOT_SATISFIED';
        $g['slt_due'] = self::gate($b);
        $g['slt_collection'] = self::gate(self::settled_total($sl) === 2500000 ? [] : ['SLT_CONTRIBUTION_NOT_SETTLED']);
        return $g;
    }

    public static function apply(array $case, string $command, array $input, array $actor) {
        $spec = self::specs()[$command] ?? null;
        if (!$spec) return self::error('UNKNOWN_COMMAND', 'Unknown workflow command.', 400);
        $caps = $actor['capabilities'] ?? [];
        if (!in_array($spec['capability'], $caps, true) && empty($caps[$spec['capability']])) return self::error('FORBIDDEN', 'Your role cannot perform this command.', 403);
        $partyRole = null;
        if ($spec['capability'] === 'party') {
            $partyRole = $actor['party_role'] ?? null;
            if (!in_array($partyRole, self::ROLES, true) || (int) ($case['parties'][$partyRole]['user_id'] ?? 0) !== (int) ($actor['id'] ?? 0) || empty($actor['id'])) return self::error('PARTY_SESSION_REQUIRED', 'Use the relevant party’s own authenticated account.', 403);
        }
        foreach ($spec['fields'] as $key => $field) {
            if (empty($field['required'])) continue;
            if (!array_key_exists($key, $input) || !is_scalar($input[$key]) || trim((string) $input[$key]) === '') return self::error('FIELD_REQUIRED', $field['label'] . ' is required.', 422, ['field' => $key]);
            if ($field['type'] === 'checkbox' && !self::yes($input[$key])) return self::error('CONFIRMATION_REQUIRED', $field['label'] . ' must be confirmed.', 422, ['field' => $key]);
            if (isset($field['options']) && !in_array($input[$key], $field['options'], true)) return self::error('INVALID_OPTION', 'Select a supported ' . $field['label'] . '.', 422, ['field' => $key]);
        }
        $actorId = (int) ($actor['id'] ?? 0);
        $source = !empty($actor['provider']) ? 'PROVIDER_CONFIRMED' : 'OFFICER_REPORTED';
        $evidence = ['reference' => self::text($input['reference'] ?? ''), 'evidence_ref' => self::text($input['evidence_ref'] ?? ''), 'source' => $source, 'actor_id' => $actorId, 'recorded_at' => self::now()];
        try {
            switch ($command) {
                case 'submit_documents':
                    if ($partyRole !== 'applicant') return self::error('APPLICANT_REQUIRED', 'Only the applicant submits the group application.', 403);
                    if ($e = self::require_gates($case, ['documents_present'])) return $e;
                    $case['documents_submitted'] = true;
                    break;
                case 'review_document':
                    $r = $input['party_role']; $found = false;
                    foreach (($case['parties'][$r]['documents'] ?? []) as $key => $doc) {
                        if ((string) ($doc['id'] ?? $key) !== (string) $input['document_id']) continue;
                        $found = true;
                        if ($input['decision'] === 'ACCEPTED') {
                            if (!self::yes($input['original_confirmed'] ?? false)) return self::error('ORIGINAL_NOT_CONFIRMED', 'Confirm original-document observation; capture metadata alone cannot prove originality.');
                            $scan = strtoupper((string) ($doc['scan_status'] ?? $doc['scan']['status'] ?? ''));
                            if ($scan !== 'CLEAN' && empty($case['policy']['allow_unscanned_manual_review'])) return self::error('DOCUMENT_SCAN_REQUIRED', 'A clean malware scan is required before acceptance.');
                        }
                        $review = ['status' => $input['decision'], 'original_confirmed' => self::yes($input['original_confirmed'] ?? false), 'reason' => self::text($input['reason']), 'actor_id' => $actorId, 'reviewed_at' => self::now()];
                        $doc['review_history'][] = $review; $doc['review'] = $review;
                        $case['parties'][$r]['documents'][$key] = $doc;
                        self::invalidate_kit($case, 'DOCUMENT_REVIEW_CHANGED');
                        break;
                    }
                    if (!$found) return self::error('DOCUMENT_NOT_FOUND', 'Document not found.', 404);
                    break;
                case 'assign_officer':
                    if ($e = self::require_gates($case, ['documents', 'identity_kyc'])) return $e;
                    $id = self::positive($input['officer_id']);
                    if ($id === null) return self::error('INVALID_OFFICER', 'A valid officer user ID is required.');
                    $case['assignments'][] = ['previous_id' => $case['assigned_id'] ?? 0, 'officer_id' => $id, 'reason' => self::text($input['reason']), 'actor_id' => $actorId, 'at' => self::now()];
                    $case['assigned_id'] = $id;
                    break;
                case 'record_bank_verification':
                    $r = $input['party_role']; $bank = $case['parties'][$r]['bank'] ?? [];
                    if (empty($bank['account_number']) || empty($bank['ifsc'])) return self::error('BANK_DETAILS_REQUIRED', 'Capture the actual account number and IFSC before bank verification.');
                    $case['parties'][$r]['bank']['verification'] = $evidence + ['result' => $input['result'], 'bank_hash' => self::bank_hash($bank)];
                    self::invalidate_kit($case, 'BANK_VERIFICATION_CHANGED');
                    break;
                case 'record_bc_enrolment':
                    if ($e = self::require_gates($case, ['documents', 'identity_kyc', 'assignment'])) return $e;
                    $valid = empty($input['valid_until']) ? null : self::date($input['valid_until']);
                    if (!empty($input['valid_until']) && !$valid) return self::error('INVALID_DATE', 'Use a valid UTC approval expiry.');
                    $case['bc_enrolment_history'][] = $case['bc_enrolment'] ?? [];
                    $case['bc_enrolment'] = $evidence + ['partner' => self::text($input['partner']), 'result' => $input['result'], 'valid_until' => $valid, 'reason' => self::text($input['reason'])];
                    self::invalidate_kit($case, 'BC_APPROVAL_CHANGED');
                    break;
                case 'schedule_counselling':
                    if ($e = self::require_gates($case, ['bc_eligibility'])) return $e;
                    if (!preg_match('~^https://meet\.google\.com/[a-zA-Z0-9-]+(?:\?[^\s]*)?$~', $input['meeting_url'])) return self::error('INVALID_MEETING_LINK', 'Enter a Google Meet HTTPS meeting link.');
                    $date = self::date($input['scheduled_at']);
                    if (!$date) return self::error('INVALID_DATE', 'Use a valid UTC meeting date.');
                    $case['counselling_history'][] = $case['counselling'] ?? [];
                    $case['counselling'] = ['status' => 'SCHEDULED', 'meeting_url' => $input['meeting_url'], 'scheduled_at' => $date, 'reference' => self::text($input['reference']), 'acknowledgements' => []];
                    break;
                case 'complete_counselling':
                    if ($e = self::require_gates($case, ['bc_eligibility'])) return $e;
                    if (empty($case['counselling']['meeting_url'])) return self::error('MEETING_REQUIRED', 'Schedule or record the meeting first.');
                    $roles = self::role_list($input['attended_roles']);
                    if (array_diff(self::ROLES, $roles)) return self::error('ATTENDANCE_INCOMPLETE', 'All four required participants must attend counselling.');
                    $case['counselling'] = array_merge($case['counselling'], $evidence, ['status' => 'COMPLETED', 'attended_roles' => $roles, 'checklist_confirmed' => true, 'notes' => self::text($input['notes'] ?? ''), 'completed_at' => self::now()]);
                    break;
                case 'acknowledge_counselling':
                    if (($case['counselling']['status'] ?? '') !== 'COMPLETED') return self::error('COUNSELLING_INCOMPLETE', 'Completed counselling must be recorded before acknowledgement.');
                    $case['counselling']['acknowledgements'][$partyRole] = ['party_id' => $case['parties'][$partyRole]['id'], 'user_id' => $actorId, 'meeting_reference' => $case['counselling']['reference'], 'at' => self::now()];
                    break;
                case 'set_loan_terms':
                    if ($e = self::require_gates($case, ['identity_kyc', 'bc_eligibility', 'counselling'])) return $e;
                    $kind = $input['loan']; $old = $case['loans'][$kind] ?? [];
                    if (self::has_payment_activity($old)) return self::error('IMMUTABLE_FINANCIAL_RECORD', 'Loan terms cannot be rewritten after financial instruction activity.');
                    $amount = self::positive($input['amount_paise']);
                    $net = !array_key_exists('net_disbursement_paise', $input) || $input['net_disbursement_paise'] === '' ? $amount : self::positive($input['net_disbursement_paise']);
                    $tenure = self::positive($input['tenure_months']);
                    $rate = self::nonnegative($input['annual_interest_bps'] ?? 0);
                    if ($amount === null || $net === null || $net > $amount || $tenure === null || $tenure > 600 || $rate === null || $rate > 100000 || ($kind === 'initial' && ($amount !== 1000000 || $net !== 1000000))) return self::error('INVALID_LOAN_TERMS', 'Use valid integer paise, tenure and rate; the initial loan and disbursement are exactly INR 10,000.');
                    $due = self::date($input['first_due_at']);
                    if (!$due) return self::error('INVALID_DATE', 'Use a valid first repayment date.');
                    $disbursement = empty($input['expected_disbursement_at']) ? null : self::date($input['expected_disbursement_at']);
                    if (!empty($input['expected_disbursement_at']) && (!$disbursement || self::time($disbursement) >= self::time($due))) return self::error('INVALID_DATE', 'Expected disbursement must be a valid date before the first repayment.');
                    $alloc = [$input['borrower_role'] => $amount];
                    if (!empty($input['allocations_json'])) {
                        $alloc = json_decode($input['allocations_json'], true);
                        if (!is_array($alloc) || !$alloc || array_diff(array_keys($alloc), self::ROLES)) return self::error('INVALID_ALLOCATION', 'Allocation JSON must map actual borrower roles to positive integer paise.');
                        foreach ($alloc as $n) if (self::positive($n) === null) return self::error('INVALID_ALLOCATION', 'Every borrower allocation must be positive integer paise.');
                        if (array_sum($alloc) !== $amount) return self::error('INVALID_ALLOCATION', 'Actual borrower allocations must sum to the loan principal.');
                    }
                    $fee = self::nonnegative($input['processing_fee_paise'] ?? 0); $charges = self::nonnegative($input['other_charges_paise'] ?? 0);
                    if ($fee === null || $charges === null) return self::error('INVALID_CHARGES', 'Charges must be nonnegative integer paise.');
                    $terms = self::terms($input['terms_version'], $input['terms_text'], ['lender' => self::text($input['lender']), 'lender_beneficiary_ref' => self::text($input['lender_beneficiary_ref'] ?? ''), 'lender_bank_evidence_ref' => self::text($input['lender_bank_evidence_ref'] ?? ''), 'amount_paise' => $amount, 'net_disbursement_paise' => $net, 'allocations' => $alloc, 'beneficiary_role' => $input['beneficiary_role'], 'annual_interest_bps' => $rate, 'tenure_months' => $tenure, 'repayment_frequency' => $input['repayment_frequency'], 'processing_fee_paise' => $fee, 'other_charges_paise' => $charges, 'expected_disbursement_at' => $disbursement, 'first_due_at' => $due]);
                    $case['loan_term_history'][$kind][] = $old;
                    $case['loans'][$kind] = ['id' => $old['id'] ?? self::uuid(), 'kind' => strtoupper($kind), 'status' => 'DOCUMENTATION_PENDING', 'lender' => self::text($input['lender']), 'lender_beneficiary_ref' => self::text($input['lender_beneficiary_ref'] ?? ''), 'lender_bank_evidence_ref' => self::text($input['lender_bank_evidence_ref'] ?? ''), 'amount_paise' => $amount, 'net_disbursement_paise' => $net, 'borrower_allocations' => $alloc, 'beneficiary_role' => $input['beneficiary_role'], 'terms' => $terms, 'signatures' => []];
                    unset($case['mandates'][$kind]);
                    self::invalidate_kit($case, 'LOAN_TERMS_CHANGED');
                    break;
                case 'set_return_collection':
                    $old = $case['return_collection'] ?? [];
                    if (self::has_payment_activity($old)) return self::error('IMMUTABLE_FINANCIAL_RECORD', 'A collection with financial activity cannot be rewritten.');
                    $date = self::date($input['due_at']);
                    if (!$date) return self::error('INVALID_DATE', 'Use a valid return collection due date.');
                    $case['return_collection_history'][] = $old;
                    $case['return_collection'] = $evidence + ['id' => $old['id'] ?? self::uuid(), 'status' => 'PENDING', 'amount_paise' => 1000000, 'recipient' => self::text($input['recipient']), 'purpose' => self::text($input['purpose']), 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'due_at' => $date, 'terms' => self::terms($input['terms_version'], $input['terms_text'], ['amount_paise' => 1000000, 'recipient' => self::text($input['recipient']), 'purpose' => self::text($input['purpose']), 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'due_at' => $date])];
                    self::invalidate_kit($case, 'RETURN_TERMS_CHANGED');
                    break;
                case 'set_slt_terms':
                    $old = $case['slt'] ?? [];
                    if (self::has_payment_activity($old)) return self::error('IMMUTABLE_FINANCIAL_RECORD', 'A contribution with financial activity cannot be rewritten.');
                    $date = self::date($input['due_at']);
                    if (!$date) return self::error('INVALID_DATE', 'Use a valid authorized contribution due date.');
                    $case['slt_history'][] = $old;
                    $case['slt'] = $evidence + ['id' => $old['id'] ?? self::uuid(), 'status' => 'PENDING', 'amount_paise' => 2500000, 'recipient' => 'Shubh Labh Trust', 'frequency' => 'ONE_TIME', 'purpose' => self::text($input['purpose']), 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'payer_role' => $input['payer_role'], 'due_at' => $date, 'terms' => self::terms($input['terms_version'], $input['terms_text'], ['amount_paise' => 2500000, 'recipient' => 'Shubh Labh Trust', 'frequency' => 'ONE_TIME', 'payer_role' => $input['payer_role'], 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'due_at' => $date]), 'signatures' => []];
                    unset($case['mandates']['slt']); self::invalidate_kit($case, 'SLT_TERMS_CHANGED');
                    break;
                case 'accept_terms':
                    $record =& self::terms_record($case, $input['purpose']);
                    if (empty($record['terms']['hash']) || ($record['terms']['version'] ?? '') !== (string) $input['terms_version']) return self::error('TERMS_VERSION_CONFLICT', 'Read and accept the current exact terms version.', 409);
                    $record['terms']['accepted'][$partyRole] = ['accepted' => true, 'terms_hash' => $record['terms']['hash'], 'terms_version' => $record['terms']['version'], 'party_id' => $case['parties'][$partyRole]['id'], 'user_id' => $actorId, 'at' => self::now()];
                    unset($record);
                    break;
                case 'record_signature':
                    $purpose = $input['purpose']; $r = $input['party_role'];
                    $record =& self::terms_record($case, $purpose);
                    if (empty($record['terms']['hash'])) return self::error('TERMS_REQUIRED', 'Create approved terms before recording execution evidence.');
                    if (!hash_equals((string) $record['terms']['hash'], (string) $input['terms_hash'])) return self::error('TERMS_VERSION_CONFLICT', 'Execution evidence must match the exact current immutable terms version; an earlier signed version cannot sign newer terms.', 409);
                    if (!self::accepted($record['terms']['accepted'][$r] ?? false, $record['terms']['hash'])) return self::error('PARTY_ACCEPTANCE_REQUIRED', 'The relevant party must accept these exact terms in their own session.');
                    if (!preg_match('/^[a-f0-9]{64}$/i', $input['document_hash'])) return self::error('DOCUMENT_HASH_REQUIRED', 'Provide the executed immutable document SHA-256.');
                    if (empty($actor['provider']) && empty($case['policy']['allow_manual_evidence'])) return self::error('PROVIDER_CONFIRMATION_REQUIRED', 'This policy requires authenticated provider execution evidence.');
                    $record['signature_history'][$r][] = $record['signatures'][$r] ?? [];
                    $record['signatures'][$r] = $evidence + ['status' => $input['status'], 'terms_hash' => $record['terms']['hash'], 'document_hash' => strtolower($input['document_hash']), 'party_id' => $case['parties'][$r]['id']];
                    unset($record); self::invalidate_kit($case, 'SIGNATURE_CHANGED');
                    break;
                case 'prepare_mandate':
                    $purpose = $input['purpose']; $record =& self::terms_record($case, $purpose);
                    if (empty($record['id']) || empty($record['terms']['hash'])) return self::error('OBLIGATION_TERMS_REQUIRED', 'Create the separately identified obligation and approved terms first.');
                    $current = $case['mandates'][$purpose] ?? [];
                    if (in_array($current['status'] ?? '', ['ACTIVE', 'WITHDRAWAL_REQUESTED'], true)) return self::error('ACTIVE_MANDATE_EXISTS', 'Confirm external cancellation of the active or withdrawal-requested mandate before replacement.');
                    $amount = self::positive($input['amount_paise']); $from = self::date($input['valid_from']); $until = self::date($input['valid_until']);
                    if ($amount === null || !$from || !$until || self::time($until) <= self::time($from)) return self::error('INVALID_MANDATE', 'A valid amount and increasing validity window are required.');
                    if ($purpose === 'slt' && ($amount !== 2500000 || $input['frequency'] !== 'ONE_TIME' || $input['payer_role'] !== ($record['payer_role'] ?? '') || $input['beneficiary_ref'] !== ($record['beneficiary_ref'] ?? ''))) return self::error('SLT_MANDATE_MISMATCH', 'SLT requires its own exact INR 25,000 one-time authorization, payer and beneficiary.');
                    if (!self::bank_verified($case['parties'][$input['payer_role']]['bank'] ?? [], $case['policy'] ?? [])) return self::error('PAYER_BANK_NOT_VERIFIED', 'Verify the mandate payer’s current bank account for this environment first.');
                    $case['mandate_history'][$purpose][] = $current;
                    $case['mandates'][$purpose] = ['id' => self::uuid(), 'purpose' => $purpose, 'obligation_id' => $record['id'], 'status' => 'PENDING', 'provider_status' => 'NOT_SUBMITTED', 'payer_role' => $input['payer_role'], 'payer_bank_hash' => self::bank_hash($case['parties'][$input['payer_role']]['bank']), 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'amount_paise' => $amount, 'frequency' => $input['frequency'], 'valid_from' => $from, 'valid_until' => $until, 'terms_hash' => $record['terms']['hash'], 'created_by' => $actorId];
                    unset($record); self::invalidate_kit($case, 'MANDATE_PREPARED');
                    break;
                case 'accept_mandate':
                    $purpose = $input['purpose']; $m = $case['mandates'][$purpose] ?? [];
                    if (empty($m['id']) || $m['id'] !== $input['mandate_id'] || ($m['payer_role'] ?? '') !== $partyRole) return self::error('MANDATE_NOT_OWNED', 'Only the mandate’s named payer can authorize the exact current record.', 403);
                    if (!empty($m['authorization_withdrawal'])) return self::error('MANDATE_AUTHORIZATION_WITHDRAWN', 'A withdrawn authorization cannot be restored on the same mandate. Complete cancellation and authorize a fresh mandate record.');
                    if (($m['status'] ?? '') !== 'PENDING') return self::error('MANDATE_NOT_PENDING', 'Only a pending mandate can receive fresh authorization.');
                    $case['mandates'][$purpose]['authorization'] = ['accepted' => true, 'party_id' => $case['parties'][$partyRole]['id'], 'user_id' => $actorId, 'mandate_hash' => self::mandate_hash($m), 'at' => self::now()];
                    break;
                case 'withdraw_mandate':
                    $purpose = $input['purpose']; $m = $case['mandates'][$purpose] ?? [];
                    if (empty($m['id']) || $m['id'] !== $input['mandate_id'] || ($m['payer_role'] ?? '') !== $partyRole) return self::error('MANDATE_NOT_OWNED', 'Only the mandate’s named payer can withdraw authorization for the exact current record.', 403);
                    if (!empty($m['authorization_withdrawal'])) return $case;
                    if (!in_array($m['status'] ?? '', ['PENDING', 'ACTIVE'], true)) return self::error('MANDATE_NOT_WITHDRAWABLE', 'This mandate is already terminal; its recorded outcome and history remain unchanged.');
                    $reason = self::text($input['reason']);
                    if ($reason === '') return self::error('WITHDRAWAL_REASON_REQUIRED', 'A withdrawal reason is required.');
                    $providerStatus = (string) ($m['provider_status'] ?? $m['status']);
                    $withdrawal = ['mandate_id' => $m['id'], 'party_id' => $case['parties'][$partyRole]['id'], 'user_id' => $actorId, 'reason' => $reason, 'requested_at' => self::now(), 'prior_status' => $m['status'], 'prior_provider_status' => $providerStatus];
                    $m['authorization_withdrawal'] = $withdrawal;
                    $m['authorization_withdrawal_history'][] = $withdrawal;
                    $m['provider_status'] = $providerStatus;
                    $m['status'] = 'WITHDRAWAL_REQUESTED';
                    $case['mandates'][$purpose] = $m;
                    $case['mandate_events'][$purpose][] = $withdrawal + ['status' => 'WITHDRAWAL_REQUESTED', 'source' => 'PARTY_REQUEST'];
                    self::invalidate_kit($case, 'MANDATE_AUTHORIZATION_WITHDRAWN');
                    break;
                case 'record_mandate':
                    $purpose = $input['purpose']; $m = $case['mandates'][$purpose] ?? [];
                    if (!$m) return self::error('MANDATE_NOT_FOUND', 'Prepare a purpose-bound mandate first.', 404);
                    if (($m['id'] ?? '') !== $input['mandate_id']) return self::error('MANDATE_REFERENCE_CONFLICT', 'This provider result belongs to another mandate registration. Match the exact current registered mandate ID.', 409);
                    if (!empty($m['authorization_withdrawal']) && $input['status'] !== 'CANCELLED') return self::error('MANDATE_AUTHORIZATION_WITHDRAWN', 'Authorization has been withdrawn. A stale provider result cannot restore it; record cancellation evidence and obtain a fresh mandate authorization.');
                    if ($input['status'] === 'ACTIVE' && (empty($m['authorization']['accepted']) || !hash_equals((string) ($m['authorization']['mandate_hash'] ?? ''), self::mandate_hash($m)))) return self::error('MANDATE_AUTHORIZATION_REQUIRED', 'The exact payer authorization is required before recording activation.');
                    if (in_array($m['status'] ?? '', ['CANCELLED', 'REJECTED', 'FAILED'], true) && $input['status'] !== $m['status'] && $input['status'] !== 'CANCELLED') return self::error('TERMINAL_MANDATE', 'A cancelled, rejected or failed mandate needs a fresh registration and payer authorization; its current record cannot be reopened.');
                    if (empty($actor['provider']) && empty($case['policy']['allow_manual_evidence'])) return self::error('PROVIDER_CONFIRMATION_REQUIRED', 'This policy requires authenticated provider mandate evidence.');
                    $case['mandate_events'][$purpose][] = $evidence + ['status' => $input['status']];
                    $case['mandates'][$purpose] = array_merge($m, $evidence, ['status' => $input['status'], 'provider_status' => $input['status']]);
                    self::invalidate_kit($case, 'MANDATE_RESULT_CHANGED');
                    break;
                case 'record_slt_notice':
                    if (empty($case['slt']['terms']['hash'])) return self::error('SLT_TERMS_REQUIRED', 'Configure accepted SLT terms first.');
                    $date = self::date($input['delivered_at']);
                    if (!$date || self::time($date) > time()) return self::error('INVALID_NOTICE_DATE', 'Notice delivery must be an actual timestamp at or before now.');
                    $case['slt']['notice'] = $evidence + ['delivered_at' => $date, 'terms_hash' => $case['slt']['terms']['hash']];
                    break;
                case 'assign_verification':
                    if ($e = self::require_gates($case, ['initial_disbursement', 'return_collection', 'slt_membership', 'slt_mandate'])) return $e;
                    $id = self::positive($input['officer_id']); $due = self::date($input['due_at']);
                    if (!$id || !$due) return self::error('INVALID_ASSIGNMENT', 'Use an officer user ID and valid UTC due date.');
                    $type = $input['type']; $old = $case['verifications'][$type] ?? [];
                    $case['verification_history'][$type][] = $old;
                    $case['verifications'][$type] = ['id' => $old['id'] ?? self::uuid(), 'status' => 'ASSIGNED', 'assigned_id' => $id, 'due_at' => $due, 'reason' => self::text($input['reason']), 'assigned_by' => $actorId];
                    self::invalidate_kit($case, 'VERIFICATION_REASSIGNED');
                    break;
                case 'record_verification':
                    $type = $input['type']; $old = $case['verifications'][$type] ?? [];
                    if ((int) ($old['assigned_id'] ?? 0) !== $actorId) return self::error('VERIFICATION_NOT_ASSIGNED', 'Only the assigned verification officer may record this task’s result.', 403);
                    $case['verification_history'][$type][] = $old;
                    $case['verifications'][$type] = array_merge($old, $evidence, ['status' => 'COMPLETED', 'result' => $input['result'], 'checklist' => self::text($input['checklist']), 'completed_at' => self::now()]);
                    self::invalidate_kit($case, 'VERIFICATION_RESULT_CHANGED');
                    break;
                case 'open_query':
                    $date = self::date($input['due_at']);
                    if (!$date) return self::error('INVALID_DATE', 'Use a valid query due date.');
                    $case['queries'][] = ['id' => self::uuid(), 'status' => 'OPEN', 'description' => self::text($input['description']), 'reference' => self::text($input['reference']), 'due_at' => $date, 'blocking' => !array_key_exists('blocking', $input) || self::yes($input['blocking']), 'created_by' => $actorId, 'created_at' => self::now(), 'responses' => []];
                    self::invalidate_kit($case, 'QUERY_OPENED');
                    break;
                case 'respond_query':
                case 'close_query':
                    $found = false;
                    foreach (($case['queries'] ?? []) as $k => $q) {
                        if (($q['id'] ?? '') !== $input['query_id']) continue;
                        $found = true;
                        if ($command === 'respond_query') {
                            if (($q['status'] ?? '') === 'CLOSED') return self::error('QUERY_ALREADY_CLOSED', 'A closed query cannot receive a new response.');
                            $q['responses'][] = $evidence + ['response' => self::text($input['response'])]; $q['status'] = 'RESPONSE_SUBMITTED';
                        } else {
                            if (empty($q['responses'])) return self::error('QUERY_RESPONSE_REQUIRED', 'Submit the response before recording partner closure.');
                            $q['closure'] = $evidence; $q['status'] = 'CLOSED';
                        }
                        $case['queries'][$k] = $q; self::invalidate_kit($case, 'QUERY_CHANGED'); break;
                    }
                    if (!$found) return self::error('QUERY_NOT_FOUND', 'Query not found.', 404);
                    break;
                case 'prepare_kit':
                    if ($e = self::require_gates($case, self::kit_gates())) return $e;
                    $old = $case['db_kit'] ?? [];
                    if (($old['status'] ?? '') === 'ACCEPTED' && ($old['snapshot_hash'] ?? '') === self::kit_hash($case)) return self::error('KIT_ALREADY_ACCEPTED', 'The current exact kit is already accepted.');
                    $case['db_kit_history'][] = $old;
                    $case['db_kit'] = $evidence + ['id' => self::uuid(), 'version' => (int) ($old['version'] ?? 0) + 1, 'status' => 'READY', 'snapshot_hash' => self::kit_hash($case), 'prepared_at' => self::now()];
                    break;
                case 'submit_kit':
                case 'accept_kit':
                    if ($e = self::require_gates($case, self::kit_gates())) return $e;
                    $kit = $case['db_kit'] ?? [];
                    $expected = $command === 'submit_kit' ? 'READY' : 'SUBMITTED';
                    if (($kit['status'] ?? '') !== $expected || ($kit['snapshot_hash'] ?? '') !== self::kit_hash($case)) return self::error('KIT_VERSION_CONFLICT', 'Prepare and submit the exact current version before acceptance.', 409);
                    $case['db_kit'][$command === 'submit_kit' ? 'submission' : 'acceptance'] = $evidence;
                    $case['db_kit']['status'] = $command === 'submit_kit' ? 'SUBMITTED' : 'ACCEPTED';
                    break;
                case 'prepare_payment':
                    if (empty($case['policy']['financial_operations_enabled'])) return self::error('FINANCIAL_OPERATIONS_DISABLED', 'Financial instructions remain disabled until approved product and provider settings are configured. You may record an observation separately.');
                    $purpose = $input['purpose']; $record =& self::payment_record($case, $purpose);
                    $amount = self::positive($input['amount_paise']);
                    if (!$amount || strlen((string) $input['idempotency_key']) < 8 || strlen((string) $input['idempotency_key']) > 200) return self::error('INVALID_FINANCIAL_INPUT', 'Use positive integer paise and an idempotency key of 8–200 characters.');
                    $payload = ['purpose' => $purpose, 'amount_paise' => $amount, 'beneficiary_ref' => self::text($input['beneficiary_ref']), 'reference' => self::text($input['reference'])];
                    $fingerprint = self::hash($payload); $key = (string) $input['idempotency_key'];
                    foreach (($case['financial_keys'] ?? []) as $savedKey => $saved) if ($savedKey === $key) {
                        if (($saved['fingerprint'] ?? '') !== $fingerprint) return self::error('IDEMPOTENCY_CONFLICT', 'This idempotency key was used for different financial details.', 409);
                        return $case;
                    }
                    if ($e = self::payment_gates($case, $purpose)) return $e;
                    $old = $record['payment'] ?? [];
                    if (in_array($old['status'] ?? '', ['PREPARED', 'APPROVED', 'SUBMITTED', 'UNKNOWN', 'PENDING'], true)) return self::error('PAYMENT_IN_FLIGHT', 'An existing instruction must be reconciled before another attempt.', 409);
                    $target = self::payment_target($case, $purpose); $settled = self::settled_total($record, $purpose === 'initial_repayment' ? 'repayment' : null);
                    $remaining = $target - $settled;
                    if ($amount > $remaining || $remaining <= 0 || (in_array($purpose, ['initial_disbursement', 'bc_disbursement', 'slt_contribution'], true) && $amount !== $remaining)) return self::error('OBLIGATION_AMOUNT_MISMATCH', 'The amount must match the remaining separately identified obligation.');
                    if ($purpose === 'slt_contribution' && (!empty($record['ever_collected']) || !empty($record['reversals']))) return self::error('SLT_ALREADY_COLLECTED', 'A successful contribution or reversal requires controlled review; do not initiate another debit.');
                    $expectedBeneficiary = self::beneficiary_ref($case, $purpose);
                    if (!$expectedBeneficiary || !hash_equals($expectedBeneficiary, self::text($input['beneficiary_ref']))) return self::error('BENEFICIARY_MISMATCH', 'The beneficiary must match the verified, accepted obligation.');
                    if ($old) $record['payment_history'][] = $old;
                    $instruction = $evidence + $payload + ['id' => self::uuid(), 'obligation_id' => $record['id'] ?? '', 'status' => 'PREPARED', 'maker_id' => $actorId, 'idempotency_key' => $key, 'fingerprint' => $fingerprint, 'currency' => 'INR', 'terms_hash' => $record['terms']['hash'] ?? '', 'created_at' => self::now(), 'events' => []];
                    if ($purpose === 'initial_repayment') $instruction['ledger_kind'] = 'repayment';
                    $record['payment'] = $instruction; $case['financial_keys'][$key] = ['fingerprint' => $fingerprint, 'instruction_id' => $instruction['id']];
                    unset($record);
                    break;
                case 'check_payment':
                case 'record_submission':
                case 'record_settlement':
                    $purpose = $input['purpose']; $record =& self::payment_record($case, $purpose); $p = $record['payment'] ?? [];
                    if (!$p || ($p['id'] ?? '') !== $input['instruction_id']) return self::error('INSTRUCTION_NOT_FOUND', 'The current purpose-bound instruction was not found.', 404);
                    if ($command === 'check_payment') {
                        if (($p['status'] ?? '') !== 'PREPARED') return self::error('INSTRUCTION_NOT_PREPARED', 'Only a prepared instruction can be checked.');
                        if (($p['maker_id'] ?? 0) === $actorId) return self::error('MAKER_CHECKER_REQUIRED', 'A maker cannot approve their own instruction.', 403);
                        if ($e = self::payment_gates($case, $purpose)) return $e;
                        $p['status'] = 'APPROVED'; $p['checker_id'] = $actorId; $p['approval'] = $evidence;
                    } elseif ($command === 'record_submission') {
                        if (($p['status'] ?? '') !== 'APPROVED') return self::error('INSTRUCTION_NOT_APPROVED', 'Only an independently approved instruction may be recorded as submitted.');
                        if ($e = self::payment_gates($case, $purpose)) return $e;
                        $p['status'] = $input['result']; $p['submission'] = $evidence;
                    } else {
                        $result = $input['result'];
                        $settledAt = empty($input['settled_at']) ? null : self::date($input['settled_at']);
                        if ($result === 'SETTLED' && (!$settledAt || self::time($settledAt) > time())) return self::error('SETTLEMENT_DATE_REQUIRED', 'Record the actual bank settlement/value date at or before now.');
                        if (($p['status'] ?? '') === 'SETTLED') {
                            if ($result === 'SETTLED' && ($p['settlement']['reference'] ?? '') === (string) $input['reference']) return $case;
                            return self::error('SETTLEMENT_IMMUTABLE', 'Settled history cannot regress; use a linked reversal.', 409);
                        }
                        if (!in_array($p['status'] ?? '', ['APPROVED', 'SUBMITTED', 'UNKNOWN', 'PENDING'], true)) return self::error('INSTRUCTION_NOT_RECONCILABLE', 'Only approved or in-flight instructions can be reconciled.');
                        if (empty($actor['provider']) && ($p['maker_id'] ?? 0) === $actorId) return self::error('MAKER_CHECKER_REQUIRED', 'An independent checker must confirm bank/lender settlement.', 403);
                        if (self::positive($input['amount_paise']) !== (int) $p['amount_paise'] || $input['currency'] !== 'INR' || !hash_equals((string) $p['beneficiary_ref'], self::text($input['beneficiary_ref']))) return self::error('SETTLEMENT_MISMATCH', 'Match the instruction’s exact amount, currency and beneficiary before reconciliation.');
                        if (empty($actor['provider']) && empty($case['policy']['allow_manual_evidence'])) return self::error('PROVIDER_CONFIRMATION_REQUIRED', 'This product requires authenticated provider settlement confirmation.');
                        foreach (($case['settlement_references'] ?? []) as $r => $instructionId) if ($r === (string) $input['reference'] && $instructionId !== $p['id']) return self::error('SETTLEMENT_REFERENCE_REUSED', 'This settlement reference is already linked to another instruction.', 409);
                        $p['status'] = $result; $p['settlement'] = $evidence + ['amount_paise' => (int) $p['amount_paise'], 'currency' => 'INR', 'beneficiary_ref' => $p['beneficiary_ref'], 'settled_at' => $settledAt];
                        if ($result === 'SETTLED') {
                            $settlement = $p['settlement'] + ['instruction_id' => $p['id'], 'purpose' => $purpose, 'maker_id' => $p['maker_id'] ?? 0, 'checker_id' => $p['checker_id'] ?? 0, 'ledger_kind' => $p['ledger_kind'] ?? 'primary'];
                            $record['settlements'][] = $settlement; $case['settlement_references'][(string) $input['reference']] = $p['id'];
                            $p['receipt_id'] = self::uuid();
                            $recipient = $purpose === 'return_collection' ? ($record['recipient'] ?? '') : ($purpose === 'slt_contribution' ? 'Shubh Labh Trust' : ($purpose === 'initial_repayment' ? ($record['lender'] ?? '') : ($case['parties'][$record['beneficiary_role'] ?? 'applicant']['profile']['legal_name'] ?? $case['parties'][$record['beneficiary_role'] ?? 'applicant']['profile']['name'] ?? 'Borrower')));
                            $mode = in_array($input['payment_mode'] ?? '', ['BANK_TRANSFER', 'NEFT', 'RTGS', 'IMPS', 'UPI', 'ENACH'], true) ? $input['payment_mode'] : 'Not recorded';
                            $case['receipts'][$p['receipt_id']] = ['receipt_id' => $p['receipt_id'], 'instruction_id' => $p['id'], 'obligation_id' => $p['obligation_id'], 'purpose' => $purpose, 'recipient_name' => $recipient, 'amount_paise' => (int) $p['amount_paise'], 'currency' => 'INR', 'status' => 'SETTLED', 'settlement_reference' => self::text($input['reference']), 'settled_at' => $settledAt, 'payment_mode' => $mode, 'source' => $source, 'created_at' => self::now()];
                            if ($purpose === 'slt_contribution') { $record['ever_collected'] = true; $record['status'] = 'SATISFIED'; }
                            elseif ($purpose === 'return_collection') $record['status'] = self::settled_total($record) === 1000000 ? 'RECONCILED' : 'PARTIAL';
                            elseif ($purpose === 'initial_repayment') $record['repayment_status'] = self::settled_total($record, 'repayment') >= 1000000 ? 'REPAID_AWAITING_LENDER_CLOSURE' : 'PARTIAL';
                            else $record['status'] = 'ACTIVE';
                        }
                    }
                    $p['events'][] = $evidence + ['status' => $p['status']]; $record['payment'] = $p;
                    unset($record);
                    break;
                case 'record_reversal':
                    $purpose = $input['purpose']; $record =& self::payment_record($case, $purpose); $found = false; $originalAmount = 0; $originalMaker = 0;
                    foreach (($record['settlements'] ?? []) as $settlement) if (($settlement['instruction_id'] ?? '') === $input['instruction_id']) { $found = true; $originalAmount = (int) $settlement['amount_paise']; $originalMaker = (int) ($settlement['maker_id'] ?? 0); }
                    if (!$found) return self::error('SETTLED_INSTRUCTION_NOT_FOUND', 'A reversal must link to a settled instruction.', 404);
                    if (empty($actor['provider']) && $originalMaker === $actorId) return self::error('MAKER_CHECKER_REQUIRED', 'An independent checker must reconcile the original instruction’s reversal.', 403);
                    $amount = self::positive($input['amount_paise']); $already = 0;
                    foreach (($record['reversals'] ?? []) as $rev) {
                        if (($rev['reference'] ?? '') === (string) $input['reference']) return self::error('REVERSAL_REFERENCE_REUSED', 'This reversal reference is already recorded.', 409);
                        if (($rev['instruction_id'] ?? '') === $input['instruction_id']) $already += (int) $rev['amount_paise'];
                    }
                    if (!$amount || $amount + $already > $originalAmount) return self::error('REVERSAL_AMOUNT_INVALID', 'Reversals cannot exceed the original settled amount.');
                    $reversalId = self::uuid();
                    $record['reversals'][] = $evidence + ['id' => $reversalId, 'instruction_id' => $input['instruction_id'], 'amount_paise' => $amount, 'purpose' => $purpose, 'ledger_kind' => $purpose === 'initial_repayment' ? 'repayment' : 'primary'];
                    $receiptId = null;
                    foreach (($case['receipts'] ?? []) as $rid => $receipt) if (($receipt['instruction_id'] ?? '') === $input['instruction_id']) $receiptId = $rid;
                    $case['reversal_notices'][$reversalId] = $evidence + ['id' => $reversalId, 'original_receipt_id' => $receiptId, 'instruction_id' => $input['instruction_id'], 'obligation_id' => $record['id'] ?? '', 'purpose' => $purpose, 'amount_paise' => $amount, 'currency' => 'INR', 'status' => 'REVERSAL_RECORDED'];
                    $record['reconciliation_exception'] = 'REVERSAL_REVIEW_REQUIRED';
                    if ($purpose === 'initial_repayment') { $record['status'] = 'ACTIVE'; unset($record['closure']); }
                    unset($record); self::invalidate_kit($case, 'FINANCIAL_REVERSAL');
                    break;
                case 'close_initial_loan':
                    if (self::nonnegative($input['lender_balance_paise']) !== 0 || self::settled_total($case['loans']['initial'] ?? [], 'repayment') < 1000000) return self::error('LENDER_REPAYMENT_NOT_CONFIRMED', 'A separate reconciled lender repayment and zero authoritative lender balance are required. A return collection cannot close this loan.');
                    $case['loans']['initial']['closure'] = $evidence + ['lender_balance_paise' => 0]; $case['loans']['initial']['status'] = 'CLOSED';
                    break;
                case 'record_financial_observation':
                    $amount = self::positive($input['amount_paise']);
                    if (!$amount) return self::error('INVALID_AMOUNT', 'Use a positive integer amount in paise.');
                    $case['financial_observations'][] = $evidence + ['id' => self::uuid(), 'purpose' => $input['purpose'], 'amount_paise' => $amount, 'notes' => self::text($input['notes']), 'status' => 'UNRECONCILED_OBSERVATION'];
                    break;
                case 'set_exception':
                    $case['exception_history'][] = ['exception' => $input['exception'], 'reason' => self::text($input['reason']), 'actor_id' => $actorId, 'at' => self::now()];
                    $case['exception'] = $input['exception'] === 'CLEAR' ? null : $input['exception'];
                    break;
            }
        } catch (\Throwable $e) {
            return self::error('INVALID_WORKFLOW_INPUT', 'The supplied workflow data could not be processed. Check required fields and current record versions.', 422);
        }
        $case['updated_at'] = self::now();
        $case['stage'] = self::stage($case);
        return $case;
    }

    public static function bank_hash(array $bank): string {
        return self::hash(['account_number' => (string) ($bank['account_number'] ?? ''), 'ifsc' => strtoupper((string) ($bank['ifsc'] ?? '')), 'holder_name' => (string) ($bank['holder_name'] ?? $bank['account_holder'] ?? '')]);
    }

    public static function stage(array $case): string {
        if (!empty($case['exception'])) return (string) $case['exception'];
        $g = self::evaluate($case);
        if (!$g['documents_present']['passed']) return !empty($case['documents_submitted']) ? 'DOCUMENTS_PENDING' : 'DRAFT';
        $map = ['documents' => 'DOCUMENT_REVIEW', 'identity_kyc' => 'IDENTITY_KYC_PENDING', 'assignment' => 'READY_FOR_ASSIGNMENT', 'bc_eligibility' => 'BC_RESPONSE_PENDING', 'counselling' => 'COUNSELLING_PENDING', 'initial_documentation' => 'INITIAL_DOCUMENTATION_PENDING', 'initial_mandate' => 'INITIAL_MANDATE_PENDING', 'initial_disbursement' => 'INITIAL_DISBURSEMENT_PENDING', 'return_collection' => 'RETURN_COLLECTION_PENDING', 'slt_membership' => 'SLT_MEMBERSHIP_PENDING', 'slt_mandate' => 'SLT_MANDATE_PENDING', 'verifications' => 'VERIFICATION_PENDING', 'queries' => 'BC_QUERY_PENDING', 'bc_documentation' => 'BC_DOCUMENTATION_PENDING', 'bc_mandate' => 'BC_MANDATE_PENDING', 'initial_closure' => 'INITIAL_LENDER_CLOSURE_PENDING', 'db_kit' => 'DB_KIT_PENDING', 'bc_disbursement' => 'BC_DISBURSEMENT_PENDING', 'slt_due' => 'SLT_COLLECTION_SCHEDULED', 'slt_collection' => 'SLT_COLLECTION_PENDING'];
        foreach ($map as $key => $stage) if (!$g[$key]['passed']) return $stage;
        return 'COMPLETED';
    }

    public static function settled_total(array $record, ?string $kind = null): int {
        $sum = 0;
        foreach (($record['settlements'] ?? []) as $s) if (($s['ledger_kind'] ?? 'primary') === ($kind ?? 'primary')) $sum += (int) ($s['amount_paise'] ?? 0);
        foreach (($record['reversals'] ?? []) as $s) if (($s['ledger_kind'] ?? 'primary') === ($kind ?? 'primary')) $sum -= (int) ($s['amount_paise'] ?? 0);
        return max(0, $sum);
    }

    public static function bank_verified(array $bank, array $policy = []): bool {
        $v = $bank['verification'] ?? [];
        $passed = ($v['result'] ?? '') === 'PASS' || ($v['status'] ?? '') === 'VERIFIED';
        if (($policy['surepass_environment'] ?? 'sandbox') === 'production' && ($v['environment'] ?? '') !== 'production') {
            $manual = ($policy['allow_manual_evidence'] ?? false) === true && ($v['source'] ?? '') === 'OFFICER_REPORTED' && !empty($v['evidence_ref']);
            if (!$manual) return false;
        }
        return $passed && !empty($v['reference']) && !empty($v['bank_hash']) && hash_equals(self::bank_hash($bank), (string) $v['bank_hash']);
    }

    private static function document_blockers(array $case, bool $accepted): array {
        $b = [];
        if (empty($case['loan_purpose'])) $b[] = 'LOAN_PURPOSE_REQUIRED';
        if ($accepted && empty($case['documents_submitted'])) $b[] = 'APPLICATION_NOT_SUBMITTED';
        foreach (self::ROLES as $r) {
            $p = $case['parties'][$r] ?? [];
            if (empty($p['profile']['name']) && empty($p['profile']['legal_name']) && empty($p['profile']['full_name'])) $b[] = 'PARTY_NAME_REQUIRED:' . $r;
            if (empty($p['profile']['mobile'])) $b[] = 'PARTY_MOBILE_REQUIRED:' . $r;
            if (!self::consent($p['consents']['data_processing'] ?? $p['consents']['document_processing'] ?? false)) $b[] = 'DOCUMENT_CONSENT_REQUIRED:' . $r;
            $requirements = $case['policy']['document_requirements'][$r] ?? $case['policy']['required_documents'] ?? self::DOCUMENTS;
            foreach ($requirements as $type) {
                if (is_array($type)) { if (isset($type['mandatory']) && !$type['mandatory']) continue; $type = $type['type'] ?? ''; }
                if (!$type) continue;
                $latest = null;
                foreach (($p['documents'] ?? []) as $key => $d) {
                    $dt = $d['type'] ?? $key;
                    if (in_array($dt, ['aadhaar', 'aadhaar_card'], true) && !empty($d['side'])) $dt = 'aadhaar_' . $d['side'];
                    if ($dt === $type && empty($d['superseded_by'])) $latest = $d;
                }
                if (!$latest) $b[] = 'DOCUMENT_MISSING:' . $r . ':' . $type;
                elseif ($accepted && ($latest['review']['status'] ?? $latest['review_status'] ?? '') !== 'ACCEPTED') $b[] = 'DOCUMENT_NOT_ACCEPTED:' . $r . ':' . $type;
            }
        }
        return $b;
    }

    private static function loan_blockers(array $case, string $kind): array {
        $l = $case['loans'][$kind] ?? []; $b = [];
        if (empty($l['id']) || empty($l['lender']) || empty($l['terms']['hash']) || empty($l['borrower_allocations'])) return [strtoupper($kind) . '_LOAN_TERMS_MISSING'];
        if ($kind === 'initial' && (int) ($l['amount_paise'] ?? 0) !== 1000000) $b[] = 'INITIAL_AMOUNT_MISMATCH';
        $r = $l['beneficiary_role'] ?? 'applicant';
        if (!self::bank_verified($case['parties'][$r]['bank'] ?? [], $case['policy'] ?? [])) $b[] = strtoupper($kind) . '_BORROWER_BANK_NOT_VERIFIED';
        $signers = $case['policy']['required_signers_by_loan'][$kind] ?? $case['policy']['required_signers'] ?? self::ROLES;
        if (!$signers || array_diff($signers, self::ROLES)) $b[] = 'SIGNER_POLICY_INVALID:' . $kind;
        foreach ($signers as $role) {
            if (!self::accepted($l['terms']['accepted'][$role] ?? false, $l['terms']['hash'])) $b[] = 'TERMS_ACCEPTANCE_REQUIRED:' . $kind . ':' . $role;
            if (!self::signature_valid($l['signatures'][$role] ?? [], $l['terms']['hash'])) $b[] = 'SIGNATURE_REQUIRED:' . $kind . ':' . $role;
        }
        return $b;
    }

    private static function mandate_blockers(array $case, string $purpose): array {
        $m = $case['mandates'][$purpose] ?? []; $b = [];
        $record = in_array($purpose, ['initial', 'bc'], true) ? ($case['loans'][$purpose] ?? []) : ($case['slt'] ?? []);
        if (($m['status'] ?? '') !== 'ACTIVE') $b[] = strtoupper($purpose) . '_MANDATE_NOT_ACTIVE';
        if (!empty($m['authorization_withdrawal'])) $b[] = strtoupper($purpose) . '_MANDATE_AUTHORIZATION_WITHDRAWN';
        if (empty($m['reference']) || empty($m['evidence_ref'])) $b[] = strtoupper($purpose) . '_MANDATE_EVIDENCE_MISSING';
        if (empty($record['id']) || ($m['obligation_id'] ?? '') !== $record['id'] || ($m['terms_hash'] ?? '') !== ($record['terms']['hash'] ?? '')) $b[] = strtoupper($purpose) . '_MANDATE_OBLIGATION_MISMATCH';
        if (empty($m['authorization']['accepted']) || ($m['authorization']['mandate_hash'] ?? '') !== self::mandate_hash($m)) $b[] = strtoupper($purpose) . '_MANDATE_AUTHORIZATION_MISSING';
        $bank = $case['parties'][$m['payer_role'] ?? 'applicant']['bank'] ?? [];
        if (!self::bank_verified($bank, $case['policy'] ?? []) || ($m['payer_bank_hash'] ?? '') !== self::bank_hash($bank)) $b[] = strtoupper($purpose) . '_MANDATE_PAYER_CHANGED';
        if (empty($m['valid_from']) || empty($m['valid_until']) || self::time($m['valid_from']) > time() || self::time($m['valid_until']) < time()) $b[] = strtoupper($purpose) . '_MANDATE_OUTSIDE_VALIDITY';
        if ($purpose === 'slt' && ((int) ($m['amount_paise'] ?? 0) !== 2500000 || ($m['frequency'] ?? '') !== 'ONE_TIME' || ($m['beneficiary_ref'] ?? '') !== ($record['beneficiary_ref'] ?? '') || ($m['payer_role'] ?? '') !== ($record['payer_role'] ?? ''))) $b[] = 'SLT_AUTHORIZATION_MISMATCH';
        return $b;
    }

    private static function payment_gates(array $case, string $purpose) {
        if (!empty($case['exception'])) return self::error('CASE_EXCEPTION', 'Clear the case exception through the authorized review route first.');
        if (empty($case['policy']['financial_operations_enabled'])) return self::error('FINANCIAL_OPERATIONS_DISABLED', 'New financial instructions are suspended. Incoming reconciliation remains available.');
        $gates = ['documents', 'identity_kyc', 'assignment', 'bc_eligibility', 'counselling'];
        switch ($purpose) {
            case 'initial_disbursement': $gates = array_merge($gates, ['initial_documentation', 'initial_mandate']); break;
            case 'return_collection':
                $gates[] = 'initial_disbursement'; $r = $case['return_collection'] ?? [];
                if (empty($r['recipient']) || empty($r['purpose']) || empty($r['beneficiary_ref']) || empty($r['evidence_ref']) || !self::accepted($r['terms']['accepted']['applicant'] ?? false, $r['terms']['hash'] ?? '')) return self::error('RETURN_AUTHORIZATION_REQUIRED', 'Configure the actual recipient, contractual purpose, verified beneficiary and separately accepted authorization.');
                if (empty($r['due_at']) || self::time($r['due_at']) > time()) return self::error('RETURN_NOT_DUE', 'The separately authorized return collection is not due.');
                break;
            case 'initial_repayment':
                $gates[] = 'initial_disbursement';
                if (empty($case['loans']['initial']['lender']) || empty($case['loans']['initial']['lender_beneficiary_ref']) || empty($case['loans']['initial']['lender_bank_evidence_ref'])) return self::error('INITIAL_LENDER_REQUIRED', 'A verified receiving-account reference and evidence for the actual initial lender are required.');
                break;
            case 'bc_disbursement': $gates = array_merge($gates, self::kit_gates(), ['db_kit']); break;
            case 'slt_contribution':
                $gates = ['bc_disbursement', 'slt_membership', 'slt_mandate', 'slt_due'];
                $notice = $case['slt']['notice'] ?? [];
                if (($notice['terms_hash'] ?? '') !== ($case['slt']['terms']['hash'] ?? '')) return self::error('SLT_NOTICE_STALE', 'Collection notice must match the currently authorized SLT terms.');
                break;
            default: return self::error('INVALID_FINANCIAL_PURPOSE', 'Use a separately defined financial purpose.');
        }
        return self::require_gates($case, array_unique($gates));
    }

    private static function kit_gates(): array {
        return ['documents', 'identity_kyc', 'assignment', 'bc_eligibility', 'counselling', 'initial_documentation', 'initial_mandate', 'initial_disbursement', 'return_collection', 'slt_membership', 'slt_mandate', 'verifications', 'queries', 'bc_documentation', 'bc_mandate', 'initial_closure'];
    }

    private static function kit_hash(array $case): string {
        $docs = [];
        foreach (($case['parties'] ?? []) as $r => $party) {
            $docs[$r] = ['profile' => $party['profile'] ?? [], 'kyc' => $party['kyc'] ?? [], 'bank_hash' => self::bank_hash($party['bank'] ?? []), 'documents' => []];
            foreach (($party['documents'] ?? []) as $k => $d) if (empty($d['superseded_by'])) $docs[$r]['documents'][] = ['id' => $d['id'] ?? $k, 'hash' => $d['sha256'] ?? $d['hash'] ?? '', 'review' => $d['review'] ?? []];
        }
        $loans = [];
        foreach (['initial', 'bc'] as $kind) $loans[$kind] = ['terms' => $case['loans'][$kind]['terms'] ?? [], 'signatures' => $case['loans'][$kind]['signatures'] ?? []];
        return self::hash(['parties' => $docs, 'policy' => $case['policy'] ?? [], 'bc' => $case['bc_enrolment'] ?? [], 'counselling' => $case['counselling'] ?? [], 'loans' => $loans, 'return_terms' => $case['return_collection']['terms'] ?? [], 'return_settlements' => $case['return_collection']['settlements'] ?? [], 'slt_terms' => $case['slt']['terms'] ?? [], 'slt_signatures' => $case['slt']['signatures'] ?? [], 'mandates' => $case['mandates'] ?? [], 'verifications' => $case['verifications'] ?? [], 'queries' => $case['queries'] ?? []]);
    }

    private static function invalidate_kit(array &$case, string $reason): void {
        if (!empty($case['db_kit'])) { $case['db_kit']['status'] = 'CORRECTION_REQUIRED'; $case['db_kit']['invalidation_reason'] = $reason; }
    }

    private static function require_gates(array $case, array $names) {
        $g = self::evaluate($case); $blockers = [];
        foreach ($names as $n) foreach (($g[$n]['blockers'] ?? ['UNKNOWN_GATE:' . $n]) as $b) $blockers[] = $b;
        return $blockers ? self::error('GATE_BLOCKED', 'Required workflow evidence is incomplete.', 422, ['blockers' => array_values(array_unique($blockers))]) : null;
    }

    private static function &terms_record(array &$case, string $purpose): array {
        if ($purpose === 'initial' || $purpose === 'bc') return $case['loans'][$purpose];
        if ($purpose === 'return_collection') return $case['return_collection'];
        return $case['slt'];
    }

    private static function &payment_record(array &$case, string $purpose): array {
        if ($purpose === 'initial_disbursement' || $purpose === 'initial_repayment') return $case['loans']['initial'];
        if ($purpose === 'bc_disbursement') return $case['loans']['bc'];
        if ($purpose === 'return_collection') return $case['return_collection'];
        return $case['slt'];
    }

    private static function payment_target(array $case, string $purpose): int {
        switch ($purpose) {
            case 'initial_disbursement': case 'initial_repayment': case 'return_collection': return 1000000;
            case 'bc_disbursement': return (int) ($case['loans']['bc']['net_disbursement_paise'] ?? $case['loans']['bc']['amount_paise'] ?? 0);
            case 'slt_contribution': return 2500000;
        }
        return 0;
    }

    public static function beneficiary_ref(array $case, string $purpose): string {
        if ($purpose === 'return_collection') return (string) ($case['return_collection']['beneficiary_ref'] ?? '');
        if ($purpose === 'slt_contribution') return (string) ($case['slt']['beneficiary_ref'] ?? '');
        if ($purpose === 'initial_repayment') return (string) ($case['loans']['initial']['lender_beneficiary_ref'] ?? '');
        $kind = $purpose === 'initial_disbursement' ? 'initial' : 'bc';
        $r = $case['loans'][$kind]['beneficiary_role'] ?? 'applicant'; $bank = $case['parties'][$r]['bank'] ?? [];
        return (string) ($bank['verification']['reference'] ?? '');
    }

    private static function has_payment_activity(array $record): bool {
        return !empty($record['payment']) || !empty($record['settlements']) || !empty($record['reversals']);
    }

    private static function mandate_hash(array $m): string {
        $out = [];
        foreach (['id', 'purpose', 'obligation_id', 'payer_role', 'payer_bank_hash', 'beneficiary_ref', 'amount_paise', 'frequency', 'valid_from', 'valid_until', 'terms_hash'] as $k) $out[$k] = $m[$k] ?? null;
        return self::hash($out);
    }

    private static function accepted($value, string $hash): bool {
        return is_array($value) && !empty($value['accepted']) && $hash !== '' && ($value['terms_hash'] ?? '') === $hash;
    }

    private static function kyc_verified(array $party, string $operation, array $policy = []): bool {
        $v = $party['kyc'][$operation] ?? [];
        if (strtolower((string) ($v['status'] ?? '')) !== 'verified' || empty($v['reference'])) return false;
        if (($policy['surepass_environment'] ?? 'sandbox') === 'production' && ($v['environment'] ?? '') !== 'production') return false;
        return empty($v['profile_hash']) || hash_equals((string) $v['profile_hash'], self::identity_hash($party));
    }

    public static function identity_hash(array $party): string {
        $p = $party['profile'] ?? []; $out = [];
        foreach (['legal_name', 'name', 'full_name', 'dob', 'pan', 'aadhaar_last4', 'voter_id', 'mobile'] as $k) $out[$k] = $p[$k] ?? '';
        return self::hash($out);
    }

    private static function consent($value): bool {
        return $value === true || (is_array($value) && (!empty($value['accepted']) || in_array(strtoupper((string) ($value['response'] ?? '')), ['ACCEPTED', 'ACCEPT'], true)));
    }

    private static function signature_valid(array $s, string $hash): bool {
        return ($s['status'] ?? '') === 'COMPLETED' && $hash !== '' && ($s['terms_hash'] ?? '') === $hash && !empty($s['reference']) && !empty($s['evidence_ref']) && !empty($s['document_hash']);
    }

    private static function terms($version, $text, array $metadata): array {
        $base = ['version' => self::text($version), 'text' => self::text($text), 'metadata' => $metadata];
        return $base + ['hash' => self::hash($base), 'accepted' => [], 'created_at' => self::now()];
    }
    private static function role_list($s): array { return array_values(array_intersect(self::ROLES, array_map('trim', explode(',', (string) $s)))); }
    private static function spec(string $label, string $capability, array $fields): array { return compact('label', 'capability', 'fields'); }
    private static function f(string $type, string $label, bool $required = true, ?array $options = null): array { $x = compact('type', 'label', 'required'); if ($options !== null) $x['options'] = $options; return $x; }
    private static function gate(array $blockers): array { return ['passed' => !$blockers, 'blockers' => array_values($blockers)]; }
    private static function yes($v): bool { return in_array($v, [true, 1, '1', 'true', 'on', 'yes'], true); }
    private static function text($v): string { return is_scalar($v) ? trim(strip_tags((string) $v)) : ''; }
    private static function positive($v): ?int { $n = self::nonnegative($v); return $n !== null && $n > 0 ? $n : null; }
    private static function nonnegative($v): ?int { if (is_int($v)) return $v >= 0 ? $v : null; if (!is_string($v) || !preg_match('/^(0|[1-9][0-9]{0,14})$/D', $v)) return null; return (int) $v; }
    private static function hash(array $v): string { return hash('sha256', json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE)); }
    private static function now(): string { return gmdate('Y-m-d\TH:i:s\Z'); }
    private static function time($v): int { $t = strtotime((string) $v); return $t === false ? 0 : $t; }
    private static function date($v): ?string {
        if (!is_string($v) || !preg_match('/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2})?(?:Z|\+00:00)?)?$/D', $v)) return null;
        try { $d = new \DateTimeImmutable($v, new \DateTimeZone('UTC')); $errors = \DateTimeImmutable::getLastErrors(); if ($errors && ($errors['warning_count'] || $errors['error_count'])) return null; return $d->format('Y-m-d\TH:i:s\Z'); } catch (\Exception $e) { return null; }
    }
    private static function uuid(): string { if (function_exists('wp_generate_uuid4')) return wp_generate_uuid4(); $b = random_bytes(16); $b[6] = chr((ord($b[6]) & 15) | 64); $b[8] = chr((ord($b[8]) & 63) | 128); return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4)); }
    private static function error(string $code, string $message, int $status = 422, array $data = []) { return new \WP_Error('dbcl_' . strtolower($code), $message, ['status' => $status] + $data); }
}
