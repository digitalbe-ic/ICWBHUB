<?php
/** Transactional encrypted persistence. Authorization belongs to the calling service. */
namespace DigitalBE\ClientGroupLoans;

if (!defined('ABSPATH')) {
    exit;
}

final class Store
{
    private static function table(string $suffix): string
    {
        global $wpdb;
        return $wpdb->prefix . 'dbcl_' . $suffix;
    }

    public static function install(): void
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $tables = [
            "CREATE TABLE " . self::table('applications') . " (
                id varchar(36) NOT NULL,
                org_id bigint(20) unsigned NOT NULL,
                branch varchar(100) NOT NULL DEFAULT '',
                owner_id bigint(20) unsigned NOT NULL,
                assigned_id bigint(20) unsigned NOT NULL DEFAULT 0,
                version bigint(20) unsigned NOT NULL DEFAULT 1,
                data longtext NOT NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY org_branch (org_id,branch),
                KEY owner_id (owner_id),
                KEY assigned_id (assigned_id)
            ) ENGINE=InnoDB $charset;",
            "CREATE TABLE " . self::table('events') . " (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                application_id varchar(36) NOT NULL,
                actor_id bigint(20) unsigned NOT NULL,
                event_type varchar(64) NOT NULL,
                summary text NOT NULL,
                prev_hash char(64) NOT NULL,
                hash char(64) NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY application_id (application_id,id)
            ) ENGINE=InnoDB $charset;",
            "CREATE TABLE " . self::table('members') . " (
                application_id varchar(36) NOT NULL,
                user_id bigint(20) unsigned NOT NULL,
                party_role varchar(32) NOT NULL,
                PRIMARY KEY  (application_id,party_role),
                KEY user_id (user_id,application_id)
            ) ENGINE=InnoDB $charset;",
            "CREATE TABLE " . self::table('files') . " (
                id varchar(36) NOT NULL,
                application_id varchar(36) NOT NULL,
                party_id varchar(36) NOT NULL,
                document_type varchar(64) NOT NULL,
                mime varchar(80) NOT NULL,
                size bigint(20) unsigned NOT NULL,
                sha256 char(64) NOT NULL,
                path varchar(100) NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (id),
                KEY application_id (application_id)
            ) ENGINE=InnoDB $charset;",
            "CREATE TABLE " . self::table('inbox') . " (
                event_id varchar(100) NOT NULL,
                payload_hash char(64) NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY  (event_id)
            ) ENGINE=InnoDB $charset;",
            "CREATE TABLE " . self::table('invitations') . " (
                token_hash char(64) NOT NULL,
                application_id varchar(36) NOT NULL,
                party_role varchar(32) NOT NULL,
                expires_at datetime NOT NULL,
                claimed_by bigint(20) unsigned NOT NULL DEFAULT 0,
                claimed_at datetime NULL,
                PRIMARY KEY  (token_hash),
                KEY application_id (application_id)
            ) ENGINE=InnoDB $charset;",
        ];
        foreach ($tables as $sql) {
            dbDelta($sql);
        }
        update_option('dbcl_schema_version', '1.0.0', false);
    }

    private static function error(string $code = 'dbcl_storage', string $message = 'The operation could not be stored. Please retry after checking database availability.', int $status = 500): \WP_Error
    {
        return new \WP_Error($code, $message, ['status' => $status]);
    }

    private static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    private static function encode(array $case): string
    {
        $json = wp_json_encode($case, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            throw new \RuntimeException('Case cannot be serialized.');
        }
        return Crypto::encrypt($json);
    }

    private static function decode(array $row)
    {
        $plain = Crypto::decrypt((string) $row['data']);
        if (is_wp_error($plain)) {
            return $plain;
        }
        $case = json_decode($plain, true);
        if (!is_array($case)) {
            return self::error('dbcl_corrupt_state', 'The stored application is invalid. Restore from a verified backup.');
        }
        // Bind encrypted state to its unencrypted routing/scope metadata. A database
        // writer without the key must not transplant a victim ciphertext into a row
        // whose authorization metadata belongs to another user or organization.
        foreach (['id', 'branch'] as $field) {
            if (array_key_exists($field, $case) && (!is_scalar($case[$field]) || (string) $case[$field] !== (string) $row[$field])) {
                return self::error('dbcl_corrupt_state', 'Encrypted application identity does not match its storage metadata. Restore a verified backup.');
            }
        }
        foreach (['org_id', 'owner_id', 'assigned_id', 'version'] as $field) {
            if (array_key_exists($field, $case) && (!is_scalar($case[$field]) || (int) $case[$field] !== (int) $row[$field])) {
                return self::error('dbcl_corrupt_state', 'Encrypted application scope or version does not match its storage metadata. Restore a verified backup.');
            }
        }
        $case['id'] = (string) $row['id'];
        $case['version'] = (int) $row['version'];
        $case['org_id'] = (int) $row['org_id'];
        $case['branch'] = (string) $row['branch'];
        $case['owner_id'] = (int) $row['owner_id'];
        $case['assigned_id'] = (int) $row['assigned_id'];
        $case['created_at'] = (string) $row['created_at'];
        $case['updated_at'] = (string) $row['updated_at'];
        return $case;
    }

    /** @return array|\WP_Error */
    public static function create(array $case)
    {
        global $wpdb;
        $case['id'] = !empty($case['id']) ? (string) $case['id'] : wp_generate_uuid4();
        if (!preg_match('/^[a-f0-9-]{36}$/i', $case['id']) || empty($case['owner_id']) || empty($case['org_id'])) {
            return self::error('dbcl_invalid_case', 'An application ID, organization and owner are required.', 400);
        }
        $case['version'] = 1;
        $case['created_at'] = self::now();
        $case['updated_at'] = $case['created_at'];
        $case['assigned_id'] = (int) ($case['assigned_id'] ?? 0);
        $case['branch'] = substr((string) ($case['branch'] ?? ''), 0, 100);
        try {
            $encrypted = self::encode($case);
            if ($wpdb->query('START TRANSACTION') === false) {
                return self::error();
            }
            $ok = $wpdb->insert(self::table('applications'), [
                'id' => $case['id'], 'org_id' => (int) $case['org_id'], 'branch' => $case['branch'],
                'owner_id' => (int) $case['owner_id'], 'assigned_id' => $case['assigned_id'], 'version' => 1,
                'data' => $encrypted, 'created_at' => $case['created_at'], 'updated_at' => $case['updated_at'],
            ]);
            if ($ok === false || !self::sync_members($case) || !self::append_event($case['id'], (int) $case['owner_id'], 'application_created', ['version' => 1])) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            if ($wpdb->query('COMMIT') === false) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            return $case;
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return self::error('dbcl_encryption', 'Application encryption is unavailable. Check the encryption key and PHP OpenSSL support.');
        }
    }

    /** @return array|\WP_Error */
    public static function get(string $id)
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('applications') . ' WHERE id = %s', $id), ARRAY_A);
        return $row ? self::decode($row) : self::error('dbcl_not_found', 'Application not found.', 404);
    }

    /** Compare-and-swap, membership update and hash-chained audit share one transaction. */
    public static function save(array $case, int $expected_version, int $actor_id, string $event_type, array $safe_summary = [], ?string $callback_event_id = null, ?string $callback_payload_hash = null)
    {
        global $wpdb;
        $id = (string) ($case['id'] ?? '');
        if ($id === '' || $expected_version < 1) {
            return self::error('dbcl_version', 'An application ID and expected version are required.', 400);
        }
        if (($callback_event_id !== null || $callback_payload_hash !== null) &&
            ($callback_event_id === null || $callback_payload_hash === null ||
             !preg_match('/^[A-Za-z0-9_.:-]{1,100}$/D', $callback_event_id) ||
             !preg_match('/^[a-f0-9]{64}$/D', $callback_payload_hash))) {
            return self::error('dbcl_callback_id', 'A valid callback event ID and SHA-256 payload hash are both required.', 400);
        }
        unset($case['_callback_duplicate']);
        if ($wpdb->query('START TRANSACTION') === false) {
            return self::error();
        }
        try {
            $current = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('applications') . ' WHERE id = %s FOR UPDATE', $id), ARRAY_A);
            if (!$current) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_not_found', 'Application not found.', 404);
            }
            if ($callback_event_id !== null) {
                // The inbox reservation and state/audit update commit or roll back together.
                // Duplicate checking precedes the version check so a retried successful event
                // remains idempotent even when its original expected version is now stale.
                $claimed = self::claim_event($callback_event_id, $callback_payload_hash);
                if (is_wp_error($claimed)) {
                    $wpdb->query('ROLLBACK');
                    return $claimed;
                }
                if ($claimed === false) {
                    $existing = self::decode($current);
                    $wpdb->query('ROLLBACK');
                    if (is_wp_error($existing)) {
                        return $existing;
                    }
                    $existing['_callback_duplicate'] = true;
                    return $existing;
                }
            }
            if ((int) $current['version'] !== $expected_version) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_conflict', 'This application changed. Reload it before submitting again.', 409);
            }
            // Organization and creator identity are immutable after creation.
            if ((int) ($case['org_id'] ?? 0) !== (int) $current['org_id'] || (int) ($case['owner_id'] ?? 0) !== (int) $current['owner_id']) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_scope_immutable', 'Application organization and owner cannot be changed.', 403);
            }
            $case['version'] = $expected_version + 1;
            $case['created_at'] = (string) $current['created_at'];
            $case['updated_at'] = self::now();
            $case['branch'] = substr((string) ($case['branch'] ?? ''), 0, 100);
            $case['assigned_id'] = (int) ($case['assigned_id'] ?? 0);
            $encrypted = self::encode($case);
            $result = $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::table('applications') . ' SET branch=%s,assigned_id=%d,version=%d,data=%s,updated_at=%s WHERE id=%s AND version=%d',
                substr((string) ($case['branch'] ?? ''), 0, 100), (int) ($case['assigned_id'] ?? 0), $case['version'], $encrypted, $case['updated_at'], $id, $expected_version
            ));
            $safe_summary['version'] = $case['version'];
            if ($result !== 1 || !self::sync_members($case) || !self::append_event($id, $actor_id, $event_type, $safe_summary)) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            if ($wpdb->query('COMMIT') === false) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            return $case;
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return self::error('dbcl_encryption', 'Application encryption is unavailable. Check the encryption key and PHP OpenSSL support.');
        }
    }

    private static function sync_members(array $case): bool
    {
        global $wpdb;
        if ($wpdb->delete(self::table('members'), ['application_id' => $case['id']]) === false) {
            return false;
        }
        $seen = [];
        foreach (($case['parties'] ?? []) as $role => $party) {
            $user_id = (int) ($party['user_id'] ?? 0);
            if ($user_id < 1) {
                continue;
            }
            if (isset($seen[$user_id])) {
                return false; // One authenticated person cannot occupy multiple required party roles.
            }
            $seen[$user_id] = true;
            if ($wpdb->insert(self::table('members'), ['application_id' => $case['id'], 'user_id' => $user_id, 'party_role' => substr((string) $role, 0, 32)]) === false) {
                return false;
            }
        }
        // Staff assignments are case-specific memberships, not broad branch visibility.
        $staff = [];
        if (!empty($case['assigned_id'])) {
            $staff[(int) $case['assigned_id']] = 'credit_officer';
        }
        foreach (($case['staff_assignments'] ?? []) as $staff_id => $staff_role) {
            if ((int) $staff_id > 0) {
                $staff[(int) $staff_id] = is_string($staff_role) ? $staff_role : 'staff';
            }
        }
        if (!isset($seen[(int) $case['owner_id']])) {
            $staff[(int) $case['owner_id']] = 'application_owner';
        }
        foreach ($staff as $staff_id => $staff_role) {
            if ($wpdb->insert(self::table('members'), [
                'application_id' => $case['id'], 'user_id' => $staff_id,
                'party_role' => 'staff_' . $staff_id,
            ]) === false) {
                return false;
            }
        }
        return true;
    }

    private static function append_event(string $id, int $actor_id, string $event_type, array $summary): bool
    {
        global $wpdb;
        $previous = (string) $wpdb->get_var($wpdb->prepare('SELECT hash FROM ' . self::table('events') . ' WHERE application_id=%s ORDER BY id DESC LIMIT 1', $id));
        $safe = [];
        foreach (['command', 'stage', 'purpose', 'document_type', 'party_role', 'status', 'source', 'version', 'count', 'reason_code', 'amount_paise', 'sha256'] as $key) {
            if (!array_key_exists($key, $summary) || !is_scalar($summary[$key])) {
                continue;
            }
            if (is_int($summary[$key]) || is_bool($summary[$key])) {
                $safe[$key] = $summary[$key];
            } else {
                $safe[$key] = substr(preg_replace('/[^A-Za-z0-9_.:\/-]/', '', (string) $summary[$key]), 0, 100);
            }
        }
        ksort($safe);
        $data = [
            'application_id' => $id, 'actor_id' => $actor_id,
            'event_type' => substr(sanitize_key($event_type), 0, 64),
            'summary' => wp_json_encode($safe, JSON_UNESCAPED_SLASHES),
            'prev_hash' => $previous, 'created_at' => self::now(),
        ];
        // Hashes detect accidental/tampered changes; external signed anchoring is still needed against a DB administrator.
        $data['hash'] = hash('sha256', wp_json_encode($data, JSON_UNESCAPED_SLASHES));
        return $wpdb->insert(self::table('events'), $data) !== false;
    }

    /** Metadata-only queue, filtered before pagination. Empty scope fails closed. */
    public static function list(array $scope, int $page = 1, int $per_page = 25): array
    {
        global $wpdb;
        $where = ['1=1'];
        $args = [];
        $scoped = false;
        foreach (['org_id', 'owner_id', 'assigned_id'] as $key) {
            if (isset($scope[$key])) {
                $where[] = 'a.' . $key . ' = %d';
                $args[] = (int) $scope[$key];
                $scoped = true;
            }
        }
        if (isset($scope['branch'])) {
            $where[] = 'a.branch = %s';
            $args[] = substr((string) $scope['branch'], 0, 100);
            $scoped = true;
        }
        if (isset($scope['user_id'])) {
            $where[] = '(a.owner_id = %d OR a.assigned_id = %d OR EXISTS (SELECT 1 FROM ' . self::table('members') . ' m WHERE m.application_id=a.id AND m.user_id=%d))';
            $args[] = (int) $scope['user_id'];
            $args[] = (int) $scope['user_id'];
            $args[] = (int) $scope['user_id'];
            $scoped = true;
        }
        if (!$scoped && empty($scope['all'])) {
            return ['rows' => [], 'total' => 0, 'page' => max(1, $page)];
        }
        $conditions = implode(' AND ', $where);
        $from = ' FROM ' . self::table('applications') . ' a WHERE ' . $conditions;
        $count_sql = 'SELECT COUNT(*)' . $from;
        $total = (int) $wpdb->get_var($args ? $wpdb->prepare($count_sql, ...$args) : $count_sql);
        $per_page = max(1, min(100, $per_page));
        $page = max(1, $page);
        $sql = 'SELECT a.id,a.org_id,a.branch,a.owner_id,a.assigned_id,a.version,a.created_at,a.updated_at' . $from . ' ORDER BY a.updated_at DESC,a.id ASC LIMIT %d OFFSET %d';
        $rows = $wpdb->get_results($wpdb->prepare($sql, ...array_merge($args, [$per_page, ($page - 1) * $per_page])), ARRAY_A);
        return ['rows' => $rows ?: [], 'total' => $total, 'page' => $page, 'per_page' => $per_page];
    }

    /**
     * Access logging shares the application row lock used by state mutations,
     * keeping the audit chain serialized without invalidating a user's record version.
     *
     * @return true|\WP_Error
     */
    public static function log_access(string $application_id, int $actor_id, string $event_type, array $safe_summary = [])
    {
        global $wpdb;
        if ($actor_id < 1 || !preg_match('/^[a-z][a-z0-9_]{1,63}$/D', $event_type)) {
            return self::error('dbcl_access_event', 'An authenticated actor and valid access event type are required.', 400);
        }
        if ($wpdb->query('START TRANSACTION') === false) {
            return self::error();
        }
        try {
            $found = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::table('applications') . ' WHERE id=%s FOR UPDATE', $application_id));
            if (!$found) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_not_found', 'Application not found.', 404);
            }
            if (!self::append_event($application_id, $actor_id, $event_type, $safe_summary)) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_access_audit', 'Access could not be audited. The requested document has not been released.');
            }
            if ($wpdb->query('COMMIT') === false) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_access_audit', 'Access audit could not be committed. The requested document has not been released.');
            }
            return true;
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return self::error('dbcl_access_audit', 'Access could not be audited. The requested document has not been released.');
        }
    }

    public static function audit(string $id): array
    {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare('SELECT id,application_id,actor_id,event_type,summary,prev_hash,hash,created_at FROM ' . self::table('events') . ' WHERE application_id=%s ORDER BY id ASC', $id), ARRAY_A);
        $rows = is_array($rows) ? $rows : [];
        foreach ($rows as &$row) {
            $row['summary'] = json_decode((string) $row['summary'], true) ?: [];
        }
        unset($row);
        return $rows ?: [];
    }

    /** @return string|\WP_Error */
    private static function private_dir()
    {
        $web_root = realpath(ABSPATH);
        if ($web_root === false) {
            return self::error('dbcl_private_dir', 'WordPress root cannot be resolved. Configure DBCL_PRIVATE_DIR.');
        }
        $configured = defined('DBCL_PRIVATE_DIR') ? (string) DBCL_PRIVATE_DIR : (string) getenv('DBCL_PRIVATE_DIR');
        $root = $configured !== '' ? $configured : dirname($web_root) . DIRECTORY_SEPARATOR . 'dbcl-private-' . substr(hash('sha256', $web_root), 0, 12);
        if (!is_dir($root) && !wp_mkdir_p($root)) {
            return self::error('dbcl_private_dir', 'Private storage cannot be created. Configure a writable DBCL_PRIVATE_DIR outside the public document root.');
        }
        $real = realpath($root);
        if ($real === false || is_link($root) || !is_writable($real)) {
            return self::error('dbcl_private_dir', 'Private storage must be a writable, real directory.');
        }
        $forbidden = [$web_root];
        if (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $docroot = realpath((string) $_SERVER['DOCUMENT_ROOT']);
            if ($docroot !== false && $docroot !== DIRECTORY_SEPARATOR) {
                $forbidden[] = $docroot;
            }
        }
        foreach ($forbidden as $public) {
            if ($real === $public || strpos($real . DIRECTORY_SEPARATOR, rtrim($public, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) === 0) {
                return self::error('dbcl_private_dir', 'Private documents cannot be stored within the public document root.');
            }
        }
        @chmod($real, 0700);
        // Defense in depth for accidental future web-root changes. Encryption is always retained.
        foreach (['.htaccess' => "Require all denied\nDeny from all\n", 'index.php' => "<?php http_response_code(404); exit;\n"] as $name => $contents) {
            $target = $real . DIRECTORY_SEPARATOR . $name;
            if (!file_exists($target)) {
                $handle = @fopen($target, 'x');
                if ($handle) {
                    fwrite($handle, $contents);
                    fclose($handle);
                    @chmod($target, 0600);
                }
            }
        }
        return $real;
    }

    /** @return array|\WP_Error */
    public static function store_file(string $application_id, string $party_id, string $type, string $tmp_path, string $mime)
    {
        global $wpdb;
        if (!is_file($tmp_path) || is_link($tmp_path) || !is_readable($tmp_path)) {
            return self::error('dbcl_file', 'The uploaded file is unavailable.', 400);
        }
        $size = filesize($tmp_path);
        if ($size === false || $size < 1 || $size > 10 * 1024 * 1024) {
            return self::error('dbcl_file_size', 'Upload a nonempty document no larger than 10 MB.', 400);
        }
        if (!class_exists('\finfo')) {
            return self::error('dbcl_fileinfo', 'The PHP Fileinfo extension is required for safe document uploads.');
        }
        $detected = (new \finfo(FILEINFO_MIME_TYPE))->file($tmp_path);
        if (!in_array($detected, ['image/jpeg', 'image/png', 'application/pdf'], true) || $detected !== $mime) {
            return self::error('dbcl_file_type', 'The document must be a valid JPEG, PNG or PDF with a matching content type.', 400);
        }
        if (strpos($detected, 'image/') === 0 && @getimagesize($tmp_path) === false) {
            return self::error('dbcl_file_type', 'The uploaded image is invalid.', 400);
        }
        $dir = self::private_dir();
        if (is_wp_error($dir)) {
            return $dir;
        }
        $bytes = file_get_contents($tmp_path);
        if ($bytes === false) {
            return self::error('dbcl_file', 'The uploaded document could not be read.', 400);
        }
        $id = wp_generate_uuid4();
        $filename = bin2hex(random_bytes(24)) . '.enc';
        $path = $dir . DIRECTORY_SEPARATOR . $filename;
        try {
            $bound = [
                'id' => $id, 'application_id' => $application_id, 'party_id' => $party_id,
                'document_type' => substr(sanitize_key($type), 0, 64), 'mime' => $detected,
                'size' => $size, 'sha256' => hash('sha256', $bytes),
            ];
            $header = wp_json_encode($bound, JSON_UNESCAPED_SLASHES);
            if ($header === false) { throw new \RuntimeException('Document metadata cannot be serialized.'); }
            // Metadata and bytes are authenticated together. This binds the object
            // to its application/party rather than trusting editable database routing.
            $encrypted = Crypto::encrypt("dbcl-file-v1\n" . $header . "\n" . $bytes);
            $handle = @fopen($path, 'x');
            if (!$handle) {
                return self::error('dbcl_private_write', 'The private document could not be stored.');
            }
            $written = fwrite($handle, $encrypted);
            fclose($handle);
            @chmod($path, 0600);
            if ($written !== strlen($encrypted)) {
                @unlink($path);
                return self::error('dbcl_private_write', 'The private document could not be completely stored.');
            }
            $record = [
                'id' => $id, 'application_id' => $application_id, 'party_id' => $party_id,
                'document_type' => substr(sanitize_key($type), 0, 64), 'mime' => $detected,
                'size' => $size, 'sha256' => hash('sha256', $bytes), 'path' => $filename,
                'created_at' => self::now(),
            ];
            if ($wpdb->insert(self::table('files'), $record) === false) {
                @unlink($path);
                return self::error();
            }
            unset($record['path']);
            $record['scan_status'] = 'PENDING';
            return $record;
        } catch (\Throwable $e) {
            if (is_file($path)) {
                @unlink($path);
            }
            return self::error('dbcl_encryption', 'Document encryption is unavailable. Check the encryption key and PHP OpenSSL support.');
        }
    }

    /** Metadata lets the router authorize ownership before decrypting the object. */
    public static function file_metadata(string $id)
    {
        global $wpdb;
        $record = $wpdb->get_row($wpdb->prepare('SELECT id,application_id,party_id,document_type,mime,size,sha256,created_at FROM ' . self::table('files') . ' WHERE id=%s', $id), ARRAY_A);
        return $record ?: self::error('dbcl_file_not_found', 'Private document not found.', 404);
    }

    /** Caller must authorize the application and party before sending decrypted bytes. */
    public static function read_file(string $id)
    {
        global $wpdb;
        $record = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('files') . ' WHERE id=%s', $id), ARRAY_A);
        if (!$record || !preg_match('/^[a-f0-9]{48}\.enc$/D', (string) ($record['path'] ?? ''))) {
            return self::error('dbcl_file_not_found', 'Private document not found.', 404);
        }
        $dir = self::private_dir();
        if (is_wp_error($dir)) {
            return $dir;
        }
        $path = $dir . DIRECTORY_SEPARATOR . $record['path'];
        if (!is_file($path) || is_link($path)) {
            return self::error('dbcl_file_not_found', 'Private document not found.', 404);
        }
        $encrypted = file_get_contents($path);
        if ($encrypted === false) {
            return self::error('dbcl_private_read', 'Private document could not be read.');
        }
        $plaintext = Crypto::decrypt($encrypted);
        if (is_wp_error($plaintext)) {
            return $plaintext;
        }
        $parts = explode("\n", $plaintext, 3);
        if (count($parts) !== 3 || $parts[0] !== 'dbcl-file-v1') {
            return self::error('dbcl_file_format', 'This private document uses an unbound legacy format. A verified migration is required before it can be released.');
        }
        $bound = json_decode($parts[1], true);
        if (!is_array($bound)) {
            return self::error('dbcl_file_integrity', 'The private document metadata integrity check failed.');
        }
        foreach (['id', 'application_id', 'party_id', 'document_type', 'mime', 'sha256'] as $field) {
            if (!isset($bound[$field]) || !is_string($bound[$field]) || !hash_equals((string) $record[$field], $bound[$field])) {
                return self::error('dbcl_file_integrity', 'The private document identity does not match its storage metadata.');
            }
        }
        $bytes = $parts[2];
        if (!isset($bound['size']) || !is_int($bound['size']) || $bound['size'] !== (int) $record['size'] || !hash_equals((string) $record['sha256'], hash('sha256', $bytes)) || strlen($bytes) !== (int) $record['size']) {
            return self::error('dbcl_file_integrity', 'The private document integrity check failed.');
        }
        unset($record['path']);
        $record['bytes'] = $bytes;
        return $record;
    }

    /**
     * Read-only callback lookup before domain gate evaluation.
     * true = committed same-payload event, null = unseen, WP_Error = invalid/conflicting.
     * Store::save still repeats the check inside its transaction for race protection.
     *
     * @return bool|\WP_Error|null
     */
    public static function event_status(string $event_id, string $payload_hash)
    {
        global $wpdb;
        if (!preg_match('/^[A-Za-z0-9_.:-]{1,100}$/D', $event_id) || !preg_match('/^[a-f0-9]{64}$/D', $payload_hash)) {
            return self::error('dbcl_callback_id', 'Invalid callback event ID or payload hash.', 400);
        }
        $existing = $wpdb->get_var($wpdb->prepare('SELECT payload_hash FROM ' . self::table('inbox') . ' WHERE event_id=%s', $event_id));
        if ($wpdb->last_error !== '') {
            return self::error();
        }
        if ($existing === null) {
            return null;
        }
        return is_string($existing) && hash_equals($existing, $payload_hash)
            ? true
            : self::error('dbcl_callback_replay', 'This callback ID has already been used for different content.', 409);
    }

    /** Atomic callback replay guard. true=new; false=identical duplicate; WP_Error=conflicting payload. */
    public static function claim_event(string $event_id, string $payload_hash)
    {
        global $wpdb;
        if (!preg_match('/^[A-Za-z0-9_.:-]{1,100}$/D', $event_id) || !preg_match('/^[a-f0-9]{64}$/D', $payload_hash)) {
            return self::error('dbcl_callback_id', 'Invalid callback event ID or payload hash.', 400);
        }
        $result = $wpdb->query($wpdb->prepare('INSERT IGNORE INTO ' . self::table('inbox') . ' (event_id,payload_hash,created_at) VALUES (%s,%s,%s)', $event_id, $payload_hash, self::now()));
        if ($result === false) {
            return self::error();
        }
        if ($result === 1) {
            return true;
        }
        $existing = $wpdb->get_var($wpdb->prepare('SELECT payload_hash FROM ' . self::table('inbox') . ' WHERE event_id=%s', $event_id));
        return is_string($existing) && hash_equals($existing, $payload_hash) ? false : self::error('dbcl_callback_replay', 'This callback ID has already been used for different content.', 409);
    }

    /** Token is returned only once for a caller-delivered invitation, never sent by this method. */
    public static function issue_invitation(string $application_id, string $role, int $expires_epoch)
    {
        global $wpdb;
        if (!in_array($role, ['co_applicant', 'guarantor_1', 'guarantor_2'], true) || $expires_epoch <= time() || $expires_epoch > time() + 7 * DAY_IN_SECONDS) {
            return self::error('dbcl_invitation', 'A supported party role and expiry within seven days are required.', 400);
        }
        if ($wpdb->query('START TRANSACTION') === false) {
            return self::error();
        }
        try {
            $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('applications') . ' WHERE id=%s FOR UPDATE', $application_id), ARRAY_A);
            $case = $row ? self::decode($row) : self::error('dbcl_not_found', 'Application not found.', 404);
            if (is_wp_error($case)) {
                $wpdb->query('ROLLBACK');
                return $case;
            }
            if (!isset($case['parties'][$role]) || !empty($case['parties'][$role]['user_id'])) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_invitation_role', 'This party role is unavailable.', 409);
            }
            $token = bin2hex(random_bytes(32));
            $invitation = ['token_hash' => hash('sha256', $token), 'application_id' => $application_id, 'party_role' => $role, 'expires_at' => gmdate('Y-m-d H:i:s', $expires_epoch), 'claimed_by' => 0];
            if ($wpdb->insert(self::table('invitations'), $invitation) === false || !self::append_event($application_id, (int) get_current_user_id(), 'invitation_issued', ['party_role' => $role])) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            if ($wpdb->query('COMMIT') === false) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            return ['token' => $token, 'application_id' => $application_id, 'party_role' => $role, 'expires_at' => $invitation['expires_at']];
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return self::error('dbcl_invitation', 'The invitation could not be created. Check database and encryption configuration.');
        }
    }

    /** Requires independent identity authentication by caller; binds one party role once. */
    public static function claim_invitation(string $token, int $user_id)
    {
        global $wpdb;
        if (!preg_match('/^[a-f0-9]{64}$/D', $token) || $user_id < 1) {
            return self::error('dbcl_invitation', 'Invalid invitation.', 400);
        }
        if ($wpdb->query('START TRANSACTION') === false) {
            return self::error();
        }
        try {
            $hash = hash('sha256', $token);
            $invite = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('invitations') . ' WHERE token_hash=%s FOR UPDATE', $hash), ARRAY_A);
            if (!$invite || (int) $invite['claimed_by'] !== 0 || $invite['expires_at'] <= self::now()) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_invitation', 'This invitation is invalid, expired or already claimed.', 410);
            }
            $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table('applications') . ' WHERE id=%s FOR UPDATE', $invite['application_id']), ARRAY_A);
            $case = $row ? self::decode($row) : self::error('dbcl_not_found', 'Application not found.', 404);
            if (is_wp_error($case)) {
                $wpdb->query('ROLLBACK');
                return $case;
            }
            $role = $invite['party_role'];
            if (!isset($case['parties'][$role]) || !empty($case['parties'][$role]['user_id'])) {
                $wpdb->query('ROLLBACK');
                return self::error('dbcl_invitation_role', 'This party role has already been linked.', 409);
            }
            foreach ($case['parties'] as $party) {
                if ((int) ($party['user_id'] ?? 0) === $user_id) {
                    $wpdb->query('ROLLBACK');
                    return self::error('dbcl_independent_party', 'Each required party must use a separate authenticated account.', 403);
                }
            }
            $case['parties'][$role]['user_id'] = $user_id;
            $case['version'] = (int) $row['version'] + 1;
            $case['updated_at'] = self::now();
            $ok = $wpdb->update(self::table('applications'), ['data' => self::encode($case), 'version' => $case['version'], 'updated_at' => $case['updated_at']], ['id' => $case['id'], 'version' => (int) $row['version']]);
            $claimed = $wpdb->update(self::table('invitations'), ['claimed_by' => $user_id, 'claimed_at' => self::now()], ['token_hash' => $hash, 'claimed_by' => 0]);
            if ($ok !== 1 || $claimed !== 1 || !self::sync_members($case) || !self::append_event($case['id'], $user_id, 'invitation_claimed', ['party_role' => $role, 'version' => $case['version']])) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            if ($wpdb->query('COMMIT') === false) {
                $wpdb->query('ROLLBACK');
                return self::error();
            }
            return $case;
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return self::error('dbcl_invitation', 'Invitation could not be claimed. Check database and encryption configuration.');
        }
    }
}
