<?php
namespace DigitalBE\ClientGroupLoans;
defined('ABSPATH') || exit;

final class Auth {
    public const CAPS = ['dbcl_review', 'dbcl_assign', 'dbcl_verify', 'dbcl_operate', 'dbcl_finance_make', 'dbcl_finance_check', 'dbcl_audit'];

    public static function install(): void {
        $roles = [
            'dbcl_credit_officer' => ['Credit officer', ['dbcl_review']],
            'dbcl_verification_officer' => ['Verification officer', ['dbcl_verify']],
            'dbcl_operations_officer' => ['Operations officer', ['dbcl_operate']],
            'dbcl_finance_maker' => ['Finance maker', ['dbcl_finance_make']],
            'dbcl_finance_checker' => ['Finance checker', ['dbcl_finance_check']],
            'dbcl_supervisor' => ['Loan supervisor', ['dbcl_assign', 'dbcl_review', 'dbcl_verify', 'dbcl_operate']],
            'dbcl_auditor' => ['Loan auditor', ['dbcl_audit']],
        ];
        foreach ($roles as $key => [$name, $caps]) {
            add_role($key, $name, array_fill_keys(array_merge(['read'], $caps), true));
        }
        // WordPress administrators configure the plugin; financial authority is explicitly assigned.
    }

    public static function staff(): bool {
        if (current_user_can('manage_options')) { return true; }
        foreach (self::CAPS as $cap) { if (current_user_can($cap)) { return true; } }
        return false;
    }

    public static function actor(array $case = []): array {
        $id = get_current_user_id();
        $caps = [];
        foreach (self::CAPS as $cap) { if (current_user_can($cap)) { $caps[] = $cap; } }
        $role = null;
        foreach (($case['parties'] ?? []) as $key => $party) {
            if ((int) ($party['user_id'] ?? 0) === $id && $id > 0) { $role = $key; break; }
        }
        // A participant acts as that participant in this case, even if their
        // account also holds staff roles for unrelated cases.
        if ($role !== null) { $caps = ['party']; }
        return ['id' => $id, 'capabilities' => $caps, 'party_role' => $role, 'provider' => false];
    }

    public static function logged(): bool|\WP_Error {
        return is_user_logged_in() ? true : new \WP_Error('dbcl_login_required', 'Sign in with your own WordPress account to continue.', ['status' => 401]);
    }

    public static function access(array $case, bool $write = false): bool|\WP_Error {
        if (!is_user_logged_in()) { return self::logged(); }
        $uid = get_current_user_id();
        $org = max(1, (int) get_user_meta($uid, 'dbcl_org_id', true));
        if ((int) ($case['org_id'] ?? 1) !== $org) { return self::denied(); }
        $actor = self::actor($case);
        $settings = get_option('dbcl_settings', []);
        if ($write && self::staff() && !empty($settings['require_staff_mfa']) && !apply_filters('dbcl_mfa_verified', false, $uid)) {
            return new \WP_Error('dbcl_mfa_required', 'A verified staff MFA session is required.', ['status' => 403]);
        }
        if ($actor['party_role'] !== null) { return true; }
        if (!self::staff()) { return self::denied(); }
        if ($write && current_user_can('dbcl_audit') && count($actor['capabilities']) === 1) { return self::denied(); }
        $branch = (string) get_user_meta($uid, 'dbcl_branch', true);
        if ($branch !== '' && $branch !== ($case['branch'] ?? '')) { return self::denied(); }
        if (current_user_can('manage_options') || current_user_can('dbcl_assign') || current_user_can('dbcl_audit')) { return true; }
        if ((int) ($case['assigned_id'] ?? 0) === $uid || isset($case['staff_assignments'][$uid])) { return true; }
        return self::denied();
    }

    public static function own_party(array $case, string $role): bool|\WP_Error {
        $access = self::access($case, true);
        if (is_wp_error($access)) { return $access; }
        if (!isset($case['parties'][$role]) || (int) ($case['parties'][$role]['user_id'] ?? 0) !== get_current_user_id()) {
            return new \WP_Error('dbcl_individual_acceptance', 'Only the independently signed-in party can perform this action.', ['status' => 403]);
        }
        return true;
    }

    public static function denied(): \WP_Error { return new \WP_Error('dbcl_forbidden', 'You do not have access to this record or action.', ['status' => 403]); }

    public static function can_staff(array $case, string $capability): bool {
        $actor = self::actor($case);
        return $actor['party_role'] === null && in_array($capability, $actor['capabilities'], true);
    }

    public static function public_case(array $case): array {
        unset($case['esign_sessions']);
        foreach ($case['parties'] ?? [] as $key => $party) { unset($case['parties'][$key]['kyc_requests']); }
        if (self::staff() && self::actor($case)['party_role'] === null) { return self::mask_identifiers($case); }
        $role = self::actor($case)['party_role'];
        foreach (($case['parties'] ?? []) as $key => $party) {
            if ($key !== $role) {
                $case['parties'][$key] = ['id' => $party['id'] ?? '', 'name' => $party['profile']['legal_name'] ?? '', 'role' => $key, 'linked' => !empty($party['user_id'])];
            }
        }
        $case = array_intersect_key($case, array_flip(['id', 'group_id', 'branch', 'version', 'stage', 'exception', 'product', 'requested_amount_paise', 'loan_purpose', 'purpose', 'assigned_id', 'parties', 'loans', 'return_collection', 'slt', 'mandates', 'bc_enrolment', 'counselling', 'verifications', 'queries', 'receipts', 'reversal_notices', 'created_at', 'updated_at']));
        if (isset($case['counselling'])) { unset($case['counselling']['notes']); }
        foreach (($case['queries'] ?? []) as $key => $query) {
            $case['queries'][$key] = array_intersect_key($query, array_flip(['id', 'status', 'customer_message', 'due_at']));
        }
        // Operational evidence references and staff identities are never customer document access grants.
        return self::mask_identifiers(self::strip_private_evidence($case));
    }

    private static function strip_private_evidence(array $value): array {
        foreach ($value as $key => $item) {
            if (in_array($key, ['evidence_ref', 'notes', 'internal_notes', 'profile_history', 'consent_history', 'kyc_requests', 'document_url', 'sdk_token'], true)) { unset($value[$key]); }
            elseif (is_array($item)) { $value[$key] = self::strip_private_evidence($item); }
        }
        return $value;
    }

    public static function mask_identifiers(array $value): array {
        foreach ($value as $key => &$item) {
            if (is_array($item)) { $item = self::mask_identifiers($item); }
            elseif (is_string($item) && in_array($key, ['aadhaar', 'aadhaar_number', 'pan', 'pan_number', 'account_number', 'account_confirmation', 'voter_id', 'passport', 'mobile'], true)) {
                $item = $item === '' ? '' : str_repeat('•', max(0, strlen($item) - 4)) . substr($item, -4);
            }
        }
        return $value;
    }
}
