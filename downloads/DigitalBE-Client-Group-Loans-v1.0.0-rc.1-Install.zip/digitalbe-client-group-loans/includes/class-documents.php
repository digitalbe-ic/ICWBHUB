<?php
namespace DigitalBE\ClientGroupLoans;

/** Printable document generation. Persistence/access control belong to the calling service. */
final class Documents
{
    private const TYPES = [
        'application' => 'Client and Group Loan Application',
        'sanction' => 'Sanction Letter',
        'kfs' => 'Key Facts Statement and Repayment Schedule',
        'agreement' => 'Loan Agreement',
        'dpn' => 'Demand Promissory Note',
        'indemnity' => 'Indemnity',
        'membership' => 'Shubh Labh Trust Membership and Contribution',
        'receipt' => 'Settlement Receipt',
        'db_kit' => 'Disbursement Documentation Kit',
    ];

    public static function schema(): array
    {
        return require dirname(__DIR__) . '/config/form-schema.php';
    }

    public static function snapshot(string $type, array $case, array $settings = []): array
    {
        [$type, $settings] = self::resolveType($type, $settings);
        $html = self::render($type, $case, $settings);
        $signers = [];
        foreach ((array) ($settings['signer_roles'][$type] ?? array_keys(self::schema()['roles'])) as $role) {
            $signers[] = ['role' => (string) $role, 'party_id' => (string) ($case['parties'][$role]['id'] ?? '')];
        }
        return [
            'type' => $type,
            'case_id' => (string) ($case['id'] ?? ''),
            'case_version' => (int) ($case['version'] ?? 0),
            'loan_kind' => $settings['loan_kind'] ?? 'bc',
            'template_version' => self::templateVersion($type, $settings),
            'terms_version' => (string) ($settings['terms_version'] ?? self::loan($case, $settings)['terms']['version'] ?? $settings['template_version'] ?? ''),
            'status' => self::approved($type, $case, $settings) ? 'ready_for_execution' : 'draft',
            'required_signers' => $signers,
            'html' => $html,
            'sha256' => hash('sha256', $html),
            'generated_at' => gmdate('Y-m-d\TH:i:s\Z'),
        ];
    }

    public static function render(string $type, array $case, array $settings = []): string
    {
        [$type, $settings] = self::resolveType($type, $settings);
        if (!isset(self::TYPES[$type])) {
            throw new \InvalidArgumentException('Unsupported document type.');
        }
        $approved = self::approved($type, $case, $settings);
        $title = self::TYPES[$type];
        $lender = self::text($settings['lender_name'] ?? '') ?: 'Lender not configured';
        $html = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . self::e($title) . '</title>';
        $html .= '<style>body{font:14px/1.5 Arial,sans-serif;color:#182632;max-width:1000px;margin:24px auto;padding:0 20px}h1{font-size:24px}h2{font-size:18px;margin-top:28px}table{width:100%;border-collapse:collapse;margin:12px 0}th,td{border:1px solid #bac5ce;text-align:left;padding:8px;vertical-align:top;overflow-wrap:anywhere}th{background:#eff3f6}.draft{border:3px solid #a33;padding:12px;color:#822;font-weight:bold}.note{padding:12px;background:#f2f5f8}.muted{color:#54616a}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:36px}.signature{border-top:1px solid #333;padding-top:8px;min-height:50px}pre{white-space:pre-wrap;font:inherit}.nowrap{white-space:nowrap}@media print{body{margin:0;max-width:none;padding:0;font-size:10pt}thead{display:table-header-group}tr{break-inside:avoid}.draft{print-color-adjust:exact}h2{break-after:avoid}}</style></head><body>';
        $html .= '<p class="muted">digital BE · Client and Group Loans</p><h1>' . self::e($title) . '</h1>';
        if (!$approved) {
            $html .= '<p class="draft">DRAFT — NOT FOR EXECUTION. Approved lender terms, template version and signer configuration are required. This preview does not establish approval, signature, mandate authorization or settlement.</p>';
        }
        $html .= self::table([
            'Application ID' => $case['id'] ?? '',
            'Group ID' => $case['group_id'] ?? '',
            'Branch' => $case['branch'] ?? '',
            'Lender' => $lender,
            'Lender address' => $settings['lender_address'] ?? '',
            'Template version' => self::templateVersion($type, $settings),
            'Case version' => $case['version'] ?? 0,
        ]);
        switch ($type) {
            case 'application':
                $html .= self::application($case);
                break;
            case 'sanction':
                $html .= '<p>Sanction is subject to the lender-approved conditions below. This document does not itself confirm disbursement.</p>' . self::loanFacts($case, $settings);
                $html .= self::legalText($type, $case, $settings);
                break;
            case 'kfs':
                $html .= self::kfs($case, $settings);
                break;
            case 'agreement':
            case 'dpn':
            case 'indemnity':
                $html .= self::loanFacts($case, $settings) . self::partyNames($case);
                $html .= self::legalText($type, $case, $settings);
                break;
            case 'membership':
                $html .= self::membership($case, $settings);
                break;
            case 'receipt':
                $html .= self::receipt($case, $settings);
                break;
            case 'db_kit':
                $html .= self::kit($case);
                break;
        }
        if ($type !== 'receipt' && $type !== 'db_kit') {
            $html .= self::signatures($case, $type, $settings);
        }
        $html .= '<p class="note">Grievance / support: ' . self::e(self::text($settings['grievance_contact'] ?? '') ?: 'Not configured') . '</p>';
        $html .= '<p class="muted">Confidential. Identity and bank identifiers are masked in this print view. A specimen signature or provider redirect is not evidence of completed eSign. Executed artifacts and verified settlement evidence are retained separately.</p></body></html>';
        return $html;
    }

    /** Integer-paise reducing-balance illustration, with exact principal reconciliation. */
    public static function schedule(array $terms): array
    {
        $amount = self::minor($terms['amount_paise'] ?? $terms['principal_paise'] ?? 0);
        $months = filter_var($terms['tenure_months'] ?? 0, FILTER_VALIDATE_INT);
        $annual = $terms['annual_rate'] ?? $terms['annual_interest_rate'] ?? $terms['interest_rate'] ?? null;
        if ($amount < 1 || $amount > 1000000000000 || !$months || $months < 1 || $months > 600 || !is_numeric($annual) || (float) $annual < 0 || (float) $annual > 1000) {
            throw new \InvalidArgumentException('A positive amount in paise, tenure of 1–600 months and annual percentage rate of 0–1000 are required.');
        }
        $frequency = (string) ($terms['frequency'] ?? $terms['repayment_frequency'] ?? 'monthly');
        if (!in_array($frequency, ['monthly', 'semi_monthly'], true)) {
            throw new \InvalidArgumentException('Repayment frequency must be monthly or semi_monthly.');
        }
        $first = self::date((string) ($terms['first_due_date'] ?? ''));
        $periods = $frequency === 'monthly' ? 12 : 24;
        $count = $months * ($frequency === 'monthly' ? 1 : 2);
        $rate = ((float) $annual / 100) / $periods;
        $payment = $rate == 0.0 ? (int) round($amount / $count) : (int) round($amount * $rate / (1 - pow(1 + $rate, -$count)));
        if ($payment < 1) {
            throw new \InvalidArgumentException('The amount is too small for positive integer-paise instalments over this tenure.');
        }
        $days = $terms['semi_monthly_days'] ?? [1, 15];
        if ($frequency === 'semi_monthly') {
            if (!is_array($days) || count($days) !== 2) {
                throw new \InvalidArgumentException('Two semi-monthly repayment days are required.');
            }
            $days = array_values(array_map('intval', $days));
            sort($days);
            if ($days[0] < 1 || $days[1] > 28 || $days[0] >= $days[1] || !in_array((int) $first->format('j'), $days, true)) {
                throw new \InvalidArgumentException('Semi-monthly days must be distinct days 1–28 and include the first due date.');
            }
        }
        $balance = $amount;
        $rows = [];
        $date = $first;
        for ($index = 1; $index <= $count; ++$index) {
            $interest = (int) round($balance * $rate);
            $principal = $index === $count ? $balance : min($balance, max(0, $payment - $interest));
            $closing = $balance - $principal;
            $rows[] = [
                'number' => $index, 'due_date' => $date->format('Y-m-d'),
                'opening_paise' => $balance, 'principal_paise' => $principal,
                'interest_paise' => $interest, 'payment_paise' => $principal + $interest,
                'closing_paise' => $closing,
            ];
            $balance = $closing;
            if ($frequency === 'monthly') {
                // Retain the original anchor rather than drifting after a short month.
                $base = $first->modify('first day of this month')->modify('+' . $index . ' months');
                $date = $base->setDate((int) $base->format('Y'), (int) $base->format('n'), min((int) $first->format('j'), (int) $base->format('t')));
            } elseif ((int) $date->format('j') === $days[0]) {
                $date = $date->setDate((int) $date->format('Y'), (int) $date->format('n'), $days[1]);
            } else {
                $base = $date->modify('first day of next month');
                $date = $base->setDate((int) $base->format('Y'), (int) $base->format('n'), $days[0]);
            }
        }
        return $rows;
    }

    /** Effective annualized actual-date IRR, not the nominal annual interest rate. */
    public static function apr(array $terms, array $schedule): ?float
    {
        try {
            $disbursed = self::date((string) ($terms['disbursement_date'] ?? ''));
            $principal = self::minor($terms['amount_paise'] ?? $terms['principal_paise'] ?? 0);
            $net = isset($terms['net_disbursed_paise']) ? self::minor($terms['net_disbursed_paise']) : $principal - self::fees($terms);
            if ($net <= 0 || $net > $principal || !$schedule) {
                return null;
            }
            $flows = [];
            foreach ($schedule as $row) {
                $due = self::date((string) ($row['due_date'] ?? ''));
                $days = (int) $disbursed->diff($due)->format('%r%a');
                $payment = self::minor($row['payment_paise'] ?? 0);
                if ($days <= 0 || $payment <= 0) {
                    return null;
                }
                $flows[] = [$days / 365.0, $payment];
            }
            $npv = static function (float $rate) use ($net, $flows): float {
                $sum = -$net;
                foreach ($flows as [$years, $payment]) {
                    $sum += $payment / pow(1 + $rate, $years);
                }
                return $sum;
            };
            $low = -0.9999;
            $high = 1.0;
            while ($npv($high) > 0 && $high < 1000000) {
                $high *= 2;
            }
            if ($npv($high) > 0) {
                return null;
            }
            for ($iteration = 0; $iteration < 150; ++$iteration) {
                $mid = ($low + $high) / 2;
                if ($npv($mid) > 0) {
                    $low = $mid;
                } else {
                    $high = $mid;
                }
            }
            return round((($low + $high) / 2) * 100, 6);
        } catch (\InvalidArgumentException $error) {
            return null;
        }
    }

    private static function application(array $case): string
    {
        $html = self::table([
            'Product' => $case['product'] ?? '',
            'Loan purpose' => $case['purpose'] ?? '',
            'Requested amount' => self::money((int) ($case['requested_amount_paise'] ?? 0)),
            'Application date (UTC)' => $case['created_at'] ?? '',
        ]);
        foreach (self::schema()['roles'] as $role => $labels) {
            $party = $case['parties'][$role] ?? [];
            $profile = $party['profile'] ?? [];
            $bank = $party['bank'] ?? [];
            $html .= '<h2>' . self::e($labels['en'] . ' / ' . $labels['hi']) . '</h2>';
            $html .= self::table([
                'Party ID' => $party['id'] ?? '',
                'Legal name' => $profile['legal_name'] ?? $profile['name'] ?? '',
                'Date of birth' => $profile['dob'] ?? '',
                'Occupation' => $profile['occupation'] ?? '',
                'Relationship' => $profile['relationship'] ?? ($role === 'applicant' ? 'SELF' : ''),
                'Mobile (masked)' => self::mask($profile['mobile'] ?? ''),
                'PAN (masked)' => self::mask($profile['pan'] ?? ''),
                'Aadhaar last four' => self::mask($profile['aadhaar_last4'] ?? ''),
                'Voter ID (masked)' => self::mask($profile['voter_id'] ?? ''),
                'Current address' => $profile['current_address'] ?? '',
                'Permanent address' => $profile['permanent_address'] ?? '',
                'Years at current address' => $profile['years_at_address'] ?? '',
                'Residence owner' => $profile['residence_owner_name'] ?? '',
                'Owner relationship' => $profile['owner_relationship'] ?? '',
                'Annual household income' => isset($profile['annual_household_income_paise']) ? self::money((int) $profile['annual_household_income_paise']) : '',
                'Aadhaar-linked mobile declaration' => !empty($profile['aadhaar_linked_mobile_declared']) ? 'Declared by party; not independently verified' : 'Not declared',
                'Bank account holder' => $bank['holder_name'] ?? '',
                'Bank' => $bank['bank_name'] ?? '',
                'Account number (masked)' => self::mask($bank['account_number'] ?? $bank['account_last4'] ?? ''),
                'IFSC' => $bank['ifsc'] ?? '',
                'Bank verification status' => $bank['status'] ?? $bank['verification_status'] ?? 'Not verified',
            ]);
        }
        return $html . '<p class="note">Submission is an application for consideration and does not guarantee loan approval. Individual declarations and purpose-specific consents are retained separately with their exact accepted versions.</p>';
    }

    private static function loanFacts(array $case, array $settings): string
    {
        $loan = self::loan($case, $settings);
        $terms = self::normalizedTerms($loan);
        return '<h2>Loan details</h2>' . self::table([
            'Loan ID' => $loan['id'] ?? '',
            'Loan kind' => ($settings['loan_kind'] ?? 'bc') === 'initial' ? 'Initial loan — separate lender obligation' : 'Final BC loan — separate lender obligation',
            'Actual lender' => $loan['lender_name'] ?? $loan['lender'] ?? $settings['lender_name'] ?? '',
            'Sanctioned amount' => self::money((int) ($loan['amount_paise'] ?? 0)),
            'Borrower allocation' => self::summary($loan['borrower_allocations'] ?? $loan['borrower_allocation'] ?? $terms['borrower_allocation'] ?? []),
            'Loan purpose' => $case['purpose'] ?? '',
            'Tenure in months' => $terms['tenure_months'] ?? '',
            'Annual nominal interest rate (%)' => $terms['annual_rate'] ?? $terms['interest_rate'] ?? '',
            'Interest type' => $terms['interest_type'] ?? 'Fixed reducing balance illustration; lender terms control',
            'Repayment frequency' => $terms['frequency'] ?? $terms['repayment_frequency'] ?? '',
            'First due date' => $terms['first_due_date'] ?? '',
            'Terms version' => $terms['version'] ?? $settings['terms_version'] ?? '',
            'Sanction validity' => $terms['sanction_valid_until'] ?? '',
        ]);
    }

    private static function kfs(array $case, array $settings): string
    {
        $loan = self::loan($case, $settings);
        $terms = self::normalizedTerms($loan);
        $terms['amount_paise'] = $loan['amount_paise'] ?? $terms['amount_paise'] ?? 0;
        $html = self::loanFacts($case, $settings);
        $fees = self::fees($terms);
        $html .= '<h2>Fees, disclosures and grievance information</h2>' . self::table([
            'Processing fee' => self::money((int) ($terms['processing_fee_paise'] ?? 0)),
            'Taxes' => self::money((int) ($terms['tax_paise'] ?? 0)),
            'Insurance' => self::money((int) ($terms['insurance_fee_paise'] ?? 0)),
            'Stamp / documentation charges' => self::money((int) ($terms['stamp_fee_paise'] ?? 0)),
            'Other disclosed upfront charges' => self::money((int) ($terms['other_fee_paise'] ?? 0)),
            'Total upfront charges' => self::money($fees),
            'Net disbursed amount' => self::money((int) ($terms['net_disbursed_paise'] ?? max(0, (int) $terms['amount_paise'] - $fees))),
            'Disbursement date' => $terms['disbursement_date'] ?? '',
            'Penal charges' => $terms['penal_charges'] ?? 'Not configured — lender disclosure required',
            'Foreclosure / prepayment' => $terms['foreclosure_charges'] ?? 'Not configured — lender disclosure required',
            'Bounce / other contingent charges' => $terms['contingent_charges'] ?? 'Not configured — lender disclosure required',
            'Cooling-off period' => $terms['cooling_off_period'] ?? 'Not configured',
            'Recovery agent details' => $terms['recovery_agent'] ?? 'Not configured',
            'Grievance contact' => $settings['grievance_contact'] ?? 'Not configured',
            'Co-lending / transfer disclosure' => $terms['co_lending_disclosure'] ?? 'Not configured',
        ]);
        try {
            $schedule = self::schedule($terms);
            $apr = self::apr($terms, $schedule);
            $totalInterest = array_sum(array_column($schedule, 'interest_paise'));
            $html .= '<h2>APR illustration</h2>' . self::table([
                'Total interest' => self::money($totalInterest),
                'Total instalments payable (principal + interest)' => self::money(array_sum(array_column($schedule, 'payment_paise'))),
                'Number of instalments' => count($schedule),
                'Effective annualized APR, actual-date IRR (%)' => $apr === null ? 'Unavailable — complete valid disbursement/repayment dates and net disbursal' : number_format($apr, 4, '.', ''),
            ]);
            $html .= '<p class="note">Illustration assumes fixed reducing-balance interest and the specified dates, with upfront charges deducted from principal. No unconfigured fee or rate from the sample ISF form is assumed. Broken-period interest, holidays and lender-specific day-count adjustments require the lender-approved schedule.</p>';
            $html .= '<h2>Repayment schedule</h2><table><thead><tr><th>No.</th><th>Due date</th><th>Opening</th><th>Principal</th><th>Interest</th><th>Instalment</th><th>Closing</th></tr></thead><tbody>';
            foreach ($schedule as $row) {
                $html .= '<tr><td>' . $row['number'] . '</td><td>' . self::e($row['due_date']) . '</td>';
                foreach (['opening_paise', 'principal_paise', 'interest_paise', 'payment_paise', 'closing_paise'] as $key) {
                    $html .= '<td class="nowrap">' . self::e(self::money($row[$key])) . '</td>';
                }
                $html .= '</tr>';
            }
            $html .= '</tbody></table>';
        } catch (\InvalidArgumentException $error) {
            $html .= '<p class="draft">Schedule and APR unavailable: ' . self::e($error->getMessage()) . '</p>';
        }
        return $html . self::legalText('kfs', $case, $settings);
    }

    private static function membership(array $case, array $settings): string
    {
        $slt = (array) ($case['slt'] ?? []);
        $return = (array) ($case['return_collection'] ?? []);
        $html = self::partyNames($case) . self::table([
            'Receiving entity' => 'Shubh Labh Trust',
            'SLT contribution ID' => $slt['id'] ?? '',
            'Contribution amount' => self::money(2500000),
            'Contribution frequency' => 'One time, with separate eNACH authorization',
            'Membership terms version' => $slt['terms']['version'] ?? $slt['terms_version'] ?? $settings['terms_version'] ?? '',
            'Membership purpose' => $slt['purpose'] ?? $settings['slt_purpose'] ?? 'Not configured',
            'Participation' => $settings['slt_participation'] ?? 'Optional / product condition not configured',
            'Refund / withdrawal / grievance rules' => $settings['slt_refund_rules'] ?? 'Not configured',
            'Authorized due date' => $slt['due_at'] ?? $slt['due_date'] ?? '',
            'Separate INR 10,000 return recipient' => $return['recipient'] ?? $return['recipient_name'] ?? 'Not configured',
            'Separate return amount' => self::money(1000000),
        ]);
        $html .= '<p class="note">The INR 25,000 SLT contribution is additional to the separate INR 10,000 return collection. Neither offsets the other. Neither receipt proves repayment or closure of the original lender loan. Mandate registration is not a debit. SLT debit requires confirmed final BC disbursement, active separate authorization, an authorized due date and applicable notice.</p>';
        return $html . self::legalText('membership', $case, $settings);
    }

    private static function receipt(array $case, array $settings): string
    {
        $payment = (array) ($settings['receipt'] ?? $case['receipt'] ?? []);
        if (!self::settledReceipt($payment)) {
            return '<p class="draft">A settlement receipt cannot be issued: a confirmed settlement reference, amount, obligation, recipient and settlement date are required. Initiation acknowledgements, screenshots and mandate registrations do not establish settlement.</p>';
        }
        return self::table([
            'Receipt reference' => $payment['receipt_id'] ?? $payment['id'] ?? '',
            'Obligation ID' => $payment['obligation_id'],
            'Purpose' => $payment['purpose'] ?? '',
            'Receiving entity' => $payment['recipient_name'],
            'Amount received' => self::money((int) $payment['amount_paise']),
            'Currency' => 'INR',
            'Settlement reference' => $payment['settlement_reference'],
            'Settlement date (UTC)' => $payment['settled_at'],
            'Payment mode' => $payment['payment_mode'] ?? 'Not recorded',
            'Confirmation source' => $payment['source'] ?? 'Authoritative source required',
        ]) . '<p class="note">This receipt applies only to the named obligation and receiving entity. It does not close another lender loan or offset a separate contribution.</p>';
    }

    private static function kit(array $case): string
    {
        $kit = (array) ($case['db_kit'] ?? []);
        $html = self::table([
            'Pack ID' => $kit['id'] ?? '', 'Pack version' => $kit['version'] ?? '',
            'Pack state' => $kit['status'] ?? 'Not prepared',
            'Submitted at (UTC)' => $kit['submission']['recorded_at'] ?? $kit['submitted_at'] ?? '',
            'BC partner acceptance reference' => $kit['acceptance']['reference'] ?? $kit['acceptance_reference'] ?? '',
            'Accepted at (UTC)' => $kit['acceptance']['recorded_at'] ?? $kit['accepted_at'] ?? '',
        ]);
        $html .= '<h2>Party evidence inventory</h2><table><thead><tr><th>Party</th><th>Document type</th><th>Version / ID</th><th>Review state</th><th>SHA-256</th></tr></thead><tbody>';
        foreach ((array) ($case['parties'] ?? []) as $role => $party) {
            foreach ((array) ($party['documents'] ?? []) as $key => $document) {
                if (!is_array($document)) {
                    continue;
                }
                $html .= '<tr><td>' . self::e((string) $role) . '</td><td>' . self::e(self::text($document['type'] ?? $key)) . '</td><td>' . self::e(self::text($document['id'] ?? '') . ' / ' . self::text($document['version'] ?? '')) . '</td><td>' . self::e(self::text($document['status'] ?? '')) . '</td><td>' . self::e(self::text($document['sha256'] ?? $document['hash'] ?? '')) . '</td></tr>';
            }
        }
        $html .= '</tbody></table><h2>Independent financial records</h2>' . self::table([
            'Initial loan ID' => $case['loans']['initial']['id'] ?? '',
            'Initial lender repayment / closure' => $case['loans']['initial']['status'] ?? 'Not confirmed',
            'INR 10,000 return state' => $case['return_collection']['status'] ?? 'Not confirmed',
            'SLT contribution ID' => $case['slt']['id'] ?? '',
            'SLT membership / mandate' => $case['slt']['status'] ?? 'Not confirmed',
            'BC loan ID' => $case['loans']['bc']['id'] ?? '',
        ]);
        $html .= '<h2>Checklist snapshot</h2><pre>' . self::e(self::summary($kit['checklist'] ?? $kit['items'] ?? [])) . '</pre>';
        return $html . '<p class="note">Inventory only. Submission is not BC partner acceptance. Verify the exact accepted pack version, executed documents, passed FVR/BVR, closed blocking queries, beneficiary verification and all financial gates before disbursement. Private evidence is downloaded separately under scoped authorization.</p>';
    }

    private static function legalText(string $type, array $case, array $settings): string
    {
        $template = $settings['document_templates'][$type] ?? [];
        $text = is_array($template) ? self::text($template['text'] ?? '') : self::text($template);
        if ($text === '' && $type === 'agreement') {
            $text = self::text($settings['approved_terms_text'] ?? '');
        }
        if ($text === '') {
            return '<p class="draft">The lender / legal owner must supply the approved ' . self::e(self::TYPES[$type] ?? $type) . ' text. The sample ISF form has not been adopted as digital BE contractual terms.</p>';
        }
        $loan = self::loan($case, $settings);
        $text = strtr($text, [
            '{{application_id}}' => self::text($case['id'] ?? ''),
            '{{group_id}}' => self::text($case['group_id'] ?? ''),
            '{{lender_name}}' => self::text($settings['lender_name'] ?? ''),
            '{{borrower_name}}' => self::text($case['parties']['applicant']['profile']['legal_name'] ?? ''),
            '{{loan_id}}' => self::text($loan['id'] ?? ''),
            '{{loan_amount}}' => self::money((int) ($loan['amount_paise'] ?? 0)),
            '{{slt_amount}}' => self::money(2500000),
        ]);
        return '<h2>Approved template text</h2><pre>' . self::e($text) . '</pre>';
    }

    private static function approved(string $type, array $case, array $settings): bool
    {
        if ($type === 'receipt') {
            return self::settledReceipt((array) ($settings['receipt'] ?? $case['receipt'] ?? []));
        }
        $template = $settings['document_templates'][$type] ?? [];
        $specificText = is_array($template) ? self::text($template['text'] ?? '') : self::text($template);
        $approved = is_array($template) ? !empty($template['approved']) : false;
        if (!in_array($type, ['application', 'db_kit'], true) && $specificText === '' && !($type === 'agreement' && !empty($settings['approved_terms_text']))) {
            return false;
        }
        if (empty($settings['terms_approved']) || empty($settings['lender_name']) || self::templateVersion($type, $settings) === '') {
            return false;
        }
        if ($specificText !== '' && !$approved) {
            return false;
        }
        if ($type !== 'db_kit' && empty($settings['signer_roles'][$type])) {
            return false;
        }
        if ($type === 'kfs') {
            try {
                $loan = self::loan($case, $settings);
                $terms = self::normalizedTerms($loan);
                $terms['amount_paise'] = $loan['amount_paise'] ?? 0;
                if (self::apr($terms, self::schedule($terms)) === null) {
                    return false;
                }
            } catch (\InvalidArgumentException $error) {
                return false;
            }
        }
        return true;
    }

    private static function settledReceipt(array $payment): bool
    {
        $status = strtolower(self::text($payment['status'] ?? ''));
        return in_array($status, ['settled', 'confirmed'], true)
            && (int) ($payment['amount_paise'] ?? 0) > 0
            && !empty($payment['settlement_reference']) && !empty($payment['settled_at'])
            && !empty($payment['obligation_id']) && !empty($payment['recipient_name']);
    }

    private static function templateVersion(string $type, array $settings): string
    {
        $template = $settings['document_templates'][$type] ?? [];
        return self::text(is_array($template) ? ($template['version'] ?? $settings['template_version'] ?? '') : ($settings['template_version'] ?? ''));
    }

    private static function signatures(array $case, string $type, array $settings): string
    {
        $html = '<h2>Required signer matrix</h2><div class="signatures">';
        foreach ((array) ($settings['signer_roles'][$type] ?? array_keys(self::schema()['roles'])) as $role) {
            $party = $case['parties'][$role] ?? [];
            $html .= '<div class="signature">' . self::e(self::schema()['roles'][$role]['en'] ?? (string) $role) . '<br>' . self::e(self::text($party['profile']['legal_name'] ?? $party['profile']['name'] ?? '')) . '<br>Party ID: ' . self::e(self::text($party['id'] ?? '')) . '<br>Execution evidence: retained separately</div>';
        }
        return $html . '</div>';
    }

    private static function partyNames(array $case): string
    {
        $rows = [];
        foreach (self::schema()['roles'] as $role => $label) {
            $rows[$label['en']] = $case['parties'][$role]['profile']['legal_name'] ?? $case['parties'][$role]['profile']['name'] ?? '';
        }
        return '<h2>Parties</h2>' . self::table($rows);
    }

    private static function loan(array $case, array $settings): array
    {
        $kind = ($settings['loan_kind'] ?? 'bc') === 'initial' ? 'initial' : 'bc';
        return (array) ($case['loans'][$kind] ?? []);
    }

    /** The workflow retains commercial metadata inside an immutable terms object. */
    private static function normalizedTerms(array $loan): array
    {
        $raw = (array) ($loan['terms'] ?? []);
        $terms = array_replace((array) ($raw['metadata'] ?? []), $raw);
        $terms['amount_paise'] = $loan['amount_paise'] ?? $terms['amount_paise'] ?? 0;
        if (!isset($terms['annual_rate']) && isset($terms['annual_interest_bps'])) {
            $terms['annual_rate'] = (float) $terms['annual_interest_bps'] / 100;
        }
        $terms['frequency'] = strtolower((string) ($terms['frequency'] ?? $terms['repayment_frequency'] ?? 'monthly'));
        if (empty($terms['first_due_date']) && !empty($terms['first_due_at'])) {
            $terms['first_due_date'] = substr((string) $terms['first_due_at'], 0, 10);
        }
        $terms['net_disbursed_paise'] = $loan['net_disbursement_paise'] ?? $terms['net_disbursed_paise'] ?? $terms['net_disbursement_paise'] ?? null;
        if ($terms['net_disbursed_paise'] === null) {
            unset($terms['net_disbursed_paise']);
        }
        if (!isset($terms['other_fee_paise']) && isset($terms['other_charges_paise'])) {
            $terms['other_fee_paise'] = $terms['other_charges_paise'];
        }
        if (empty($terms['disbursement_date']) && !empty($terms['expected_disbursement_at'])) {
            $terms['disbursement_date'] = substr((string) $terms['expected_disbursement_at'], 0, 10);
        }
        // Only the original disbursement ledger supplies the actual start date.
        foreach ((array) ($loan['settlements'] ?? []) as $settlement) {
            if (($settlement['ledger_kind'] ?? 'primary') === 'primary' && !empty($settlement['settled_at'])) {
                $terms['disbursement_date'] = substr((string) $settlement['settled_at'], 0, 10);
                break;
            }
        }
        return $terms;
    }

    private static function resolveType(string $type, array $settings): array
    {
        if (preg_match('/^(initial|bc)_(application|sanction|kfs|agreement|dpn|indemnity)$/', $type, $match)) {
            $settings['loan_kind'] = $match[1];
            $type = $match[2];
        }
        return [$type, $settings];
    }

    private static function fees(array $terms): int
    {
        $total = 0;
        foreach (['processing_fee_paise', 'tax_paise', 'insurance_fee_paise', 'stamp_fee_paise', 'other_fee_paise'] as $key) {
            $total += self::minor($terms[$key] ?? 0);
        }
        return $total;
    }

    private static function minor($value): int
    {
        if ((!is_int($value) && !(is_string($value) && preg_match('/^[0-9]+$/D', $value))) || (int) $value < 0 || (float) $value > 1000000000000) {
            throw new \InvalidArgumentException('Money must be a non-negative integer number of paise.');
        }
        return (int) $value;
    }

    private static function date(string $date): \DateTimeImmutable
    {
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));
        if (!$parsed || $parsed->format('Y-m-d') !== $date) {
            throw new \InvalidArgumentException('A valid YYYY-MM-DD date is required.');
        }
        return $parsed;
    }

    private static function table(array $rows): string
    {
        $html = '<table><tbody>';
        foreach ($rows as $label => $value) {
            $html .= '<tr><th scope="row">' . self::e((string) $label) . '</th><td>' . nl2br(self::e(self::text($value)), false) . '</td></tr>';
        }
        return $html . '</tbody></table>';
    }

    private static function money(int $paise): string
    {
        $negative = $paise < 0 ? '-' : '';
        $paise = abs($paise);
        $rupees = (string) intdiv($paise, 100);
        if (strlen($rupees) > 3) {
            $last = substr($rupees, -3);
            $prefix = substr($rupees, 0, -3);
            $prefix = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $prefix);
            $rupees = $prefix . ',' . $last;
        }
        return $negative . 'INR ' . $rupees . '.' . str_pad((string) ($paise % 100), 2, '0', STR_PAD_LEFT);
    }

    private static function mask($value): string
    {
        $value = self::text($value);
        return $value === '' ? '' : '•••• ' . substr($value, -4);
    }

    private static function summary($value): string
    {
        if (!is_array($value)) {
            return self::text($value);
        }
        return (string) json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    private static function text($value): string
    {
        return is_scalar($value) ? (string) $value : '';
    }

    private static function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
