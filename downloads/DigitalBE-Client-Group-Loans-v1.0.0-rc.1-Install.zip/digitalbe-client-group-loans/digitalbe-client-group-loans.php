<?php
/**
 * Plugin Name: digital BE Client & Group Loans
 * Description: Client onboarding, group loan operations, Surepass KYC and independently reconciled loan and contribution workflows.
 * Version: 1.0.0-rc.1
 * Author: digital BE
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Text Domain: digitalbe-client-group-loans
 * License: GPL-2.0-or-later
 */
namespace DigitalBE\ClientGroupLoans;
defined('ABSPATH') || exit;
define('DBCL_VERSION', '1.0.0-rc.1');
define('DBCL_FILE', __FILE__);
define('DBCL_DIR', __DIR__ . '/');
foreach (['crypto', 'store', 'auth', 'workflow', 'documents', 'providers', 'esign', 'notifications', 'api', 'ui'] as $module) {
    require_once DBCL_DIR . 'includes/class-' . $module . '.php';
}
register_activation_hook(__FILE__, static function () {
    Store::install();
    Auth::install();
    update_option('dbcl_version', DBCL_VERSION, false);
    if (!wp_next_scheduled('dbcl_daily_tasks')) {
        wp_schedule_event(time() + 300, 'daily', 'dbcl_daily_tasks');
    }
});
register_deactivation_hook(__FILE__, static function () { wp_clear_scheduled_hook('dbcl_daily_tasks'); });
add_action('plugins_loaded', static function () {
    load_plugin_textdomain('digitalbe-client-group-loans', false, dirname(plugin_basename(DBCL_FILE)) . '/languages');
    UI::register();
    Notifications::register();
});
add_action('rest_api_init', [API::class, 'register']);
add_action('rest_api_init', [ESign::class, 'register']);
add_action('dbcl_daily_tasks', static function () {
    // Delivery adapters consume this hook. It never sends messages or executes payments by itself.
    do_action('dbcl_run_reminders', gmdate('c'));
});
