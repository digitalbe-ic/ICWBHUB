/* digital BE Client & Group Loans. No financial data is persisted in browser storage. */
(() => {
  'use strict';
  const host = document.getElementById('dbcl-app');
  if (!host || !window.DBCL) return;
  const cfg = window.DBCL;
  const state = { lang: 'en', view: host.dataset.view || 'workspace', list: [], total: 0, page: 1, active: null, gates: {}, actor: {}, files: [], snapshots: [], tab: 'overview', role: 'applicant', message: '', error: false, busy: false, filter: '', settings: null, invitation: null, providerAction: null, consentTexts: {}, settingsReview: null };
  const streams = new Set();
  let sdkReady = null, sdkHandle = null, sdkGuard = null;
  const words = {
    en: { workspace: 'Client & Group Loans', loading: 'Loading…', back: 'All applications', create: 'Start an application', save: 'Save changes', cancel: 'Cancel', overview: 'Overview', parties: 'Group & documents', operations: 'Operations', finance: 'Financial records', documents: 'Generated documents', signatures: 'Signature centre', notifications: 'Notifications', audit: 'Audit history', reload: 'Refresh', empty: 'No applications to display.', next: 'Next', previous: 'Previous', settings: 'Configuration', status: 'Status', signedIn: 'Signed in as', original: 'Photograph the original document. Photocopies and screenshots are not accepted.', separate: 'The initial loan, return collection, final BC loan and SLT contribution are separate obligations. A return collection does not repay the initial lender.', new: 'New application', saved: 'Changes saved.', notAvailable: 'Not recorded', own: 'Each participant must sign in separately to give their own consent and accept terms.', note: 'This workspace records externally completed activities. No payment or eNACH debit is executed from these screens.', unavailable: 'This feature requires the configured provider or permission.', claim: 'Claim participant invitation' },
    hi: { workspace: 'ग्राहक एवं समूह ऋण', loading: 'लोड हो रहा है…', back: 'सभी आवेदन', create: 'नया आवेदन शुरू करें', save: 'परिवर्तन सहेजें', cancel: 'रद्द करें', overview: 'अवलोकन', parties: 'समूह और दस्तावेज़', operations: 'कार्यवाही', finance: 'वित्तीय रिकॉर्ड', documents: 'तैयार दस्तावेज़', signatures: 'हस्ताक्षर केंद्र', notifications: 'सूचनाएं', audit: 'ऑडिट इतिहास', reload: 'रीफ़्रेश', empty: 'कोई आवेदन उपलब्ध नहीं है।', next: 'अगला', previous: 'पिछला', settings: 'कॉन्फ़िगरेशन', status: 'स्थिति', signedIn: 'साइन इन', original: 'मूल दस्तावेज़ की फोटो लें। फोटोकॉपी और स्क्रीनशॉट स्वीकार नहीं हैं।', separate: 'प्रारंभिक ऋण, वापसी संग्रह, अंतिम बीसी ऋण और एसएलटी योगदान अलग दायित्व हैं। वापसी संग्रह से मूल ऋणदाता का ऋण चुकाया नहीं जाता।', new: 'नया आवेदन', saved: 'परिवर्तन सहेजे गए।', notAvailable: 'दर्ज नहीं है', own: 'हर सदस्य अपनी सहमति और शर्तें स्वीकार करने के लिए अलग से साइन इन करे।', note: 'यह कार्यस्थान बाहर पूरी की गई गतिविधियों का रिकॉर्ड रखता है। यहां से भुगतान या ईनाच डेबिट नहीं किया जाता।', unavailable: 'इस सुविधा के लिए कॉन्फ़िगर किया हुआ प्रदाता या अनुमति आवश्यक है।', claim: 'सदस्य आमंत्रण स्वीकार करें' }
  };
  const t = key => words[state.lang][key] || words.en[key] || key;
  const label = value => typeof value === 'object' && value ? (value[state.lang] || value.en || '') : String(value ?? '');
  const human = value => String(value ?? '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  const money = paise => new Intl.NumberFormat(state.lang === 'hi' ? 'hi-IN' : 'en-IN', { style: 'currency', currency: 'INR' }).format(Number(paise || 0) / 100);
  const time = value => { if (!value) return t('notAvailable'); const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(value)) ? String(value).replace(' ', 'T') + 'Z' : value; return Number.isNaN(Date.parse(normalized)) ? String(value) : new Intl.DateTimeFormat(state.lang === 'hi' ? 'hi-IN' : 'en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }).format(new Date(normalized)) + ' IST'; };
  function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([name, value]) => {
      if (value == null || value === false) return;
      if (name === 'class') node.className = value;
      else if (name === 'text') node.textContent = value;
      else if (name.startsWith('on')) node.addEventListener(name.slice(2).toLowerCase(), value);
      else if (name === 'checked' || name === 'disabled' || name === 'required' || name === 'selected') node[name] = !!value;
      else node.setAttribute(name, String(value));
    });
    children.flat(Infinity).filter(c => c != null && c !== false).forEach(c => node.append(c.nodeType ? c : document.createTextNode(String(c))));
    return node;
  }
  function button(text, action, secondary = false, attrs = {}) { return el('button', { type: 'button', class: secondary ? 'dbcl-button secondary' : 'dbcl-button', onClick: action, disabled: state.busy, ...attrs }, text); }
  function badge(text) { const s = String(text || 'PENDING'); const category = s.toUpperCase(); return el('span', { class: 'dbcl-badge ' + (/ACCEPTED|PASS|ACTIVE|SETTLED|SUCCESS|CLOSED|COMPLETE|VERIFIED/.test(category) && !/NOT_|UNVERIFIED/.test(category) ? 'good' : /FAIL|REJECT|CANCEL|ERROR|DECLIN/.test(category) ? 'bad' : 'pending') }, human(s)); }
  function note(text, kind = '') { return el('div', { class: 'dbcl-note ' + kind }, text); }
  function panel(title, ...content) { return el('section', { class: 'dbcl-panel' }, title ? el('h2', {}, title) : null, content); }
  function empty(text = t('empty')) { return el('p', { class: 'dbcl-muted' }, text); }
  function field(def, value = '') {
    const type = def.type || 'text';
    const name = def.name;
    const id = 'dbcl-' + name + '-' + Math.random().toString(36).slice(2, 7);
    const base = { id, name, required: !!def.required, autocomplete: 'off' };
    if (def.maxLength) base.maxlength = def.maxLength;
    if (def.pattern) base.pattern = def.pattern;
    let input;
    if (type === 'textarea') input = el('textarea', { ...base, rows: 4 }, value || '');
    else if (type === 'select' || def.options) {
      input = el('select', base, el('option', { value: '' }, '— ' + (state.lang === 'hi' ? 'चुनें' : 'Select') + ' —'));
      const options = def.options || [];
      Object.entries(options).forEach(([key, option]) => {
        const val = typeof option === 'object' ? (option.value ?? key) : (Array.isArray(options) ? option : key);
        const title = typeof option === 'object' ? label(option.label || option) : (Array.isArray(options) ? human(option) : option);
        input.append(el('option', { value: val, selected: String(val) === String(value) }, title));
      });
    } else if (type === 'checkbox' || type === 'boolean') input = el('input', { ...base, type: 'checkbox', checked: !!value });
    else {
      input = el('input', { ...base, type: type === 'money' ? 'number' : ['date', 'datetime-local', 'number', 'email', 'tel', 'url', 'password'].includes(type) ? type : 'text', value: value === null ? '' : type === 'money' && value !== '' ? Number(value) / 100 : value });
      if (type === 'money') { input.dataset.money = 'true'; input.step = '0.01'; input.min = def.min === undefined ? '0' : String(def.min / 100); }
      else { if (def.min !== undefined) input.min = def.min; if (def.max !== undefined) input.max = def.max; }
      if (type === 'number') input.step = def.step || 'any';
    }
    if (def.placeholder) input.placeholder = def.placeholder;
    const title = label(def.label || human(name)).replace(/\(UTC\)/g, '(IST)') + (def.required ? ' *' : '');
    const wrapper = el('label', { class: 'dbcl-field ' + (type === 'checkbox' || type === 'boolean' ? 'check' : ''), for: id }, type === 'checkbox' || type === 'boolean' ? [input, el('span', {}, title)] : [el('span', {}, title), input]);
    if (def.help) wrapper.append(el('small', {}, label(def.help)));
    return wrapper;
  }
  function values(form) {
    const out = {};
    for (const input of form.querySelectorAll('[name]')) {
      if (input.disabled || input.type === 'file' || (input.dataset.preserve && input.value === '')) continue;
      let value = input.type === 'checkbox' ? input.checked : input.value;
      if (input.dataset.money) value = Math.round(Number(value || 0) * 100);
      else if (input.type === 'number' && value !== '') value = Number(value);
      if (input.type === 'datetime-local' && value) value = new Date(value + '+05:30').toISOString();
      if (input.dataset.bps) value = Math.round(Number(value || 0) * 100);
      if (input.dataset.json) {
        if (!value.trim()) value = {};
        else { try { value = JSON.parse(value); } catch (_) { throw new Error('Invalid JSON in ' + input.name); } }
      }
      out[input.name] = value;
    }
    return out;
  }
  async function api(path, opts = {}) {
    const headers = { 'X-WP-Nonce': cfg.nonce, ...(opts.headers || {}) };
    if (opts.body && !(opts.body instanceof FormData)) headers['Content-Type'] = 'application/json';
    const response = await fetch(cfg.root + path.replace(/^\//, ''), { credentials: 'same-origin', ...opts, headers, body: opts.body && !(opts.body instanceof FormData) ? JSON.stringify(opts.body) : opts.body });
    if (opts.blob && response.ok) return response.blob();
    const result = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(result.message || 'The request could not be completed.'); error.code = result.code; throw error; }
    return result;
  }
  async function task(action, success = t('saved')) {
    if (state.busy) return;
    state.busy = true; state.message = t('loading'); state.error = false; status();
    host.querySelectorAll('button').forEach(b => { b.disabled = true; });
    try { await action(); if (state.message === t('loading')) state.message = success; } catch (error) { state.error = true; state.message = error.message; }
    state.busy = false; render();
  }
  function status() {
    const box = host.querySelector('#dbcl-status');
    if (box) { box.textContent = state.message; box.className = 'dbcl-status' + (state.error ? ' error' : ''); box.hidden = !state.message; }
  }
  function stopCamera() { streams.forEach(s => s.getTracks().forEach(track => track.stop())); streams.clear(); }
  async function list() {
    const result = await api('applications?page=' + state.page);
    state.list = result.applications || result.rows || [];
    state.total = result.total ?? state.list.length;
  }
  async function open(id) {
    const result = await api('applications/' + encodeURIComponent(id));
    const previousId = state.active?.id;
    state.active = result.application || result;
    if (previousId !== state.active.id) { state.invitation = null; state.providerAction = null; }
    state.gates = result.gates || state.active.gates || {};
    state.actor = result.actor || {};
    state.files = result.files || [];
    state.snapshots = Object.values(result.snapshots || state.active.snapshots || []);
    state.consentTexts = result.consent_texts || state.active.consent_texts || {};
    state.verificationAttempts = result.verification_attempts || [];
    if (state.actor.party_role) state.role = state.actor.party_role;
  }
  async function mutate(path, body) {
    const id = state.active.id;
    const result = await api('applications/' + encodeURIComponent(id) + '/' + path, { method: 'POST', body: { expected_version: state.active.version, ...body } });
    await open(id);
    return result;
  }
  function caps() { return state.actor.capabilities || cfg.user.capabilities || []; }
  function isStaff() { return !state.actor?.party_role && (cfg.user.staff || caps().some(cap => /^dbcl_/.test(cap))); }
  function owns(role) { const p = (state.active?.parties || {})[role]; return p && Number(p.user_id) === Number(cfg.user.id); }
  function availableRoles() { return Object.entries(state.active.parties || {}).filter(([r, p]) => isStaff() || owns(r) || r === state.actor.party_role); }
  function header() {
    const lang = el('select', { 'aria-label': 'Language / भाषा', onChange: e => { state.lang = e.target.value; render(); } }, el('option', { value: 'en', selected: state.lang === 'en' }, 'English'), el('option', { value: 'hi', selected: state.lang === 'hi' }, 'हिन्दी'));
    return el('header', { class: 'dbcl-header' }, el('div', { class: 'dbcl-brand' }, el('div', { class: 'dbcl-mark', 'aria-hidden': 'true' }, 'd', el('span', {}, 'BE')), el('div', {}, el('strong', {}, 'digital BE'), el('small', {}, t('workspace')))), el('div', { class: 'dbcl-header-actions' }, el('span', { class: 'dbcl-user' }, t('signedIn') + ' ' + cfg.user.name), lang));
  }
  function render() {
    stopCamera(); disposeSdk(); host.replaceChildren(); host.lang = state.lang;
    host.append(header(), el('div', { id: 'dbcl-status', class: 'dbcl-status' + (state.error ? ' error' : ''), role: state.error ? 'alert' : 'status', 'aria-live': 'polite', hidden: !state.message }, state.message));
    if (state.settingsReview && state.view !== 'settings') renderApproval();
    if (state.view === 'settings') renderSettings();
    else if (state.active) renderCase();
    else renderList();
    host.append(el('footer', { class: 'dbcl-footer' }, 'digital BE · ' + t('workspace') + ' · ' + (state.lang === 'hi' ? 'समय: भारत मानक समय (IST)' : 'Times shown in India Standard Time (IST)')));
    if (state.busy) host.querySelectorAll('button').forEach(b => { b.disabled = true; });
  }
  function renderList() {
    const heading = el('div', { class: 'dbcl-toolbar' }, el('div', {}, el('p', { class: 'dbcl-eyebrow' }, isStaff() ? 'OPERATIONS WORKSPACE' : 'YOUR APPLICATIONS'), el('h1', {}, t('workspace'))), button(t('create'), () => createForm()));
    const filter = el('input', { type: 'search', placeholder: state.lang === 'hi' ? 'आवेदन, शाखा या चरण खोजें' : 'Search application, branch or stage', 'aria-label': 'Filter applications', value: state.filter, onInput: e => { state.filter = e.target.value; renderRows(); } });
    if (caps().includes('dbcl_assign') || caps().includes('dbcl_audit')) heading.append(button('Download scoped report', () => task(() => download('reports', 'loan-work-queue.csv'), ''), true));
    host.append(heading, el('div', { class: 'dbcl-metrics' }, metric('Applications in scope', state.total), metric('Current page', state.page), metric('Data access', isStaff() ? 'Assigned / scoped cases' : 'Your linked applications')), panel('', filter, el('div', { id: 'dbcl-case-list' })));
    renderRows();
    const pages = el('div', { class: 'dbcl-pagination' }, button(t('previous'), () => task(async () => { state.page--; await list(); }, ''), true, { disabled: state.page <= 1 }), el('span', {}, 'Page ' + state.page), button(t('next'), () => task(async () => { state.page++; await list(); }, ''), true, { disabled: state.page * 25 >= state.total }));
    host.append(pages, invitationClaim());
  }
  function metric(title, value) { return el('div', {}, el('small', {}, title), el('strong', {}, String(value))); }
  function renderRows() {
    const target = host.querySelector('#dbcl-case-list'); if (!target) return;
    target.replaceChildren();
    const q = state.filter.toLowerCase();
    const rows = state.list.filter(row => !q || Object.values(row).some(v => typeof v !== 'object' && String(v).toLowerCase().includes(q)));
    if (!rows.length) { target.append(empty()); return; }
    rows.forEach(row => target.append(el('button', { type: 'button', class: 'dbcl-case-row', onClick: () => task(() => open(row.id), '') }, el('span', {}, el('strong', {}, row.reference || row.id), el('small', {}, [row.branch, row.product].filter(Boolean).join(' · '))), badge(row.stage || row.status || 'DRAFT'), el('span', {}, time(row.updated_at || row.created_at)), el('span', { 'aria-hidden': 'true' }, '→'))));
  }
  function createForm() {
    host.querySelector('#dbcl-create')?.remove();
    const form = el('form', { id: 'dbcl-create', class: 'dbcl-panel', onSubmit: e => { e.preventDefault(); task(async () => { const result = await api('applications', { method: 'POST', body: values(form) }); await open((result.application || result).id); }, ''); } }, el('h2', {}, t('new')), el('div', { class: 'dbcl-fields' }, (cfg.schema.sections?.application?.fields || []).map(def => field(def))), el('button', { class: 'dbcl-button', type: 'submit' }, t('create')), button(t('cancel'), () => form.remove(), true));
    host.querySelector('.dbcl-toolbar')?.after(form); form.querySelector('input')?.focus();
  }
  function invitationClaim() {
    const form = el('form', { class: 'dbcl-invite-form', onSubmit: e => { e.preventDefault(); task(async () => { const result = await api('claim', { method: 'POST', body: values(form) }); if (result.application?.id || result.application_id || result.id) await open(result.application?.id || result.application_id || result.id); else await list(); }, 'Participant invitation claimed.'); } }, field({ name: 'token', label: 'Invitation token', required: true, type: 'password' }), el('button', { class: 'dbcl-button secondary', type: 'submit' }, t('claim')));
    return el('details', { class: 'dbcl-panel' }, el('summary', {}, t('claim')), note(t('own')), form);
  }
  function renderCase() {
    const app = state.active;
    host.append(el('div', { class: 'dbcl-toolbar' }, button('← ' + t('back'), () => task(async () => { state.active = null; await list(); }, ''), true), button(t('reload'), () => task(() => open(app.id), ''), true)), el('div', { class: 'dbcl-case-heading' }, el('div', {}, el('p', { class: 'dbcl-eyebrow' }, 'APPLICATION · ' + app.id), el('h1', {}, app.product || t('workspace')), el('p', { class: 'dbcl-muted' }, [app.branch, 'Group ' + (app.group_id || ''), 'Version ' + app.version].filter(Boolean).join(' · '))), badge(app.stage || app.status || 'DRAFT')));
    const tabs = ['overview', 'parties', 'operations', 'finance', 'documents', 'signatures', 'notifications'];
    if (isStaff()) tabs.push('audit');
    const nav = el('nav', { class: 'dbcl-tabs', 'aria-label': 'Application sections' });
    tabs.forEach(tab => nav.append(button(t(tab), () => { state.tab = tab; state.message = ''; render(); }, state.tab !== tab, { 'aria-current': state.tab === tab ? 'page' : undefined })));
    host.append(nav);
    ({ overview: renderOverview, parties: renderParties, operations: renderOperations, finance: renderFinance, documents: renderDocuments, signatures: renderSignatures, notifications: renderNotifications, audit: renderAudit }[state.tab] || renderOverview)();
  }
  function renderOverview() {
    const app = state.active;
    host.append(note(t('separate')), el('div', { class: 'dbcl-metrics' }, metric('Requested amount', money(app.requested_amount_paise)), metric('Assigned credit officer', app.assigned_id || 'Awaiting assignment'), metric('Next action', human(app.exception_state || app.exception || app.stage || 'Complete party onboarding'))));
    const timeline = el('ol', { class: 'dbcl-timeline' });
    Object.entries(state.gates).forEach(([stage, gate]) => {
      if (typeof gate !== 'object' || gate === null) return;
      timeline.append(el('li', { class: gate.passed ? 'passed' : '' }, el('div', {}, el('strong', {}, human(stage)), badge(gate.passed ? 'PASS' : 'PENDING')), (gate.blockers || []).length ? el('ul', {}, gate.blockers.map(b => el('li', {}, typeof b === 'string' ? b : label(b.message || b)))) : el('small', {}, 'Prerequisites satisfied')));
    });
    host.append(panel(state.lang === 'hi' ? 'चरण और अगला कार्य' : 'Journey & outstanding actions', timeline.children.length ? timeline : empty('Complete the group profiles and original-document checklist.')));
    host.append(panel('Loan purpose', el('p', {}, app.purpose || app.loan_purpose || t('notAvailable')), note(t('own'))));
  }
  function renderParties() {
    const app = state.active;
    const roles = availableRoles();
    if (!roles.some(([r]) => r === state.role)) state.role = roles[0]?.[0] || 'applicant';
    const selector = el('div', { class: 'dbcl-role-tabs' });
    Object.entries(cfg.schema.roles || {}).forEach(([role, title]) => {
      const party = app.parties?.[role];
      const visible = roles.some(([r]) => r === role);
      selector.append(button(label(title) + (party?.user_id || party?.linked ? ' ✓' : ''), () => { state.role = role; state.providerAction = null; render(); }, state.role !== role, { disabled: !visible, title: visible ? '' : 'This participant’s private records require their own session.' }));
    });
    host.append(selector, note(t('own')));
    const role = state.role, party = app.parties?.[role];
    if (!party || !roles.some(([r]) => r === role)) { host.append(empty('Sign in as the linked participant to view this profile.')); return; }
    if (isStaff() || state.actor.party_role === 'applicant' || owns('applicant')) {
      const invites = panel('Participant invitations', el('p', { class: 'dbcl-muted' }, 'Share invitations securely. The invitee must sign in independently and satisfy mobile verification before claiming.'));
      Object.keys(cfg.schema.roles || {}).filter(r => r !== 'applicant' && !app.parties?.[r]?.user_id && !app.parties?.[r]?.linked).forEach(r => invites.append(button('Create ' + label(cfg.schema.roles[r]) + ' invitation', () => task(async () => { const result = await mutate('invite', { role: r }); const token = result.token || result.invitation_token; if (token) state.invitation = { role: r, token }; }, 'Invitation created. The token is displayed once.'))));
      if (state.invitation) invites.append(note('Invitation for ' + human(state.invitation.role) + ' (share securely; shown once): ' + state.invitation.token));
      host.append(invites);
    }
    const canEdit = owns(role) || state.actor.party_role === role || isStaff();
    const form = el('form', { onSubmit: e => { e.preventDefault(); task(async () => { const all = values(form), profile = {}, bank = {}; (cfg.schema.sections?.bank?.fields || []).forEach(def => { bank[def.name] = all[def.name]; }); ['personal', 'address'].forEach(section => (cfg.schema.sections?.[section]?.fields || []).forEach(def => { profile[def.name] = all[def.name]; })); await mutate('profile', { role, profile, bank }); }); } });
    ['personal', 'address', 'bank'].forEach(section => {
      const schema = cfg.schema.sections?.[section]; if (!schema) return;
      const defs = schema.fields || [];
      form.append(el('fieldset', { disabled: !canEdit }, el('legend', {}, label(schema.label)), el('div', { class: 'dbcl-fields' }, defs.map(def => { let value = section === 'bank' ? party.bank?.[def.name] ?? '' : party.profile?.[def.name] ?? ''; const masked = typeof value === 'string' && value.includes('•'); if (masked || (section === 'bank' && def.name === 'account_number_confirm' && party.bank?.account_number)) { const node = field({ ...def, required: false, placeholder: masked ? 'Saved ' + value + ' — enter only to replace' : 'Required only when changing account number' }, ''); node.querySelector('[name]').dataset.preserve = 'true'; return node; } return field(def, value); }))));
    });
    if (isStaff() && !owns(role)) form.append(note('Officer-assisted data entry is recorded as delegated entry. It cannot replace the participant’s consent or signature.'));
    if (canEdit) form.append(el('button', { class: 'dbcl-button', type: 'submit' }, t('save')));
    host.append(panel(label(cfg.schema.roles?.[role] || human(role)), form));
    renderConsents(party, role);
    renderUploads(party, role, canEdit);
    renderKyc(party, role, canEdit);
  }
  function renderConsents(party, role) {
    const content = panel('Purpose-specific consent', note('Accept only after reading the displayed purpose. Loan terms and mandate authorization have separate acceptance steps.'));
    Object.entries(cfg.schema.consents || {}).forEach(([purpose, text]) => {
      const record = party.consents?.[purpose];
      const own = owns(role) || state.actor.party_role === role;
      const definition = state.consentTexts[purpose] || {};
      const exact = definition.text || 'This purpose has no published consent text yet. Ask the administrator to configure it.';
      const form = el('form', { class: 'dbcl-consent', onSubmit: e => { e.preventDefault(); task(() => mutate('consent', { role, purpose, accepted: values(form).accepted, version: definition.version || '' })); } }, el('strong', {}, label(text)), el('p', {}, exact), record ? badge(record.accepted ? 'ACCEPTED' : 'DECLINED') : badge('PENDING'), field({ name: 'accepted', type: 'checkbox', label: 'I consent to this purpose' }, false), own ? el('button', { class: 'dbcl-button secondary', type: 'submit' }, 'Record my response') : el('p', { class: 'dbcl-muted' }, 'This participant must give their own response.'));
      if (!own || !definition.text || !definition.version) { form.querySelector('input').disabled = true; const submit = form.querySelector('button'); if (submit) submit.disabled = true; }
      content.append(form);
    });
    host.append(content);
  }
  function renderUploads(party, role, canEdit) {
    const content = panel('Original-document checklist', note(label(cfg.schema.capture_instruction) || t('original')));
    Object.entries(cfg.schema.documents || {}).forEach(([type, def]) => {
      const docs = Object.values(party.documents || {}).filter(d => d.type === type || d.document_type === type);
      const latest = docs[docs.length - 1];
      const row = el('details', { class: 'dbcl-document' }, el('summary', {}, el('strong', {}, label(def.label)), badge(latest?.review?.status || latest?.status || 'MISSING')));
      if (latest) row.append(el('p', { class: 'dbcl-muted' }, 'Version retained · ' + time(latest.created_at) + (latest.review?.reason ? ' · ' + latest.review.reason : '')), button('View uploaded document', () => task(() => download('files/' + encodeURIComponent(latest.file_id || latest.id), type + '.pdf'), ''), true));
      if (canEdit) {
        const form = el('form', { class: 'dbcl-upload', onSubmit: e => { e.preventDefault(); task(async () => { const file = form.querySelector('input[type=file]').files[0]; if (!file) throw new Error('Choose a clear original-document photograph.'); await upload(role, type, file, form.querySelector('[name=original_confirmed]').checked, 'upload'); }); } }, el('label', { class: 'dbcl-field' }, el('span', {}, 'Take a photo or select a clear original-document image'), el('input', { type: 'file', name: 'file', accept: 'image/jpeg,image/png,application/pdf', capture: type === 'live_photo' ? 'user' : 'environment', required: true })), field({ name: 'original_confirmed', type: 'checkbox', label: 'This is a photograph of my original document (not a screenshot or photocopy)', required: true }), el('button', { type: 'submit', class: 'dbcl-button secondary' }, latest ? 'Upload a new version' : 'Upload for review'));
        const camera = el('div', { class: 'dbcl-camera' });
        form.append(button('Use camera', () => openCamera(camera, role, type), true), camera);
        row.append(form);
      }
      content.append(row);
    });
    host.append(content);
  }
  async function upload(role, type, file, original, method) {
    if (!original) throw new Error(t('original'));
    const data = new FormData(); data.append('file', file, file.name || type + '.jpg'); data.append('role', role); data.append('type', type); data.append('original_confirmed', '1'); data.append('capture_method', method); data.append('expected_version', state.active.version);
    await api('applications/' + encodeURIComponent(state.active.id) + '/documents', { method: 'POST', body: data }); await open(state.active.id);
  }
  async function openCamera(target, role, type) {
    if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) { state.error = true; state.message = 'Camera access requires HTTPS and browser permission. You may upload a clear photograph through the approved assisted route.'; status(); return; }
    stopCamera(); target.replaceChildren();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: type === 'live_photo' ? 'user' : 'environment' } }); streams.add(stream);
      const video = el('video', { autoplay: true, playsinline: true, muted: true, 'aria-label': 'Live camera preview' }); video.srcObject = stream;
      target.append(video, note('Position the original clearly. Capture only after checking focus and visible corners.'), button('Capture & upload original', () => task(async () => { if (!video.videoWidth) throw new Error('The camera is not ready yet.'); const canvas = document.createElement('canvas'); canvas.width = video.videoWidth; canvas.height = video.videoHeight; canvas.getContext('2d').drawImage(video, 0, 0); const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.9)); if (!blob) throw new Error('The image could not be captured.'); await upload(role, type, new File([blob], type + '.jpg', { type: 'image/jpeg' }), true, 'camera'); })), button('Close camera', () => { stopCamera(); target.replaceChildren(); }, true));
    } catch (_) { target.append(note('Camera permission was denied or no camera is available. No image has been captured. Use the approved upload or assisted route.', 'warning')); }
  }
  function renderKyc(party, role, canEdit) {
    const catalog = cfg.catalog.operations || cfg.catalog;
    const operations = Object.entries(catalog).filter(([, op]) => typeof op === 'object' && op && !['esign', 'bulk'].includes(op.product) && !/^credit-report/.test(op.product || ''));
    const content = panel('Surepass identity & bank verification', note('Verification requires the participant’s KYC consent. A successful API request is not automatically a verified identity. Aadhaar OTP services are not enabled by the supplied active-product list.'));
    Object.entries(party.kyc || {}).forEach(([operation, result]) => content.append(el('div', { class: 'dbcl-ledger-row' }, el('strong', {}, human(operation)), badge(result.status || 'REVIEW_REQUIRED'), el('small', {}, result.reference || ''))));
    if (!canEdit) { host.append(content); return; }
    const form = el('form', { onSubmit: e => { e.preventDefault(); task(async () => { const data = values(form); const operation = data.operation; delete data.operation; const payload = Object.fromEntries(Object.entries(data).filter(([, v]) => v !== '')); const result = await mutate('kyc', { role, operation, payload }); state.providerAction = result.provider_action || null; }); } });
    const selector = field({ name: 'operation', label: 'Active KYC service', type: 'select', required: true, options: Object.fromEntries(operations.map(([key, op]) => [key, op.label || op.name || human(key)])) });
    const inputs = el('div', { class: 'dbcl-fields' });
    function showFields() {
      const key = selector.querySelector('select').value;
      const operation = catalog[key] || {};
      let defs = operation.fields || operation.input_fields;
      if (!Array.isArray(defs)) {
        defs = /^(bank-verification|pan-advanced|pan-advanced-v2|pan-advanced-v3|digilocker|digilocker-initialize)$/.test(key) ? [] : /bank/.test(key) ? [{ name: 'account_number', label: 'Account number', required: true }, { name: 'ifsc', label: 'IFSC', required: true }]
          : /pan|voter/.test(key) ? [{ name: /voter/.test(key) ? 'id_number' : 'pan', label: /voter/.test(key) ? 'Voter ID number' : 'PAN number', required: true }]
            : /status|download|documents/.test(key) ? [{ name: 'client_id', label: 'Provider client reference', required: true }]
              : /digilocker/.test(key) ? [{ name: 'mobile', label: 'Mobile number' }, { name: 'name', label: 'Legal name' }]
                : [{ name: 'id_number', label: 'Verification reference / identifier', required: true }];
      }
      inputs.replaceChildren(...defs.map(def => field(typeof def === 'string' ? { name: def, label: human(def) } : def)));
      if (!defs.length) inputs.append(note('This service uses this participant’s saved identity or bank details. Correct the profile before requesting verification.'));
    }
    selector.querySelector('select').addEventListener('change', showFields);
    form.append(selector, inputs, el('button', { class: 'dbcl-button secondary', type: 'submit' }, 'Run consented verification')); showFields(); content.append(form);
    if (state.providerAction?.sdk_token) { const sdk = el('div', { id: 'dbcl-digilocker-sdk' }); content.append(note('Complete the secure DigiLocker window, then confirm verification. Only the server checks the verified provider result.'), button('Load secure DigiLocker verification', () => startDigiLocker(sdk, state.providerAction, role), true), sdk, button('Confirm DigiLocker verification', () => task(() => mutate('kyc', { role, operation: 'digilocker-download', payload: { client_id: state.providerAction.reference } })), true)); }
    if (state.providerAction?.action_url) {
      try { const url = new URL(state.providerAction.action_url); if (url.protocol === 'https:') content.append(el('a', { href: url.href, target: '_blank', rel: 'noopener noreferrer', class: 'dbcl-button' }, 'Continue secure provider authorization')); } catch (_) {}
    }
    host.append(content);
  }
  function disposeSdk() {
    if (sdkGuard) { window.removeEventListener('message', sdkGuard, true); sdkGuard = null; }
    if (sdkHandle) { try { if (sdkHandle.getPopupWindow?.()) sdkHandle.cleanup?.(); } catch (_) {} sdkHandle = null; }
  }
  async function startDigiLocker(target, action, role) {
    target.replaceChildren(empty('Loading the secure DigiLocker interface…'));
    try {
      if (!sdkReady) sdkReady = new Promise((resolve, reject) => {
        if (typeof window.DigiboostSdk === 'function') { resolve(); return; }
        const script = el('script', { src: 'https://cdn.jsdelivr.net/gh/surepassio/surepass-digiboost-web-sdk@eccd4ee94dc2ddbda11042754b9cfa910784bd60/index.min.js', integrity: 'sha384-9I0RgD1w33B4urxSPbfBC4LjjxvgAA38/Y2cMEL8AL6HvOUiuoCUAIzlqzBSYjBM', crossorigin: 'anonymous' });
        script.addEventListener('load', resolve, { once: true }); script.addEventListener('error', () => { sdkReady = null; reject(new Error('The verified DigiLocker SDK could not be loaded. Check network access and try again.')); }, { once: true }); document.head.append(script);
      });
      await sdkReady;
      if (!target.isConnected) return;
      disposeSdk(); target.replaceChildren();
      const applicationId = state.active.id;
      sdkGuard = event => { if (['digilocker:complete', 'digilocker:failed'].includes(event.data?.type) && (event.origin !== 'https://digilocker-sdk.notbot.in' || event.source !== sdkHandle?.getPopupWindow?.())) event.stopImmediatePropagation(); };
      window.addEventListener('message', sdkGuard, true);
      sdkHandle = window.DigiboostSdk({ gateway: action.sdk_gateway === 'production' ? 'production' : 'sandbox', token: action.sdk_token, selector: '#dbcl-digilocker-sdk', style: { backgroundColor: '#123c4a', borderRadius: '8px', padding: '13px 18px' }, onSuccess: () => { sdkHandle = null; if (state.active?.id !== applicationId || state.role !== role) return; task(() => mutate('kyc', { role, operation: 'digilocker-download', payload: { client_id: action.reference } }), 'Provider result refreshed. Review the recorded verification status.'); }, onFailure: () => { sdkHandle = null; state.error = true; state.message = 'DigiLocker was not completed. Your identity remains unverified; use the current session or request assistance.'; status(); } });
    } catch (error) { target.replaceChildren(note(error.message, 'warning')); }
  }
  function renderOperations() {
    host.append(note(t('note')));
    renderTermSummaries();
    if (caps().includes('dbcl_assign') && state.verificationAttempts?.length) {
      const form = el('form', { onSubmit: e => { e.preventDefault(); const data = values(form); const attempt = state.verificationAttempts.find(a => a.request_id === data.request_id); if (attempt) task(() => mutate('kyc/reconcile', { ...data, role: attempt.role, operation: attempt.operation })); } },
        field({ name: 'request_id', label: 'Unresolved KYC attempt', type: 'select', required: true, options: Object.fromEntries(state.verificationAttempts.map(a => [a.request_id, human(a.role) + ' · ' + human(a.operation) + ' · ' + a.status])) }),
        field({ name: 'evidence_ref', label: 'Provider non-processing confirmation reference', required: true }),
        field({ name: 'provider_confirmed_not_processed', type: 'checkbox', required: true, label: 'The provider confirmed this attempt was not processed; a different supervisor is recording the evidence' }),
        el('button', { class: 'dbcl-button', type: 'submit' }, 'Reconcile interrupted verification'));
      host.append(panel('KYC request reconciliation', note('An unresolved request cannot be retried on a timeout alone. Record the provider evidence before allowing another billable request.'), form));
    }
    const list = el('div', { class: 'dbcl-command-list' });
    Object.entries(cfg.commands || {}).forEach(([command, spec]) => {
      const cap = spec.capability || spec.cap;
      if (cap === 'party' ? !(state.actor.party_role || availableRoles().some(([r]) => owns(r))) : cap && !caps().includes(cap)) return;
      if (['accept_terms', 'accept_mandate'].includes(command)) return;
      const form = el('form', { class: 'dbcl-command-form', onSubmit: e => { e.preventDefault(); task(() => mutate('commands', { command, input: commandValues(form, command) })); } });
      const fields = Array.isArray(spec.fields) ? spec.fields : Object.entries(spec.fields || {}).map(([name, def]) => typeof def === 'object' ? { ...def, name } : { name, label: def });
      fields.forEach(def => {
        if (['party_role', 'role', 'borrower_role'].includes(def.name) && !def.options) def = { ...def, type: 'select', options: Object.fromEntries(Object.entries(cfg.schema.roles || {}).map(([r, title]) => [r, label(title)])) };
        if (def.type === 'json' || def.type === 'object') form.append(structuredField(def, command));
        else if (def.name === 'allocations_json') form.append(allocationField(def));
        else {
          if (/_paise$/.test(def.name)) def = { ...def, type: 'money', label: label(def.label).replace(/\(.*paise.*\)/i, '(INR)').replace(/in paise|\bpaise\b/ig, 'INR') };
          if (def.name === 'annual_interest_bps') { const node = field({ ...def, label: 'Annual interest rate (%)', type: 'number', step: '0.01' }, ''); node.querySelector('input').dataset.bps = 'true'; form.append(node); }
          else form.append(commandField(def));
        }
      });
      if (spec.description) form.prepend(el('p', { class: 'dbcl-muted' }, label(spec.description)));
      form.append(el('button', { class: 'dbcl-button', type: 'submit' }, label(spec.label || human(command))));
      list.append(el('details', { class: 'dbcl-panel dbcl-command' }, el('summary', {}, label(spec.label || human(command))), form));
    });
    host.append(list.children.length ? list : panel('', empty('No operational commands are available for your role. Each group participant must accept their own terms in their own session.')));
  }
  function commandField(def) {
    const options = {};
    if (def.name === 'terms_hash') {
      Object.entries({ initial: state.active.loans?.initial, bc: state.active.loans?.bc, slt: state.active.slt }).forEach(([purpose, record]) => { if (record?.terms?.hash) options[record.terms.hash] = human(purpose) + ' · ' + (record.terms.version || 'Current accepted document version'); });
      def = { ...def, label: 'Exact document terms version' };
    }
    if (def.name === 'document_id') Object.entries(state.active.parties || {}).forEach(([role, party]) => Object.values(party.documents || {}).forEach(doc => { options[doc.id] = human(role) + ' · ' + human(doc.type) + ' · ' + doc.id.slice(0, 8); }));
    if (def.name === 'query_id') (state.active.queries || []).forEach(query => { options[query.id] = (query.description || query.customer_message || query.id).slice(0, 70) + ' · ' + human(query.status); });
    if (def.name === 'mandate_id') Object.entries(state.active.mandates || {}).forEach(([purpose, mandate]) => { if (mandate.id) options[mandate.id] = human(purpose) + ' · ' + money(mandate.amount_paise) + ' · ' + mandate.id.slice(0, 8); });
    if (def.name === 'instruction_id') {
      [state.active.loans?.initial, state.active.loans?.bc, state.active.return_collection, state.active.slt].filter(Boolean).forEach(record => {
        [...(record.payment_history || []), record.payment].filter(Boolean).forEach(payment => { options[payment.id] = human(payment.purpose || payment.ledger_kind || 'Payment') + ' · ' + money(payment.amount_paise) + ' · ' + human(payment.status) + ' · ' + payment.id.slice(0, 8); });
      });
    }
    if (Object.keys(options).length) def = { ...def, type: 'select', options };
    return field(def, def.default ?? '');
  }
  function allocationField(def) {
    const box = el('fieldset', { 'data-allocations': 'true' }, el('legend', {}, 'Borrower principal allocation (optional)'), el('p', { class: 'dbcl-muted' }, 'Enter only the actual borrowers’ allocated principal. Leave blank to allocate to the selected borrower. The total must match the loan principal.'));
    Object.entries(cfg.schema.roles || {}).forEach(([role, title]) => box.append(field({ name: 'allocation_' + role, type: 'money', label: label(title) + ' (INR)' })));
    return box;
  }
  function renderTermSummaries() {
    const app = state.active;
    const records = [['initial', app.loans?.initial], ['bc', app.loans?.bc], ['return_collection', app.return_collection], ['slt', app.slt]];
    records.filter(([, record]) => record?.terms?.text).forEach(([purpose, record]) => {
      const terms = record.terms;
      const box = panel(human(purpose) + ' — terms for your review', keyValues({ 'Legal entity': record.lender || record.recipient, 'Amount': money(record.amount_paise), 'Terms version': terms.version, 'Obligation ID': record.id }), el('pre', { class: 'dbcl-terms' }, terms.text));
      const role = state.actor.party_role;
      if (role) {
        const accepted = terms.accepted?.[role];
        box.append(badge(accepted?.accepted ? 'ACCEPTED' : 'ACCEPTANCE_PENDING'));
        const form = el('form', { onSubmit: e => { e.preventDefault(); if (!values(form).confirmed) return; task(() => mutate('commands', { command: 'accept_terms', input: { purpose, terms_version: terms.version, confirmed: true } })); } }, field({ name: 'confirmed', type: 'checkbox', required: true, label: 'I have read and accept this exact version of the terms for my own role' }), el('button', { class: 'dbcl-button', type: 'submit' }, 'Accept these terms as ' + label(cfg.schema.roles?.[role] || role)));
        box.append(form);
      }
      host.append(box);
    });
    Object.entries(app.mandates || {}).forEach(([purpose, mandate]) => {
      if (mandate.payer_role !== state.actor.party_role) return;
      const box = panel(human(purpose) + ' — separate mandate authorization', keyValues({ 'Mandate ID': mandate.id, 'Linked obligation': mandate.obligation_id, 'Beneficiary reference': mandate.beneficiary_ref, 'Amount / ceiling': money(mandate.amount_paise), 'Frequency': human(mandate.frequency), 'Valid from': time(mandate.valid_from), 'Valid until': time(mandate.valid_until) }), badge(mandate.status));
      if (mandate.status === 'PENDING' && !mandate.authorization?.accepted) {
        const form = el('form', { onSubmit: e => { e.preventDefault(); if (!values(form).confirmed) return; task(() => mutate('commands', { command: 'accept_mandate', input: { purpose, mandate_id: mandate.id, confirmed: true } })); } }, field({ name: 'confirmed', type: 'checkbox', required: true, label: 'I separately authorize this stated purpose, beneficiary, amount, frequency and validity' }), el('button', { class: 'dbcl-button', type: 'submit' }, 'Authorize this mandate'));
        box.append(form);
      }
      host.append(box);
    });
    if (caps().includes('dbcl_assign')) {
      const form = el('form', { class: 'dbcl-inline-form', onSubmit: e => { e.preventDefault(); task(() => mutate('staff', values(form))); } }, field({ name: 'user_id', type: 'number', label: 'Eligible staff WordPress user ID', required: true, min: 1 }), field({ name: 'staff_role', type: 'select', label: 'Case assignment', required: true, options: { verification: 'Verification officer', operations: 'Operations officer', finance_maker: 'Finance maker', finance_checker: 'Finance checker' } }), el('button', { class: 'dbcl-button', type: 'submit' }, 'Assign staff member'));
      host.append(panel('Case team & policy', form, button('Apply current independently approved policy', () => task(() => mutate('policy', {})), true), note('Applying a policy revision invalidates affected checks and requires fresh participant acceptance.')));
    }
  }
  function structuredField(def, command) {
    // Business object fields are edited through labelled controls, not raw request JSON.
    const box = el('fieldset', { class: 'dbcl-structured', 'data-object': def.name }, el('legend', {}, label(def.label || human(def.name))));
    const names = /allocation/.test(def.name) ? ['applicant', 'co_applicant'] : /checklist/.test(def.name) ? ['documents_complete', 'terms_explained', 'obligations_explained', 'questions_answered'] : /terms/.test(def.name) ? ['version', 'text', 'lender', 'amount_paise', 'annual_rate_percent', 'tenure_months', 'processing_fee_paise', 'repayment_frequency', 'first_due_date'] : ['reference', 'description'];
    const custom = Array.isArray(def.fields) ? def.fields : names.map(name => ({ name, label: human(name), type: /_paise$/.test(name) ? 'money' : /text|description/.test(name) ? 'textarea' : /complete|explained|answered/.test(name) ? 'checkbox' : 'text' }));
    custom.forEach(child => { const node = field(child); node.querySelector('[name]').dataset.nested = def.name; box.append(node); });
    return box;
  }
  function commandValues(form) {
    const data = values(form);
    const allocation = form.querySelector('[data-allocations]');
    if (allocation) { const totals = {}; allocation.querySelectorAll('input').forEach(input => { if (input.value !== '') totals[input.name.replace(/^allocation_/, '')] = Math.round(Number(input.value) * 100); delete data[input.name]; }); data.allocations_json = Object.keys(totals).length ? JSON.stringify(totals) : ''; }
    form.querySelectorAll('[data-object]').forEach(box => {
      const key = box.dataset.object; data[key] = {};
      box.querySelectorAll('[data-nested]').forEach(input => { data[key][input.name] = data[input.name]; delete data[input.name]; });
    });
    return data;
  }
  function renderFinance() {
    const app = state.active;
    const purposePayment = (record, purpose) => [...(record?.payment_history || []), record?.payment].filter(p => p?.purpose === purpose).at(-1);
    host.append(note(t('separate')), note(t('note')));
    const items = [
      ['Initial loan disbursement', app.loans?.initial?.amount_paise || 1000000, app.loans?.initial?.lender, app.loans?.initial?.id, purposePayment(app.loans?.initial, 'initial_disbursement'), app.loans?.initial?.status],
      ['Separate return collection', 1000000, app.return_collection?.recipient, app.return_collection?.id, app.return_collection?.payment, app.return_collection?.status],
      ['Final BC loan disbursement', app.loans?.bc?.net_disbursement_paise ?? app.loans?.bc?.amount_paise ?? 0, app.loans?.bc?.lender, app.loans?.bc?.id, app.loans?.bc?.payment, app.loans?.bc?.status],
      ['One-time SLT contribution', 2500000, 'Shubh Labh Trust', app.slt?.id, app.slt?.payment, app.slt?.status]
    ];
    const grid = el('div', { class: 'dbcl-finance-grid' });
    items.forEach(([title, amount, recipient, id, payment, loanStatus]) => {
      const card = panel(title, el('strong', { class: 'dbcl-amount' }, money(amount)), el('p', {}, recipient || 'Beneficiary / lender not configured'), el('small', { class: 'dbcl-reference' }, id || ''), badge(payment?.status || loanStatus || 'NOT_STARTED'));
      if (payment) card.append(keyValues({ 'Request reference': payment.id || payment.idempotency_key, 'Maker': payment.maker_id, 'Checker': payment.checker_id, 'Provider / bank reference': payment.settlement?.reference || payment.reference || payment.provider_reference, 'Evidence source': payment.settlement?.source || payment.source || 'OFFICER_REPORTED', 'Settlement': payment.settlement_status || payment.status, 'Recorded at': payment.updated_at || payment.created_at }));
      grid.append(card);
    });
    host.append(grid);
    const loan = app.loans?.initial || {};
    const repaid = (loan.settlements || []).filter(s => s.ledger_kind === 'repayment').reduce((sum, s) => sum + Number(s.amount_paise || 0), 0) - (loan.reversals || []).filter(s => s.ledger_kind === 'repayment').reduce((sum, s) => sum + Number(s.amount_paise || 0), 0);
    const repayment = purposePayment(loan, 'initial_repayment');
    host.append(panel('Initial lender repayment & closure', note('Only lender repayment and lender-confirmed closure affect the original loan. The separate return collection and SLT contribution do not reduce this balance.'), keyValues({ 'Recorded principal remaining (charges excluded)': money(Math.max(0, Number(loan.amount_paise || 1000000) - repaid)), 'Lender-confirmed balance': loan.closure?.lender_balance_paise != null ? money(loan.closure.lender_balance_paise) : 'Awaiting lender confirmation', 'Repayment status': loan.repayment_status || repayment?.status || 'NOT_REPAID', 'Repayment bank reference': repayment?.settlement?.reference || 'Not recorded', 'Closure status': loan.status === 'CLOSED' ? 'CLOSED' : 'NOT_CONFIRMED', 'Closure reference': loan.closure?.reference || 'Not recorded' })));
    const mandates = panel('Purpose-specific mandates');
    Object.entries(app.mandates || {}).forEach(([purpose, mandate]) => mandates.append(el('article', { class: 'dbcl-ledger-row' }, el('strong', {}, human(purpose)), badge(mandate.status || 'PENDING'), keyValues({ 'Obligation': mandate.obligation_id, 'Beneficiary': mandate.beneficiary, 'Amount / ceiling': money(mandate.amount_paise), 'Frequency': mandate.frequency, 'UMRN / reference': mandate.umrn || mandate.reference, 'Authorization source': mandate.source, 'Valid until': mandate.end_date || mandate.valid_until }))));
    host.append(mandates);
  }
  function keyValues(data) { return el('dl', { class: 'dbcl-keyvalues' }, Object.entries(data).filter(([, value]) => value !== undefined && value !== null && value !== '').map(([key, value]) => [el('dt', {}, key), el('dd', {}, typeof value === 'object' ? human(value.status || value.reference || 'Recorded') : String(value))])); }
  function renderDocuments() {
    const content = panel('Versioned loan & onboarding documents', note('Draft templates are previews until approved lender wording, terms and signer requirements have been configured. A specimen signature is not an eSign.'));
    const form = el('form', { class: 'dbcl-inline-form', onSubmit: e => { e.preventDefault(); task(() => mutate('generate', values(form))); } }, field({ name: 'type', label: 'Document type', type: 'select', required: true, options: { application: 'Loan application', sanction: 'Sanction letter', kfs: 'Key Facts Statement & repayment schedule', agreement: 'Loan agreement', dpn: 'DPN', indemnity: 'Indemnity', membership: 'SLT membership', receipt: 'Settled transaction receipt', db_kit: 'DB documentation kit' } }), field({ name: 'loan', label: 'Linked loan', type: 'select', required: true, options: { initial: 'Initial loan', bc: 'Final BC loan' } }), field({ name: 'purpose', label: 'Receipt purpose (for receipts only)', type: 'select', options: { initial_disbursement: 'Initial disbursement', return_collection: 'Separate return collection', initial_repayment: 'Initial lender repayment', bc_disbursement: 'Final BC disbursement', slt_contribution: 'One-time SLT contribution' } }), commandField({ name: 'instruction_id', label: 'Settled instruction (for receipts only)', required: false }), el('button', { class: 'dbcl-button', type: 'submit' }, 'Generate immutable version'));
    if (caps().includes('dbcl_operate') || caps().includes('dbcl_review')) content.append(form);
    if (!state.snapshots.length) content.append(empty('No generated document versions yet.'));
    state.snapshots.forEach(s => content.append(el('div', { class: 'dbcl-document-row' }, el('div', {}, el('strong', {}, human(s.type || s.document_type)), el('small', {}, 'Template ' + (s.template_version || 'draft') + ' · ' + time(s.created_at)), el('code', {}, s.sha256 || s.hash || '')), button('View / print', () => task(() => download('applications/' + encodeURIComponent(state.active.id) + '/snapshots/' + encodeURIComponent(s.id), (s.type || 'loan-document') + '.html', true), ''), true))));
    host.append(content);
  }
  function renderSignatures() {
    host.append(panel('Document execution & signature centre', note('A signature specimen is not eSign. Each named signer starts their own consented provider session. Provider completion, signed-document evidence and the current terms version determine execution status.')));
    const sessions = el('div', {}, empty(t('loading')));
    host.append(sessions);
    loadSignatureSessions(sessions);
    if (caps().includes('dbcl_operate')) {
      const coordinates = el('div', { class: 'dbcl-coordinate-list' });
      const addPosition = () => { const row = el('div', { class: 'dbcl-coordinate' }, field({ name: 'page', type: 'number', label: 'PDF page number', required: true, min: 1, step: 1 }, 1), field({ name: 'x', type: 'number', label: 'Approved X coordinate', required: true, min: 0, step: 1 }, 100), field({ name: 'y', type: 'number', label: 'Approved Y coordinate', required: true, min: 0, step: 1 }, 200)); row.append(button('Remove position', () => row.remove(), true)); coordinates.append(row); };
      addPosition();
      const form = el('form', { onSubmit: e => { e.preventDefault(); task(async () => {
        const data = new FormData(form); const positions = {};
        coordinates.querySelectorAll('.dbcl-coordinate').forEach(row => { const page = row.querySelector('[name=page]').value; if (!positions[page]) positions[page] = []; positions[page].push({ x: Number(row.querySelector('[name=x]').value), y: Number(row.querySelector('[name=y]').value) }); });
        if (!Object.keys(positions).length) throw new Error('Add at least one approved signature position.');
        ['page', 'x', 'y'].forEach(key => data.delete(key)); data.set('positions', JSON.stringify(positions)); data.set('expected_version', state.active.version); data.set('approved', form.querySelector('[name=approved]').checked ? 'true' : 'false');
        await api('applications/' + encodeURIComponent(state.active.id) + '/esign/documents', { method: 'POST', body: data }); await open(state.active.id);
      }); } }, field({ name: 'purpose', label: 'Document obligation', type: 'select', required: true, options: { initial: 'Initial loan', bc: 'Final BC loan', slt: 'SLT membership' } }), field({ name: 'party_role', label: 'Actual signer', type: 'select', required: true, options: Object.fromEntries(Object.entries(cfg.schema.roles || {}).map(([role, title]) => [role, label(title)])) }), field({ name: 'approval_ref', label: 'Approved PDF / document-control reference', required: true }), el('label', { class: 'dbcl-field' }, el('span', {}, 'Approved, final PDF to execute *'), el('input', { type: 'file', name: 'file', accept: 'application/pdf', required: true })), field({ name: 'approved', type: 'checkbox', required: true, label: 'This is the approved PDF for the current accepted terms and named signer' }), el('h3', {}, 'Approved signature positions'), coordinates, button('Add another position', addPosition, true), el('button', { class: 'dbcl-button', type: 'submit' }, 'Register this PDF for execution'));
      host.append(panel('Prepare an approved PDF for signing', note('Browser-print HTML is a preview. Upload the actual approved PDF and approved page coordinates. This step does not sign it.'), form));
    }
  }
  async function loadSignatureSessions(target) {
    try {
      const result = await api('applications/' + encodeURIComponent(state.active.id) + '/esign');
      target.replaceChildren();
      const sessions = Object.values(result.sessions || []);
      if (!sessions.length) target.append(panel('', empty('No signature sessions have been prepared for the current terms.')));
      sessions.forEach(session => {
        const card = panel(human(session.purpose) + ' · ' + label(cfg.schema.roles?.[session.party_role] || session.party_role), badge(session.status), keyValues({ 'Prepared': time(session.created_at), 'Session reference': session.id, 'Approved PDF SHA-256': session.source_sha256, 'Current action': session.reason || 'Review the provider session status' }));
        if (session.can_review_source) {
          const review = el('form', { onSubmit: e => { e.preventDefault(); task(async () => { await api('applications/' + encodeURIComponent(state.active.id) + '/esign', { method: 'POST', body: { action: 'review_source', session_id: session.id, expected_version: state.active.version, ...values(review) } }); await open(state.active.id); }); } }, field({ name: 'approval_ref', label: 'Source-review evidence reference', required: true }), field({ name: 'review_confirmed', label: 'Policy-approved manual review completed (a previously infected file still requires a clean scanner result)', type: 'checkbox' }), el('button', { class: 'dbcl-button secondary', type: 'submit' }, 'Recheck source PDF'));
          card.append(review);
        }
        if (session.party_role === state.actor.party_role && session.can_begin) card.append(button('Begin my secure signature session', () => task(async () => { const response = await mutate('esign', { action: 'begin', session_id: session.id }); state.providerAction = response.provider_action || null; if (state.providerAction?.action_url) { const url = new URL(state.providerAction.action_url); if (url.protocol === 'https:') { const popup = window.open(url.href, '_blank', 'noopener,noreferrer'); if (!popup) state.message = 'The provider session is ready. Use the secure authorization link displayed below.'; } } })));
        if (session.action_url && session.party_role === state.actor.party_role) { try { const url = new URL(session.action_url); if (url.protocol === 'https:') card.append(el('a', { href: url.href, target: '_blank', rel: 'noopener noreferrer', class: 'dbcl-button' }, 'Continue my secure signature session')); } catch (_) {} }
        if (session.can_check) card.append(button('Check provider completion', () => task(async () => { const response = await mutate('esign', { action: 'check', session_id: session.id }); state.providerAction = response.provider_action || null; }), true));
        if (session.signed_document_id) card.append(button('Download executed document', () => task(() => download('files/' + encodeURIComponent(session.signed_document_id), 'executed-document.pdf'), ''), true));
        target.append(card);
      });
      if (state.providerAction?.action_url) { try { const url = new URL(state.providerAction.action_url); if (url.protocol === 'https:') target.prepend(el('a', { href: url.href, target: '_blank', rel: 'noopener noreferrer', class: 'dbcl-button' }, 'Continue secure provider authorization')); } catch (_) {} }
    } catch (error) { target.replaceChildren(panel('', note(error.message, 'warning'))); }
  }
  async function download(path, filename, openWindow = false) {
    const blob = await api(path, { blob: true });
    const url = URL.createObjectURL(blob);
    if (openWindow) { const popup = window.open(url, '_blank', 'noopener,noreferrer'); if (!popup) { const a = el('a', { href: url, download: filename }, 'Download'); document.body.append(a); a.click(); a.remove(); } }
    else { const a = el('a', { href: url, download: filename }); document.body.append(a); a.click(); a.remove(); }
    window.setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  function renderNotifications() {
    const box = panel('Application notifications & next actions', note('In-app notices and external delivery are tracked separately. Delivery is not assumed from creating a notice.'));
    const target = el('div', {}, empty(t('loading'))); box.append(target); host.append(box);
    api('applications/' + encodeURIComponent(state.active.id) + '/notifications').then(result => {
      const rows = Object.values(result.notices || result.notifications || []); target.replaceChildren();
      if (!rows.length) target.append(empty('No notifications for this application.'));
      rows.forEach(notice => { const row = el('article', { class: 'dbcl-audit-row' }, el('strong', {}, notice.title || human(notice.type || 'Notification')), el('p', {}, notice.message || notice.body || ''), el('small', {}, time(notice.created_at || notice.at)), badge(notice.external_delivery_state || notice.delivery_status || notice.status || 'IN_APP'));
        if (!notice.read_at && notice.id) row.append(button('Mark as read', () => task(async () => { await api('notifications/' + encodeURIComponent(notice.id) + '/read', { method: 'POST', body: { application_id: state.active.id, expected_version: state.active.version } }); await open(state.active.id); }), true)); target.append(row); });
    }).catch(error => target.replaceChildren(note(error.message, 'warning')));
  }
  function renderAudit() {
    const box = panel('Append-only audit trail', el('p', { class: 'dbcl-muted' }, 'Contains action metadata and integrity hashes; identity documents and secret values are excluded.'));
    const target = el('div', {}, empty(t('loading'))); box.append(target); host.append(box);
    api('applications/' + encodeURIComponent(state.active.id) + '/audit').then(result => {
      const rows = Array.isArray(result) ? result : result.events || result.audit || [];
      target.replaceChildren();
      if (!rows.length) target.append(empty('No audit events available.'));
      rows.forEach(row => target.append(el('article', { class: 'dbcl-audit-row' }, el('strong', {}, human(row.event_type || row.type)), el('small', {}, time(row.created_at) + ' · Actor ' + row.actor_id), el('code', {}, row.hash || ''))));
    }).catch(error => target.replaceChildren(note(error.message, 'warning')));
  }
  const settingDefinitions = [
    { name: 'lender_name', label: 'Lender legal name' }, { name: 'lender_address', label: 'Lender registered address', type: 'textarea' }, { name: 'grievance_contact', label: 'Grievance officer and support contact', type: 'textarea' },
    { name: 'bc_partner', label: 'BC partner legal name' }, { name: 'template_version', label: 'Approved template / policy version' }, { name: 'approved_terms_text', label: 'Approved lender terms', type: 'textarea' }, { name: 'terms_approved', label: 'Lender terms have been approved for this product', type: 'checkbox' },
    { name: 'return_recipient', label: 'Approved ₹10,000 return recipient legal name' }, { name: 'return_purpose', label: 'Approved return collection purpose', type: 'textarea' }, { name: 'require_initial_closure', label: 'Require lender-confirmed initial-loan closure before final BC disbursement', type: 'checkbox' },
    { name: 'slt_terms_text', label: 'Approved SLT membership, contribution, cancellation and refund terms', type: 'textarea' }, { name: 'slt_due_date', label: 'Authorized SLT collection due date', type: 'date' }, { name: 'slt_notice_hours', label: 'Required pre-debit notice period (hours)', type: 'number', min: 0 },
    { name: 'sla_hours', label: 'Default task escalation target (hours)', type: 'number', min: 1 }, { name: 'notifications_enabled', label: 'Enable configured external notification delivery adapter', type: 'checkbox' },
    { name: 'require_staff_mfa', label: 'Require verified MFA for staff actions (authentication bridge required)', type: 'checkbox' }, { name: 'financial_operations_enabled', label: 'Enable evidence-backed finance workflow after product approval (does not enable bank transfers)', type: 'checkbox' },
    { name: 'allow_unscanned_manual_review', label: 'Permit policy-approved manual review before malware scanning (otherwise uploads remain pending)', type: 'checkbox' }, { name: 'require_bc_mandate', label: 'Require a separate final BC loan repayment mandate', type: 'checkbox' },
    { name: 'surepass_environment', label: 'Surepass environment', type: 'select', options: { sandbox: 'Sandbox', production: 'Production' } }
  ];
  function renderApproval() {
    const review = state.settingsReview.settings || state.settingsReview;
    const details = el('details', { class: 'dbcl-panel' }, el('summary', {}, 'Financial policy review — revision ' + (review.revision || 0)), keyValues({ 'Prepared by': review.changed_by, 'Prepared at': time(review.changed_at), 'Approved revision': review.approved_revision || 'Not approved', 'Approved by': review.approved_by || 'Not approved', 'Financial workflow requested': review.financial_operations_enabled ? 'Enabled after approval' : 'Disabled' }));
    details.append(keyValues(Object.fromEntries(settingDefinitions.filter(def => !['approved_terms_text', 'slt_terms_text'].includes(def.name)).map(def => [label(def.label), typeof review[def.name] === 'boolean' ? (review[def.name] ? 'Yes' : 'No') : review[def.name] || 'Not configured']))));
    ['approved_terms_text', 'slt_terms_text'].forEach(key => { if (review[key]) details.append(el('h3', {}, human(key)), el('pre', { class: 'dbcl-terms' }, review[key])); });
    Object.entries(review.consent_texts || {}).forEach(([purpose, definition]) => details.append(el('h3', {}, human(purpose) + ' consent · ' + (definition.version || 'No version')), el('pre', { class: 'dbcl-terms' }, definition.text || 'Not published')));
    Object.entries(review.document_templates || {}).forEach(([type, definition]) => details.append(el('h3', {}, human(type) + ' · ' + (definition.version || 'No version') + (definition.approved ? ' · Approved wording' : ' · Draft')), el('pre', { class: 'dbcl-terms' }, definition.text || 'No wording configured'), el('p', {}, 'Required signers: ' + (review.signer_roles?.[type] || []).map(human).join(', '))));
    details.append(note('Approval applies to this exact revision. A different finance checker must approve the configuration, and a supervisor must explicitly apply it to existing cases.'));
    if (Number(review.changed_by) !== Number(cfg.user.id) && Number(review.approved_revision) !== Number(review.revision)) details.append(button('Approve this reviewed policy revision', () => task(async () => { await api('settings/approve', { method: 'POST', body: { revision: review.revision } }); state.settingsReview = await api('settings/review'); })));
    host.append(details);
  }
  function consentSettings() {
    const box = el('details', { class: 'dbcl-advanced', 'data-consent-settings': 'true' }, el('summary', {}, 'Purpose-specific consent text and versions'), note('Publish the exact text each participant will read. Empty definitions remain unavailable. Do not copy a consent from another purpose.'));
    Object.entries(cfg.schema.consents || {}).forEach(([purpose, title]) => {
      const definition = state.settings.consent_texts?.[purpose] || {};
      box.append(el('fieldset', { 'data-consent-purpose': purpose }, el('legend', {}, label(title)), field({ name: 'consent_' + purpose + '_version', label: 'Published version' }, definition.version || ''), field({ name: 'consent_' + purpose + '_text', label: 'Exact text presented to the party', type: 'textarea' }, definition.text || '')));
    });
    return box;
  }
  function templateSettings() {
    const box = el('details', { class: 'dbcl-advanced', 'data-template-settings': 'true' }, el('summary', {}, 'Document wording and signer matrix'), note('Configure approved wording for each document. Existing executed snapshots are retained. A new version requires fresh applicable acceptance and signatures.'));
    ['application', 'sanction', 'kfs', 'agreement', 'dpn', 'indemnity', 'membership', 'receipt', 'db_kit'].forEach(type => {
      const template = state.settings.document_templates?.[type] || {};
      const signers = state.settings.signer_roles?.[type] || [];
      const group = el('fieldset', { 'data-template-type': type }, el('legend', {}, human(type)), field({ name: 'template_' + type + '_version', label: 'Template version' }, template.version || ''), field({ name: 'template_' + type + '_text', label: 'Approved document wording', type: 'textarea' }, template.text || ''), field({ name: 'template_' + type + '_approved', label: 'This document wording is approved', type: 'checkbox' }, !!template.approved));
      Object.entries(cfg.schema.roles || {}).forEach(([role, title]) => group.append(field({ name: 'signer_' + type + '_' + role, type: 'checkbox', label: 'Required signer: ' + label(title) }, signers.includes(role))));
      box.append(group);
    });
    return box;
  }
  function settingsValues(form) {
    const data = values(form); data.consent_texts = {}; data.document_templates = {}; data.signer_roles = {};
    form.querySelectorAll('[data-consent-purpose]').forEach(box => { const purpose = box.dataset.consentPurpose; const version = 'consent_' + purpose + '_version', text = 'consent_' + purpose + '_text'; data.consent_texts[purpose] = { version: data[version], text: data[text] }; delete data[version]; delete data[text]; });
    form.querySelectorAll('[data-template-type]').forEach(box => { const type = box.dataset.templateType; data.document_templates[type] = {}; ['version', 'text', 'approved'].forEach(key => { const fieldName = 'template_' + type + '_' + key; data.document_templates[type][key] = data[fieldName]; delete data[fieldName]; }); data.signer_roles[type] = []; Object.keys(cfg.schema.roles || {}).forEach(role => { const fieldName = 'signer_' + type + '_' + role; if (data[fieldName]) data.signer_roles[type].push(role); delete data[fieldName]; }); });
    return data;
  }
  function renderSettings() {
    host.append(el('div', { class: 'dbcl-toolbar' }, el('h1', {}, t('settings')), el('a', { href: cfg.workspaceUrl, class: 'dbcl-button secondary' }, t('workspace'))), note('Configuration administrators do not automatically receive finance approval permissions. Keep financial workflow disabled until the lender, beneficiary, legal terms and provider arrangements are approved.', 'warning'));
    if (!state.settings) { host.append(empty(t('loading'))); return; }
    const form = el('form', { onSubmit: e => { e.preventDefault(); task(async () => { const result = await api('settings', { method: 'POST', body: { expected_revision: state.settings.revision || 0, settings: settingsValues(form) } }); state.settings = result.settings || result; }); } }, el('div', { class: 'dbcl-fields' }, settingDefinitions.map(def => field(def, state.settings[def.name] ?? (def.type === 'checkbox' ? false : '')))));
    const map = field({ name: 'surepass_mappings', label: 'Confirmed Surepass endpoint mappings (integration administrator)', type: 'textarea', help: 'Use only confirmed paths, field mappings and explicit verification verdicts. The API token is configured server-side as DBCL_SUREPASS_TOKEN and is never displayed here.' }, JSON.stringify(state.settings.surepass_mappings || {}, null, 2));
    map.querySelector('textarea').dataset.json = 'true'; map.querySelector('textarea').rows = 14; map.querySelector('textarea').spellcheck = false;
    form.append(consentSettings(), templateSettings(), el('details', { class: 'dbcl-advanced' }, el('summary', {}, 'Advanced Surepass API mapping'), map), el('button', { class: 'dbcl-button', type: 'submit' }, 'Save versioned configuration'));
    host.append(panel('Product, policy & integration settings', form), panel('Integration readiness', note('Surepass calls use the configured active products and server-side credentials. AU Bank eNACH, payouts, BC submission, mobile OTP and eSign require their respective confirmed adapters. Screens do not simulate provider success.')));
  }
  window.addEventListener('pagehide', () => { stopCamera(); disposeSdk(); });
  render();
  task(async () => {
    if (cfg.user.capabilities?.includes('dbcl_finance_check')) { try { state.settingsReview = await api('settings/review'); } catch (_) { state.settingsReview = null; } }
    if (state.view === 'settings') { const result = await api('settings'); state.settings = result.settings || result; }
    else { await list(); const token = new URL(window.location.href).searchParams.get('dbcl_invite'); if (token) { state.message = 'An invitation was supplied. Claim it using your own signed-in account.'; } }
  }, '');
})();
