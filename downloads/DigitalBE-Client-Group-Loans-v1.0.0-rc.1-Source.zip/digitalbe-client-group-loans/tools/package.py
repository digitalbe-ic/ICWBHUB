#!/usr/bin/env python3
"""Build installable and source packages, excluding all runtime/customer data."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib
import re

root = Path(__file__).resolve().parents[1]
output = root.parent / 'dist'
output.mkdir(exist_ok=True)
header = (root / 'digitalbe-client-group-loans.php').read_text()
version = re.search(r'\* Version:\s*(\S+)', header).group(1)
installed = {'includes', 'assets', 'config', 'docs'}
top_files = {'digitalbe-client-group-loans.php', 'uninstall.php', 'README.md', 'readme.txt', 'LICENSE'}
manifest = []
for flavor in ['Install', 'Source']:
    target = output / f'DigitalBE-Client-Group-Loans-v{version}-{flavor}.zip'
    count = 0
    with ZipFile(target, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for source in sorted(root.rglob('*')):
            if source.is_symlink():
                raise SystemExit(f'Packaging refuses symbolic links: {source.name}')
            if not source.is_file():
                continue
            relative = source.relative_to(root)
            if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
                continue
            if flavor == 'Install' and relative.parts[0] not in installed and str(relative) not in top_files:
                continue
            if source.suffix in {'.pyc', '.log', '.sql', '.enc', '.deb'}:
                raise SystemExit(f'Unexpected generated data inside plugin: {relative}')
            info = ZipInfo(str(Path(root.name) / relative), date_time=(2026, 10, 27, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            executable = flavor == 'Source' and relative.parts[0] == 'tools' and source.suffix in {'.sh', '.py'}
            info.external_attr = (0o100755 if executable else 0o100644) << 16
            archive.writestr(info, source.read_bytes())
            count += 1
    with ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise SystemExit('Archive CRC check failed.')
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    manifest.append(f'{digest}  {target.name}\n')
    print(f'{target}: {count} files, {target.stat().st_size} bytes, SHA-256 {digest}')
(output / 'SHA256SUMS.txt').write_text(''.join(manifest))
