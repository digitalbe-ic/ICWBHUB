#!/usr/bin/env node
/* DOM-level UI smoke against the real local WordPress REST API. No browser rendering claim. */
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require(process.env.DBCL_JSDOM_MODULE || '/workspace/.runtime/ui-tests/node_modules/jsdom');
if (process.env.DBCL_TEST_ALLOW !== '1') throw new Error('Use a disposable local WordPress test database only.');
const base = process.env.DBCL_HTTP_BASE || 'http://127.0.0.1:8087';
if (!['127.0.0.1', 'localhost'].includes(new URL(base).hostname)) throw new Error('Loopback test instance required.');
let assertions = 0;
function check(okay, label) { assertions++; if (!okay) throw new Error(label); }
async function waitFor(condition, label) { const deadline = Date.now() + 10000; while (!condition()) { if (Date.now() > deadline) throw new Error('Timed out: ' + label); await new Promise(resolve => setTimeout(resolve, 40)); } }
const cookieMap = new Map();
function takeCookies(response) { for (const value of response.headers.getSetCookie()) { const pair = value.split(';', 1)[0]; const split = pair.indexOf('='); cookieMap.set(pair.slice(0, split), pair.slice(split + 1)); } }
function cookies() { return [...cookieMap].map(([key, value]) => key + '=' + value).join('; '); }
function button(document, title) { const found = [...document.querySelectorAll('button')].find(node => node.textContent.trim() === title); if (!found) throw new Error('Button missing: ' + title); return found; }
(async () => {
  const loginPage = await fetch(base + '/wp-login.php'); takeCookies(loginPage);
  const password = fs.readFileSync(process.env.DBCL_TEST_PASSWORD_FILE || '/workspace/.runtime/test-admin-password', 'utf8').trim();
  const logged = await fetch(base + '/wp-login.php', { method: 'POST', redirect: 'manual', headers: { Cookie: cookies(), 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ log: process.env.DBCL_TEST_USERNAME || 'dbcl_admin', pwd: password, 'wp-submit': 'Log In', testcookie: '1' }) });
  takeCookies(logged);
  check([...cookieMap.keys()].some(key => key.startsWith('wordpress_logged_in_')), 'WordPress login succeeds');
  const admin = await fetch(base + '/wp-admin/admin.php?page=dbcl-workspace', { headers: { Cookie: cookies() } });
  const html = await admin.text();
  const cfg = JSON.parse(html.match(/var DBCL = (\{[^\n]+\});/)[1]);
  const errors = [];
  const console = new VirtualConsole(); console.on('jsdomError', error => errors.push(error.message));
  const dom = new JSDOM('<div id="dbcl-app" data-view="workspace"></div>', { url: base + '/wp-admin/admin.php?page=dbcl-workspace', runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: console });
  const { window } = dom;
  window.DBCL = cfg;
  const pendingRequests = new Set();
  window.fetch = async (url, opts = {}) => {
    const promise = fetch(url, { ...opts, headers: { ...opts.headers, Cookie: cookies() } }).then(async response => new Response(await response.arrayBuffer(), { status: response.status, headers: response.headers }));
    pendingRequests.add(promise);
    try { return await promise; } finally { pendingRequests.delete(promise); }
  };
  window.eval(fs.readFileSync(path.join(__dirname, '../assets/app.js'), 'utf8'));
  const doc = window.document;
  await waitFor(() => doc.querySelector('#dbcl-case-list') && [...doc.querySelectorAll('button')].some(b => b.textContent.trim() === 'Start an application' && !b.disabled), 'initial queue');
  check(doc.querySelector('h1').textContent === 'Client & Group Loans', 'Workspace renders application queue');
  check(doc.querySelector('select[aria-label="Language / भाषा"]'), 'Language selector is labelled');
  button(doc, 'Start an application').click();
  const form = doc.querySelector('#dbcl-create');
  check(!!form && form.querySelectorAll('label').length === 4, 'Application form uses configured labelled fields');
  for (const [name, value] of Object.entries({ product: 'Synthetic UI Group Loan', branch: 'UI-TEST', requested_amount_paise: '250000', purpose: 'Synthetic DOM UI smoke' })) form.querySelector('[name="' + name + '"]').value = value;
  form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => doc.querySelector('.dbcl-case-heading') && [...doc.querySelectorAll('button')].some(b => b.textContent.trim() === 'Group & documents' && !b.disabled), 'application created from UI');
  check(doc.querySelector('h1').textContent === 'Synthetic UI Group Loan', 'UI creates real application and opens workspace');
  check(doc.body.textContent.includes('A return collection does not repay the initial lender.'), 'Distinct financial obligations explained in customer overview');
  check(doc.querySelectorAll('.dbcl-timeline li').length > 10, 'Server-evaluated blockers are visible in journey');
  button(doc, 'Group & documents').click();
  check(doc.body.textContent.includes('Photograph the original document'), 'Original-document capture guidance visible');
  check(doc.querySelectorAll('.dbcl-role-tabs button:disabled').length === 3, 'Applicant cannot open other parties private forms');
  check(doc.querySelector('input[name="legal_name"]') && doc.querySelector('input[name="account_number"]'), 'Personal and bank forms render');
  check(doc.body.textContent.includes('specimen') || doc.body.textContent.includes('Specimen'), 'Specimen signature remains distinct from eSign');
  button(doc, 'Financial records').click();
  check(doc.body.textContent.includes('Shubh Labh Trust') && doc.body.textContent.toLowerCase().includes('return'), 'Separate return and SLT financial records render');
  check(doc.body.textContent.includes('25,000') && doc.body.textContent.includes('10,000'), 'INR25000 and INR10000 displayed separately');
  button(doc, 'Signature centre').click();
  check(doc.body.textContent.includes('Signature') || doc.body.textContent.includes('signature'), 'Signature centre renders without browser-redirect approval');
  const selector = doc.querySelector('select[aria-label="Language / भाषा"]'); selector.value = 'hi'; selector.dispatchEvent(new window.Event('change', { bubbles: true }));
  check(doc.querySelector('#dbcl-app').lang === 'hi' && doc.body.textContent.includes('समूह'), 'Hindi navigation renders');
  check(window.localStorage.length === 0 && window.sessionStorage.length === 0, 'No identity or financial data persisted in browser storage');
  await waitFor(() => pendingRequests.size === 0, 'outstanding UI requests');
  await new Promise(resolve => setTimeout(resolve, 100));
  check(errors.length === 0, 'No DOM script exceptions');
  dom.window.close();
  process.stdout.write(`${assertions} DOM UI assertions executed; 0 failures. This validates JavaScript behavior, not a visual browser review.\n`);
})().catch(error => { process.stderr.write(error.stack + '\n'); process.exit(1); });
