#!/usr/bin/env bash
# Debian development/test runtime only. No production WordPress site is created or modified.
set -euo pipefail
umask 077
plugin_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
runtime_dir=${DBCL_RUNTIME_DIR:-/workspace/.runtime}
port=${DBCL_HTTP_PORT:-8087}
mkdir -p "$runtime_dir/bin" "$runtime_dir/root" "$runtime_dir/apt/lists/partial" "$runtime_dir/apt/cache/archives/partial"
if [ ! -x "$runtime_dir/root/usr/bin/php8.4" ] || [ ! -x "$runtime_dir/root/usr/sbin/mariadbd" ]; then
    [ -r /usr/share/keyrings/debian-archive-keyring.gpg ] || { printf 'Debian archive signing keyring is required.\n' >&2; exit 1; }
    cat > "$runtime_dir/apt/sources.list" <<'APT'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian-security trixie-security main
APT
    apt_opts=(-o "Dir::State::lists=$runtime_dir/apt/lists" -o "Dir::Cache=$runtime_dir/apt/cache" -o "Dir::Etc::sourcelist=$runtime_dir/apt/sources.list" -o Dir::Etc::sourceparts=- -o Debug::NoLocking=1)
    /usr/bin/apt-get "${apt_opts[@]}" update
    /usr/bin/apt-get "${apt_opts[@]}" --download-only -y install php8.4-cli php8.4-mysql php8.4-mbstring php8.4-xml php8.4-curl php8.4-zip mariadb-server-core mariadb-client-core mariadb-server
    for package in "$runtime_dir"/apt/cache/archives/*.deb; do dpkg-deb -x "$package" "$runtime_dir/root"; done
fi
# The PHP wrapper preserves system trust and loads only the locally installed extensions.
python - "$runtime_dir" <<'PY'
from pathlib import Path
import shlex, sys
root=Path(sys.argv[1]).resolve()
extensions=list((root/'root/usr/lib/php').glob('*/mysqlnd.so'))
if len(extensions)!=1: raise SystemExit('A single PHP8.4 extension directory is required.')
lib=str(root/'root/usr/lib/x86_64-linux-gnu')
command=[str(root/'root/usr/bin/php8.4'),'-n','-d','extension_dir='+str(extensions[0].parent)]
for extension in ['mysqlnd','mysqli','mbstring','xml','dom','simplexml','xmlreader','xmlwriter','ctype','fileinfo','iconv','tokenizer','phar','curl','zip','exif']:
 command+=['-d','extension='+extension]
command+=['-d','date.timezone=UTC','-d','memory_limit=256M']
wrapper='#!/bin/sh\nexport LD_LIBRARY_PATH='+shlex.quote(lib)+'${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}\nexec '+shlex.join(command)+' "$@"\n'
p=root/'bin/php';p.write_text(wrapper);p.chmod(0o700)
PY
"$runtime_dir/bin/php" -r 'if (!extension_loaded("mysqli") || !extension_loaded("openssl") || !extension_loaded("fileinfo")) exit(1); echo "PHP runtime prerequisites passed.\n";'
if [ ! -f "$runtime_dir/wordpress/wp-load.php" ]; then
    git clone --depth=1 --branch 6.9.4 https://github.com/WordPress/WordPress.git "$runtime_dir/wordpress"
fi
[ "$(git -C "$runtime_dir/wordpress" rev-parse HEAD)" = 97b7f62adb5d8864c3fac554bc7182d9fd754a41 ] || { printf 'Unexpected WordPress core commit; retained files were preserved for review.\n' >&2; exit 1; }
loader_path="$runtime_dir/root/usr/lib/x86_64-linux-gnu"
if [ ! -d "$runtime_dir/mysql/mysql" ]; then
    LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$runtime_dir/root/usr/bin/mariadb-install-db" --no-defaults --basedir="$runtime_dir/root/usr" --datadir="$runtime_dir/mysql" --auth-root-authentication-method=normal --skip-test-db > "$runtime_dir/database-install.log" 2>&1
fi
chmod 700 "$runtime_dir/mysql"
if ! LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$runtime_dir/root/usr/bin/mariadb" --no-defaults --socket="$runtime_dir/mysql/mysql.sock" -u root -N -e 'SELECT 1' >/dev/null 2>&1; then
    nohup env LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$runtime_dir/root/usr/sbin/mariadbd" --no-defaults --basedir="$runtime_dir/root/usr" --datadir="$runtime_dir/mysql" --socket="$runtime_dir/mysql/mysql.sock" --pid-file="$runtime_dir/mysql/mysql.pid" --skip-networking --log-error="$runtime_dir/mysql/server.log" > "$runtime_dir/mysql/stdout.log" 2>&1 &
    for attempt in {1..40}; do
        if LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$runtime_dir/root/usr/bin/mariadb" --no-defaults --socket="$runtime_dir/mysql/mysql.sock" -u root -N -e 'SELECT 1' >/dev/null 2>&1; then break; fi
        sleep 0.25
    done
fi
LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$runtime_dir/root/usr/bin/mariadb" --no-defaults --socket="$runtime_dir/mysql/mysql.sock" -u root -e 'CREATE DATABASE IF NOT EXISTS dbcl_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'
python - "$runtime_dir" "$port" <<'PY'
from pathlib import Path
import secrets,sys
root=Path(sys.argv[1]).resolve();port=int(sys.argv[2]);wp=root/'wordpress'
config=wp/'wp-config.php'
def php(value): return "'"+str(value).replace('\\','\\\\').replace("'","\\'")+"'"
if not config.exists():
 values={'DB_NAME':'dbcl_test','DB_USER':'root','DB_PASSWORD':'','DB_HOST':'localhost:'+str(root/'mysql/mysql.sock'),'DB_CHARSET':'utf8mb4','DB_COLLATE':'','WP_HOME':f'http://127.0.0.1:{port}','WP_SITEURL':f'http://127.0.0.1:{port}','WP_DEBUG_LOG':str(root/'wordpress-debug.log'),'DBCL_PRIVATE_DIR':str(root/'private-files')}
 s='<?php\n'+''.join(f'define({php(k)}, {php(v)});\n' for k,v in values.items())
 for k in ['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT']: s+=f'define({php(k)}, {php(secrets.token_hex(40))});\n'
 s+="define('WP_DEBUG', true);\ndefine('WP_DEBUG_DISPLAY', false);\ndefine('DISABLE_WP_CRON', true);\n$table_prefix='wp_';\nif (!defined('ABSPATH')) define('ABSPATH', __DIR__.'/');\nrequire_once ABSPATH.'wp-settings.php';\n"
 config.write_text(s);config.chmod(0o600)
mu=wp/'wp-content/mu-plugins';mu.mkdir(parents=True,exist_ok=True)
sink=mu/'dbcl-test-mail-sink.php'
if not sink.exists(): sink.write_text("<?php\n// Local tests never dispatch external mail.\nadd_filter('pre_wp_mail', static function () { return true; });\n")
PY
plugin_link="$runtime_dir/wordpress/wp-content/plugins/digitalbe-client-group-loans"
if [ ! -e "$plugin_link" ] && [ ! -L "$plugin_link" ]; then ln -s "$plugin_root" "$plugin_link"; fi
[ "$(readlink -f "$plugin_link")" = "$plugin_root" ] || { printf 'A different plugin checkout already exists; it was preserved.\n' >&2; exit 1; }
cat > "$runtime_dir/install-wordpress.php" <<'PHP'
<?php
define('WP_INSTALLING', true);
require __DIR__.'/wordpress/wp-load.php';
require_once ABSPATH.'wp-admin/includes/upgrade.php';
if (!is_blog_installed()) {
    $password=bin2hex(random_bytes(24));
    wp_install('digital BE Loan Plugin Test','dbcl_admin','dbcl-admin@example.invalid',true,'',$password);
    file_put_contents(__DIR__.'/test-admin-password',$password);
    chmod(__DIR__.'/test-admin-password',0600);
}
require_once ABSPATH.'wp-admin/includes/plugin.php';
$result=activate_plugin('digitalbe-client-group-loans/digitalbe-client-group-loans.php');
if (is_wp_error($result)) { fwrite(STDERR,'Plugin activation failed: '.$result->get_error_code()."\n"); exit(1); }
echo 'WordPress installation and plugin activation passed; existing credentials retained.'.PHP_EOL;
PHP
"$runtime_dir/bin/php" "$runtime_dir/install-wordpress.php"
DBCL_RUNTIME_DIR="$runtime_dir" DBCL_HTTP_PORT="$port" "$plugin_root/tools/start-local.sh"
printf 'Disposable local development runtime prepared.\n'
