#!/usr/bin/env bash
set -euo pipefail
plugin_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
php_bin=${PHP_BIN:-php}
while IFS= read -r -d '' source_file; do "$php_bin" -l "$source_file" >/dev/null; done < <(find "$plugin_root" -name '*.php' -print0)
printf 'PHP syntax checks passed.\n'
for suite in integration.php storage-integrity.php notifications.php; do
    DBCL_TEST_ALLOW=1 "$php_bin" "$plugin_root/tests/$suite"
done
