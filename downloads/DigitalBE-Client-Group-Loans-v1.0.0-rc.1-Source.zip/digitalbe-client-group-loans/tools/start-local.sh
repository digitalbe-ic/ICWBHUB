#!/usr/bin/env bash
# Start retained local test services; no database or credential recreation.
set -euo pipefail
runtime_dir=${DBCL_RUNTIME_DIR:-/workspace/.runtime}
php_bin="$runtime_dir/bin/php"
server_bin="$runtime_dir/root/usr/sbin/mariadbd"
client_bin="$runtime_dir/root/usr/bin/mariadb"
loader_path="$runtime_dir/root/usr/lib/x86_64-linux-gnu"
socket_path="$runtime_dir/mysql/mysql.sock"
port=${DBCL_HTTP_PORT:-8087}
case "$port" in *[!0-9]*|'') printf 'Invalid DBCL_HTTP_PORT.\n' >&2; exit 1;; esac
[ -x "$php_bin" ] && [ -x "$server_bin" ] && [ -f "$runtime_dir/wordpress/wp-config.php" ] || { printf 'Run tools/setup-local.sh first.\n' >&2; exit 1; }
db_ready() { LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$client_bin" --no-defaults --socket="$socket_path" -u root -N -e 'SELECT 1' >/dev/null 2>&1; }
if ! db_ready; then
    nohup env LD_LIBRARY_PATH="$loader_path${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$server_bin" --no-defaults --basedir="$runtime_dir/root/usr" --datadir="$runtime_dir/mysql" --socket="$socket_path" --pid-file="$runtime_dir/mysql/mysql.pid" --skip-networking --log-error="$runtime_dir/mysql/server.log" > "$runtime_dir/mysql/stdout.log" 2>&1 &
    for attempt in {1..40}; do if db_ready; then break; fi; sleep 0.25; done
    db_ready || { printf 'MariaDB did not start; inspect runtime/mysql/server.log.\n' >&2; exit 1; }
fi
if ! curl --silent --show-error --max-time 3 "http://127.0.0.1:$port/wp-login.php" -o "$runtime_dir/login-health.html" 2>/dev/null || ! rg -q 'id="loginform"' "$runtime_dir/login-health.html"; then
    python - "$port" <<'PY'
import socket, sys
with socket.socket() as client:
    if client.connect_ex(('127.0.0.1', int(sys.argv[1]))) == 0:
        raise SystemExit('The test HTTP port is occupied by a different/unready service; no process was stopped.')
PY
    nohup "$php_bin" -S "127.0.0.1:$port" -t "$runtime_dir/wordpress" > "$runtime_dir/http.log" 2>&1 &
    echo "$!" > "$runtime_dir/http.pid"
    for attempt in {1..40}; do
        if curl --silent --show-error --max-time 2 "http://127.0.0.1:$port/wp-login.php" -o "$runtime_dir/login-health.html" 2>/dev/null; then break; fi
        sleep 0.25
    done
fi
if [ "${DBCL_SKIP_HTTP_CHECK:-0}" != 1 ]; then
    curl --silent --show-error --fail --max-time 5 "http://127.0.0.1:$port/wp-login.php" -o "$runtime_dir/login-health.html"
    rg -q 'id="loginform"' "$runtime_dir/login-health.html" || { printf 'WordPress login health check failed.\n' >&2; exit 1; }
fi
printf 'MariaDB query and WordPress HTTP startup checks passed.\n'
