#!/usr/bin/env python3
"""Exercise an isolated WordPress instance with real cookie/nonce HTTP requests.

Never run against production. Password values are read from a local private file
and never logged. External provider endpoints are not invoked.
"""
import base64
import http.cookiejar
import json
import os
from pathlib import Path
import re
import urllib.error
import urllib.parse
import urllib.request

if os.environ.get('DBCL_TEST_ALLOW') != '1':
    raise SystemExit('Set DBCL_TEST_ALLOW=1 only for a disposable local WordPress instance.')
base = os.environ.get('DBCL_HTTP_BASE', 'http://127.0.0.1:8087').rstrip('/')
if urllib.parse.urlparse(base).hostname not in ('127.0.0.1', 'localhost'):
    raise SystemExit('HTTP smoke test is restricted to loopback test instances.')
password_file = Path(os.environ.get('DBCL_TEST_PASSWORD_FILE', '/workspace/.runtime/test-admin-password'))
login = os.environ.get('DBCL_TEST_USERNAME', 'dbcl_admin')
jar = http.cookiejar.CookieJar()
client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
count = 0

def assert_check(condition, label):
    global count
    count += 1
    if not condition:
        raise AssertionError(label)

def request(url, data=None, headers=None):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with client.open(req, timeout=20) as res:
            return res.status, res.read(), res.headers
    except urllib.error.HTTPError as res:
        return res.code, res.read(), res.headers

status, html, _ = request(base + '/wp-login.php')
assert_check(status == 200 and b'id="loginform"' in html, 'WordPress login form served')
form = urllib.parse.urlencode({'log': login, 'pwd': password_file.read_text().strip(), 'wp-submit': 'Log In', 'redirect_to': base + '/wp-admin/', 'testcookie': '1'}).encode()
request(base + '/wp-login.php', form, {'Content-Type': 'application/x-www-form-urlencoded'})
assert_check(any(c.name.startswith('wordpress_logged_in_') for c in jar), 'Real WordPress login cookie issued')
status, html, _ = request(base + '/wp-admin/admin.php?page=dbcl-workspace')
assert_check(status == 200 and b'id="dbcl-app"' in html, 'Authenticated plugin workspace rendered')
match = re.search(rb'var DBCL = (\{[^\n]+\});', html)
assert_check(bool(match), 'Workspace includes server-generated REST nonce')
cfg = json.loads(match.group(1))
root, nonce = cfg['root'], cfg['nonce']

def api(path, body=None, with_nonce=True):
    headers = {'Content-Type': 'application/json'}
    if with_nonce:
        headers['X-WP-Nonce'] = nonce
    status, raw, response_headers = request(root + path, json.dumps(body).encode() if body is not None else None, headers)
    return status, json.loads(raw), response_headers

status, _, _ = api('applications')
assert_check(status == 200, 'Authenticated queue API responds')
status, data, _ = api('applications', {'branch': 'HTTP-TEST', 'purpose': 'Synthetic HTTP smoke', 'requested_amount_paise': 25000000})
assert_check(status == 200 and 'application' in data, 'Create application through actual cookie/nonce REST request')
app = data['application']
app_id = app['id']
Path('/workspace/.runtime/http-smoke-application-id').write_text(app_id)
status, _, _ = api('applications/' + app_id + '/profile', {'role': 'applicant', 'expected_version': app['version'], 'profile': {'legal_name': 'Synthetic HTTP Applicant', 'mobile': '9000000000'}, 'bank': {'holder_name': 'Synthetic HTTP Applicant', 'account_number': '123456789012', 'account_number_confirm': '123456789012', 'ifsc': 'HDFC0000001'}}, with_nonce=False)
assert_check(status == 401, 'Cookie without REST nonce cannot mutate application')
status, data, _ = api('applications/' + app_id + '/profile', {'role': 'applicant', 'expected_version': app['version'], 'profile': {'legal_name': 'Synthetic HTTP Applicant', 'mobile': '9000000000'}, 'bank': {'holder_name': 'Synthetic HTTP Applicant', 'account_number': '123456789012', 'account_number_confirm': '123456789012', 'ifsc': 'HDFC0000001'}})
assert_check(status == 200, 'Profile save through authenticated REST succeeds')
updated = data['application']
assert_check('123456789012' not in json.dumps(updated), 'HTTP response masks full bank account number')
status, _, _ = api('applications/' + app_id + '/profile', {'role': 'applicant', 'expected_version': app['version'], 'profile': {'legal_name': 'Stale overwrite'}})
assert_check(status == 409, 'Actual HTTP stale-version write rejected')
status, _, _ = api('applications/' + app_id + '/consent', {'role': 'guarantor_1', 'purpose': 'kyc', 'version': '1', 'accepted': True, 'expected_version': updated['version']})
assert_check(status == 403, 'Applicant session cannot provide guarantor consent')
status, _, _ = api('applications/' + app_id + '/commands', {'command': 'prepare_payment', 'input': {}, 'expected_version': updated['version']})
assert_check(status == 403, 'Configuration administrator lacks implicit financial-maker authority')

# A real multipart upload reaches PHP is_uploaded_file(), MIME checks and encryption.
png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jrS0AAAAASUVORK5CYII=')
boundary = 'DBCLTestBoundary2026'
parts = []
for key, value in {'role': 'applicant', 'type': 'live_photo', 'original_confirmed': 'true', 'capture_method': 'upload', 'expected_version': str(updated['version'])}.items():
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="synthetic-original.png"\r\nContent-Type: image/png\r\n\r\n'.encode() + png + b'\r\n')
parts.append(f'--{boundary}--\r\n'.encode())
status, raw, _ = request(root + 'applications/' + app_id + '/documents', b''.join(parts), {'X-WP-Nonce': nonce, 'Content-Type': 'multipart/form-data; boundary=' + boundary})
upload = json.loads(raw)
assert_check(status == 200 and upload['files'], 'Actual multipart image upload stored')
file_id = upload['files'][0]['id']
assert_check(upload['files'][0]['scan_status'] == 'PENDING', 'Upload never fabricates a clean scan result')
status, downloaded, headers = request(root + 'files/' + file_id, headers={'X-WP-Nonce': nonce})
assert_check(status == 200 and downloaded == png, 'Authenticated private document download returns original bytes')
assert_check('private' in headers.get('Cache-Control', '').lower() or 'no-store' in headers.get('Cache-Control', '').lower(), 'Private download sends restrictive cache policy')
# New anonymous client cannot reuse an object's URL as authority.
try:
    urllib.request.urlopen(root + 'files/' + file_id, timeout=20)
    denied = 200
except urllib.error.HTTPError as error:
    denied = error.code
assert_check(denied == 401, 'Anonymous private document download denied')
print(f'{count} HTTP assertions executed; 0 failures. Application {app_id} is a synthetic disposable test record.')
