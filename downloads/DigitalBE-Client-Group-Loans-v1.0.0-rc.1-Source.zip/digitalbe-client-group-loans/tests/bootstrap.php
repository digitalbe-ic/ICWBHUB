<?php
// Run only against a disposable WordPress database; no external integrations are called.
if (PHP_SAPI !== 'cli' || getenv('DBCL_TEST_ALLOW') !== '1') {
    fwrite(STDERR, "Set DBCL_TEST_ALLOW=1 only for a disposable WordPress test database.\n");
    exit(2);
}
$root = getenv('DBCL_WP_ROOT') ?: '/workspace/.runtime/wordpress';
if (!is_file($root . '/wp-load.php')) {
    fwrite(STDERR, "Set DBCL_WP_ROOT to an installed, isolated WordPress checkout.\n");
    exit(2);
}
require_once $root . '/wp-load.php';
add_filter('pre_wp_mail', static function () { return true; });
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-admin/includes/user.php';
$plugin = dirname(__DIR__) . '/digitalbe-client-group-loans.php';
require_once $plugin;
DigitalBE\ClientGroupLoans\Store::install();
DigitalBE\ClientGroupLoans\Auth::install();
rest_get_server();
