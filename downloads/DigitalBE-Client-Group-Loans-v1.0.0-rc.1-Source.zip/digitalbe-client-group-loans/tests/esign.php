<?php
use DigitalBE\ClientGroupLoans\ESign;
use DigitalBE\ClientGroupLoans\Providers;
use DigitalBE\ClientGroupLoans\Store;

/** Actual WordPress/DB/HTTP-boundary tests with synthetic PDFs and no provider network. */
function dbcl_esign_tests(array $actors): void
{
    global $applications;
    $settingsBefore = get_option('dbcl_settings', []);
    $tokenBefore = getenv('DBCL_SUREPASS_TOKEN');
    $owner = $actors['applicant'];
    $operator = $actors['operations'];
    $settings = ['terms_approved' => true, 'template_version' => 'synthetic-v1', 'surepass_environment' => 'production', 'consent_texts' => ['data_processing' => ['version' => 'synthetic-v1', 'text' => 'Synthetic processing consent'], 'esign' => ['version' => 'synthetic-v1', 'text' => 'Synthetic signing consent']]];
    update_option('dbcl_settings', $settings);
    putenv('DBCL_SUREPASS_TOKEN=synthetic-test-token-never-a-live-key');
    $pdf = "%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [] /Count 0 >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n";
    $signedPdf = str_replace('%%EOF', "% SYNTHETIC SIGNED ARTIFACT\n%%EOF", $pdf);
    $requests = [];
    $completed = false;
    $unknownUpload = false;
    $providerOverride = null;
    $reservedBeforeNetwork = [];
    $activeApplication = '';
    $activeSession = '';
    $mock = static function ($preempt, $args, $url) use (&$requests, &$completed, &$unknownUpload, &$providerOverride, &$reservedBeforeNetwork, &$activeApplication, &$activeSession, $signedPdf) {
        $requests[] = ['url' => $url, 'args' => $args];
        $state = Store::get($activeApplication);
        $reservedBeforeNetwork[] = !is_wp_error($state) ? ($state['esign_sessions'][$activeSession]['status'] ?? '') : '';
        if (is_array($providerOverride)) {
            return ['response' => ['code' => 200], 'body' => wp_json_encode($providerOverride)];
        }
        if (str_ends_with($url, '/api/v1/files/esign/upload')) {
            if ($unknownUpload) { return new WP_Error('synthetic_timeout', 'Synthetic timeout; no actual network call.'); }
            return ['response' => ['code' => 200], 'body' => wp_json_encode(['success' => true, 'status_code' => 200, 'data' => ['uploaded' => true, 'file_id' => 'files_SYNTHETIC12345']])];
        }
        if (str_ends_with($url, '/api/v1/esign/initialize')) {
            return ['response' => ['code' => 200], 'body' => wp_json_encode(['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'esign_SYNTHETIC12345', 'url' => 'https://esign-client.surepass.io/?token=SYNTHETIC_SIGNING_TOKEN_1234567890']])];
        }
        if (str_contains($url, '/api/v1/esign/status/')) {
            return ['response' => ['code' => 200], 'body' => wp_json_encode(['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'esign_SYNTHETIC12345', 'status' => $completed ? 'esign_completed' : 'otp_sent']])];
        }
        if (str_contains($url, '/api/v1/esign/get-signed-document/')) {
            return ['response' => ['code' => 200], 'body' => wp_json_encode(['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'esign_SYNTHETIC12345', 'url' => 'https://synthetic-bucket.s3.amazonaws.com/signed.pdf?signature=SYNTHETIC']])];
        }
        if (str_starts_with($url, 'https://synthetic-bucket.s3.amazonaws.com/')) {
            return ['response' => ['code' => 200], 'body' => $signedPdf];
        }
        return new WP_Error('synthetic_unexpected_request', 'Unexpected synthetic test request blocked.');
    };
    add_filter('pre_http_request', $mock, 30, 3);
    $fixture = static function () use ($owner, $settings, $pdf, &$applications): array {
        $case = basic_case($owner);
        $party =& $case['parties']['applicant'];
        $party['profile']['mobile'] = '9876543210';
        $party['profile']['email'] = 'signer@example.invalid';
        foreach ($settings['consent_texts'] as $purpose => $definition) {
            $party['consents'][$purpose] = ['accepted' => true, 'version' => $definition['version'], 'text' => $definition['text'], 'actor_id' => $owner];
        }
        $termsHash = hash('sha256', 'Synthetic accepted loan terms');
        $case['loans']['initial'] = ['id' => wp_generate_uuid4(), 'terms' => ['hash' => $termsHash, 'version' => 'synthetic-v1', 'accepted' => ['applicant' => ['accepted' => true, 'terms_hash' => $termsHash, 'party_id' => $party['id'], 'user_id' => $owner]]], 'signatures' => []];
        unset($party);
        $tmp = wp_tempnam('dbcl-synthetic-source');
        file_put_contents($tmp, $pdf);
        $source = Store::store_file($case['id'], $case['parties']['applicant']['id'], 'execution_pdf', $tmp, 'application/pdf');
        unlink($tmp);
        if (is_wp_error($source)) { throw new RuntimeException('Synthetic eSign source could not be stored: ' . $source->get_error_code()); }
        $bindingMethod = new ReflectionMethod(ESign::class, 'preconditions');
        $binding = $bindingMethod->invoke(null, $case, 'initial', 'applicant');
        if (is_wp_error($binding)) { throw new RuntimeException('Synthetic eSign binding could not be prepared: ' . $binding->get_error_code()); }
        $id = wp_generate_uuid4();
        $session = $binding + ['id' => $id, 'purpose' => 'initial', 'party_role' => 'applicant', 'source_file_id' => $source['id'], 'source_sha256' => $source['sha256'], 'positions' => ['1' => [['x' => 100, 'y' => 200]]], 'scan_status' => 'CLEAN', 'status' => 'SOURCE_READY', 'created_at' => gmdate('c')];
        $hashMethod = new ReflectionMethod(ESign::class, 'fingerprint');
        $session['fingerprint'] = $hashMethod->invoke(null, $session);
        $case['esign_sessions'][$id] = $session;
        $created = Store::create($case);
        if (is_wp_error($created)) { throw new RuntimeException('Synthetic signing case could not be stored.'); }
        $applications[] = $created['id'];
        return [$created, $session];
    };
    try {
        [$case, $session] = $fixture();
        $activeApplication = $case['id']; $activeSession = $session['id'];
        wp_set_current_user($owner);
        check(ESign::validate_binding($case, $session) === true, 'esign: approved source binds current signer and terms');
        $changed = $case; $changed['parties']['applicant']['profile']['mobile'] = '9876543211';
        check(is_wp_error(ESign::validate_binding($changed, $session)), 'esign: changed signer contact invalidates immutable session');
        $changed = $case; $changed['parties']['applicant']['consents']['esign']['accepted'] = false;
        check(is_wp_error(ESign::validate_binding($changed, $session)), 'esign: withdrawn signing consent blocks execution');
        $changed = $case; $changed['loans']['initial']['terms']['hash'] = hash('sha256', 'New terms');
        check(is_wp_error(ESign::validate_binding($changed, $session)), 'esign: changed terms invalidate source acceptance');
        $tampered = $session; $tampered['source_sha256'] = str_repeat('0', 64);
        check(is_wp_error(ESign::validate_binding($case, $tampered)), 'esign: source hash tampering rejected');
        $response = api('POST', '/applications/' . $case['id'] . '/esign', ['expected_version' => $case['version'], 'session_id' => $session['id'], 'action' => 'begin']);
        check($response->get_status() === 200, 'esign: independent signer starts the approved PDF flow');
        $case = Store::get($case['id']);
        check($case['esign_sessions'][$session['id']]['status'] === 'SIGNING_PENDING', 'esign: provider initialization remains pending');
        check($reservedBeforeNetwork[0] === 'UPLOAD_PROCESSING' && $reservedBeforeNetwork[1] === 'INITIALIZE_PROCESSING', 'esign: durable reservations precede each provider mutation');
        check(empty($case['loans']['initial']['signatures']), 'esign: hosted link is not completed signature evidence');
        $initialCount = count($requests);
        $repeat = api('POST', '/applications/' . $case['id'] . '/esign', ['expected_version' => $case['version'], 'session_id' => $session['id'], 'action' => 'begin']);
        check($repeat->get_status() === 409 && count($requests) === $initialCount, 'esign: repeat begin cannot create another paid signing session');
        wp_set_current_user($operator);
        $staffSessions = ESign::public_sessions($case);
        check(!str_contains(wp_json_encode($staffSessions), 'SYNTHETIC_SIGNING_TOKEN'), 'esign: operations staff never receive private signer URL');
        wp_set_current_user($owner);
        check(str_contains(wp_json_encode(ESign::public_sessions($case)), 'SYNTHETIC_SIGNING_TOKEN'), 'esign: current signer can resume their own protected link');
        $response = api('POST', '/applications/' . $case['id'] . '/esign', ['expected_version' => $case['version'], 'session_id' => $session['id'], 'action' => 'check']);
        $case = Store::get($case['id']);
        check($response->get_status() === 200 && $case['esign_sessions'][$session['id']]['status'] === 'SIGNING_PENDING' && empty($case['loans']['initial']['signatures']), 'esign: provider OTP pending never completes execution');
        $completed = true;
        $response = api('POST', '/applications/' . $case['id'] . '/esign', ['expected_version' => $case['version'], 'session_id' => $session['id'], 'action' => 'check']);
        $case = Store::get($case['id']);
        $storedSession = $case['esign_sessions'][$session['id']];
        check($response->get_status() === 200 && $storedSession['status'] === 'COMPLETED', 'esign: verified completion plus retrieved PDF completes session');
        $signature = $case['loans']['initial']['signatures']['applicant'] ?? [];
        check(($signature['status'] ?? '') === 'COMPLETED' && ($signature['source'] ?? '') === 'PROVIDER_CONFIRMED' && ($signature['terms_hash'] ?? '') === $session['terms_hash'], 'esign: execution evidence remains bound to exact party and terms');
        $artifact = Store::read_file($storedSession['signed_document_id'] ?? '');
        check(!is_wp_error($artifact) && $artifact['bytes'] === $signedPdf && $artifact['party_id'] === $session['party_id'] && $artifact['application_id'] === $case['id'], 'esign: actual executed PDF is encrypted under correct party scope');
        $s3 = array_values(array_filter($requests, static fn($r) => str_starts_with($r['url'], 'https://synthetic-bucket.s3.amazonaws.com/')));
        check(count($s3) === 1 && empty($s3[0]['args']['headers']['Authorization']), 'esign: API Bearer key is never forwarded to signed S3 URLs');
        check(empty($storedSession['action_url']), 'esign: completed session discards private signing URL');
        $count = count($requests);
        api('POST', '/applications/' . $case['id'] . '/esign', ['expected_version' => $case['version'], 'session_id' => $session['id'], 'action' => 'check']);
        check(count($requests) === $count, 'esign: completed status check creates no duplicate requests or artifacts');
        wp_set_current_user($actors['co_applicant']);
        $denied = api('GET', '/applications/' . $case['id'] . '/esign');
        check($denied->get_status() === 403, 'esign: unrelated account cannot inspect signer sessions');
        wp_set_current_user($owner);
        [$unknownCase, $unknownSession] = $fixture();
        $activeApplication = $unknownCase['id']; $activeSession = $unknownSession['id'];
        $unknownUpload = true;
        $response = api('POST', '/applications/' . $unknownCase['id'] . '/esign', ['expected_version' => $unknownCase['version'], 'session_id' => $unknownSession['id'], 'action' => 'begin']);
        $unknownCase = Store::get($unknownCase['id']);
        check($response->get_status() === 200 && $unknownCase['esign_sessions'][$unknownSession['id']]['status'] === 'UPLOAD_UNCONFIRMED', 'esign: transport timeout preserves unknown upload state');
        $count = count($requests);
        $response = api('POST', '/applications/' . $unknownCase['id'] . '/esign', ['expected_version' => $unknownCase['version'], 'session_id' => $unknownSession['id'], 'action' => 'begin']);
        check($response->get_status() === 409 && count($requests) === $count, 'esign: unknown upload cannot be blindly retried');

        // Mapping mistakes cannot weaken built-in identity/source correlation.
        $context = ['consent' => true, 'consent_purpose' => 'kyc', 'application_id' => $case['id'], 'party_id' => $session['party_id'], 'expected_name' => 'Synthetic Applicant', 'settings' => ['surepass_environment' => 'sandbox']];
        $bankMapping = Providers::default_mappings()['bank-verification'];
        unset($bankMapping['normalizer']);
        $bankMapping['verdict_path'] = 'success'; $bankMapping['verified_values'] = [true];
        $context['settings']['surepass_mappings']['bank-verification'] = $bankMapping;
        $providerOverride = ['success' => true, 'data' => []];
        $result = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
        check(!is_wp_error($result) && $result['status'] === 'review_required', 'providers: mapping cannot remove bank evidence checks or verify success alone');
        $context['settings']['surepass_mappings']['face-match'] = ['confirmed' => true, 'path' => '/api/v1/ocr/face-match', 'field_map' => ['image' => 'image'], 'required_fields' => ['image'], 'verdict_path' => 'success', 'verified_values' => [true]];
        $result = Providers::request('face-match', ['image' => 'SYNTHETIC'], $context);
        check(!is_wp_error($result) && $result['status'] === 'review_required', 'providers: generic accepted request cannot be configured as an identity verdict');
        $digilockerRef = 'digilocker_SYNTHETIC12345';
        $providerOverride = ['success' => true, 'status_code' => 200, 'data' => ['client_id' => $digilockerRef, 'aadhaar_xml_data' => ['full_name' => 'Synthetic Applicant', 'dob' => '1990-01-01', 'masked_aadhaar' => 'XXXXXXXX1234']]];
        $result = Providers::request('digilocker-download', ['client_id' => $digilockerRef, 'dob' => '1990-01-02', 'aadhaar_last4' => '1234'], $context);
        check(!is_wp_error($result) && $result['status'] === 'review_required', 'providers: same name with conflicting DOB does not verify the typed party');
        $result = Providers::request('digilocker-download', ['client_id' => $digilockerRef, 'dob' => '1990-01-01', 'aadhaar_last4' => '5678'], $context);
        check(!is_wp_error($result) && $result['status'] === 'review_required', 'providers: conflicting masked Aadhaar does not verify the typed party');
        $result = Providers::request('digilocker-download', ['client_id' => $digilockerRef, 'dob' => '1990-01-01', 'aadhaar_last4' => '1234'], $context);
        check(!is_wp_error($result) && $result['status'] === 'verified', 'providers: matching provider identity evidence verifies the exact typed party');
        $context['consent_purpose'] = 'esign';
        $esignMapping = Providers::default_mappings()['esign-initialize'];
        $esignMapping['fixed_values']['config.skip_otp'] = true;
        $context['settings']['surepass_mappings']['esign-initialize'] = $esignMapping;
        $count = count($requests);
        $result = Providers::request('esign-initialize', [], $context);
        check(is_wp_error($result) && count($requests) === $count, 'providers: signing configuration cannot skip customer authorization');
        $providerOverride = ['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'esign_OTHERSESSION123', 'status' => 'esign_completed']];
        $statusMapping = Providers::default_mappings()['esign-status']; $statusMapping['reference_path'] = 'missing.field';
        $context['settings']['surepass_mappings']['esign-status'] = $statusMapping;
        $result = Providers::request('esign-status', ['client_id' => 'esign_SYNTHETIC12345'], $context);
        check(is_wp_error($result), 'providers: overriding reference path cannot hide another signer session');
        $stale = $case; $stale['esign_sessions'][$session['id']]['status'] = 'SIGNING_PENDING'; $stale['esign_sessions'][$session['id']]['action_url'] = 'https://esign-client.surepass.io/?token=SYNTHETIC_STALE_PRIVATE_URL';
        $stale['parties']['applicant']['profile']['mobile'] = '9876543211';
        $public = ESign::public_sessions($stale);
        check(($public[0]['status'] ?? '') === 'STALE_SOURCE' && !str_contains(wp_json_encode($public), 'SYNTHETIC_STALE_PRIVATE_URL'), 'esign: stale source never exposes an old signing link');
        get_user_by('id', $owner)->add_cap('dbcl_operate');
        $blockedUpload = api('POST', '/applications/' . $case['id'] . '/esign/documents', ['expected_version' => $case['version']]);
        check($blockedUpload->get_status() === 403, 'esign: borrower account with staff capability cannot approve its own signing source');
        get_user_by('id', $owner)->remove_cap('dbcl_operate');

        // A pending source can be recovered after configuration, without weakening infection handling.
        [$reviewCase, $reviewSession] = $fixture();
        $reviewCase['staff_assignments'][$operator] = 'operations';
        $reviewCase['esign_sessions'][$reviewSession['id']]['status'] = 'SOURCE_REVIEW_REQUIRED';
        $reviewCase['esign_sessions'][$reviewSession['id']]['scan_status'] = 'PENDING';
        $reviewCase = Store::save($reviewCase, $reviewCase['version'], $owner, 'synthetic_source_pending');
        update_option('dbcl_settings', $settings + ['allow_unscanned_manual_review' => true]);
        wp_set_current_user($operator);
        $response = api('POST', '/applications/' . $reviewCase['id'] . '/esign', ['expected_version' => $reviewCase['version'], 'session_id' => $reviewSession['id'], 'action' => 'review_source', 'review_confirmed' => true, 'approval_ref' => 'SYNTHETIC-REVIEW']);
        $reviewCase = Store::get($reviewCase['id']);
        check($response->get_status() === 200 && $reviewCase['esign_sessions'][$reviewSession['id']]['status'] === 'SOURCE_READY' && $reviewCase['esign_sessions'][$reviewSession['id']]['scan_status'] === 'PENDING', 'esign: permitted manual source review is recorded without inventing a clean scan');
        $reviewCase['esign_sessions'][$reviewSession['id']]['status'] = 'SOURCE_BLOCKED';
        $reviewCase['esign_sessions'][$reviewSession['id']]['scan_status'] = 'INFECTED';
        $reviewCase = Store::save($reviewCase, $reviewCase['version'], $operator, 'synthetic_source_infected');
        for ($attempt = 0; $attempt < 2; $attempt++) {
            $response = api('POST', '/applications/' . $reviewCase['id'] . '/esign', ['expected_version' => $reviewCase['version'], 'session_id' => $reviewSession['id'], 'action' => 'review_source', 'review_confirmed' => true, 'approval_ref' => 'SYNTHETIC-REVIEW']);
            $reviewCase = Store::get($reviewCase['id']);
        }
        check($response->get_status() === 200 && $reviewCase['esign_sessions'][$reviewSession['id']]['status'] === 'SOURCE_BLOCKED' && $reviewCase['esign_sessions'][$reviewSession['id']]['scan_status'] === 'INFECTED', 'esign: repeated scanner outages never bypass a known infected source');
    } finally {
        remove_filter('pre_http_request', $mock, 30);
        update_option('dbcl_settings', $settingsBefore);
        putenv($tokenBefore === false ? 'DBCL_SUREPASS_TOKEN' : 'DBCL_SUREPASS_TOKEN=' . $tokenBefore);
    }
}
