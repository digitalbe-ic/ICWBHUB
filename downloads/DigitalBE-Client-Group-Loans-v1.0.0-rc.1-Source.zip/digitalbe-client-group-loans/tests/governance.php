<?php
use DigitalBE\ClientGroupLoans\API;
use DigitalBE\ClientGroupLoans\Auth;
use DigitalBE\ClientGroupLoans\Notifications;
use DigitalBE\ClientGroupLoans\Store;

function dbcl_governance_tests(array $ids): void {
    global $applications, $wpdb;
    $old = get_option('dbcl_settings', []);
    $delivery = null;
    try {
        update_option('dbcl_settings', ['revision' => 7, 'require_staff_mfa' => false, 'notifications_enabled' => false]);
        wp_set_current_user($ids['administrator']);
        $noRevision = api('POST', '/settings', ['settings' => ['financial_operations_enabled' => true]]);
        check($noRevision->get_status() === 409, 'settings: expected revision is mandatory');
        $stale = api('POST', '/settings', ['expected_revision' => 6, 'settings' => ['financial_operations_enabled' => true]]);
        check($stale->get_status() === 409, 'settings: stale configuration write rejected');
        $saved = api('POST', '/settings', ['expected_revision' => 7, 'settings' => ['financial_operations_enabled' => true, 'lender_name' => 'Synthetic Lender']]);
        check($saved->get_status() === 200 && get_option('dbcl_settings')['revision'] === 8, 'settings: matching revision advances atomically');
        check(empty(get_option('dbcl_settings')['approved_by']), 'settings: any configuration edit clears financial approval');
        $admin = get_user_by('id', $ids['administrator']);
        $admin->add_cap('dbcl_finance_check');
        $ownApproval = api('POST', '/settings/approve', ['revision' => 8]);
        check($ownApproval->get_status() === 403, 'settings: maker cannot approve own settings even with checker capability');
        $admin->remove_cap('dbcl_finance_check');
        wp_set_current_user($ids['checker']);
        check(api('POST', '/settings/approve', ['revision' => 7])->get_status() === 409, 'settings: checker cannot approve stale revision');
        check(api('POST', '/settings/approve', ['revision' => 8])->get_status() === 200, 'settings: independent checker approves exact version');
        $approved = get_option('dbcl_settings');
        check($approved['approved_by'] === $ids['checker'] && $approved['approved_revision'] === 8, 'settings: approval records checker and exact revision');
        $write = new ReflectionMethod(API::class, 'write_settings');
        $concurrent = $approved; $concurrent['revision'] = 9;
        update_option('dbcl_settings', $concurrent);
        $wrongWrite = $write->invoke(null, array_merge($approved, ['lender_name' => 'Stale overwrite']), $approved);
        check(is_wp_error($wrongWrite) && get_option('dbcl_settings')['revision'] === 9, 'settings: database CAS prevents stale cached-option overwrite');

        update_option('dbcl_settings', ['require_staff_mfa' => false, 'notifications_enabled' => false, 'sla_hours' => 1]);
        $case = basic_case($ids['applicant']);
        $case['parties']['co_applicant']['user_id'] = $ids['co_applicant'];
        $case['assigned_id'] = $ids['reviewer'];
        $case['internal_notes'] = 'PRIVATE-NOTE-NEVER-NOTIFY';
        $case = Notifications::append($case, 'application_created');
        check(count($case['notifications']) === 1, 'notifications: initial in-app notice created');
        $again = Notifications::append($case, 'application_created');
        check(count($again['notifications']) === 1, 'notifications: unchanged stage deduplicates notice');
        $notice = array_values($case['notifications'])[0];
        check($notice['delivery']['state'] === 'DISABLED', 'notifications: external delivery disabled by default');
        check(!str_contains(wp_json_encode($notice), 'PRIVATE-NOTE') && !str_contains(wp_json_encode($notice), '123456789012'), 'notifications: safe copy excludes internal notes and identity details');
        $case = Store::create($case);
        if (is_wp_error($case)) { throw new RuntimeException('Notification case could not be created.'); }
        $applications[] = $case['id'];
        wp_set_current_user($ids['applicant']);
        $visible = api('GET', '/applications/' . $case['id'] . '/notifications');
        check($visible->get_status() === 200 && $visible->get_data()['unread_count'] === 1, 'notifications: recipient sees own unread notice');
        check(!isset($visible->get_data()['notifications'][0]['recipients']), 'notifications: response excludes other recipients');
        $read = api('POST', '/notifications/' . $notice['id'] . '/read', ['application_id' => $case['id'], 'expected_version' => $case['version']]);
        check($read->get_status() === 200 && $read->get_data()['unread_count'] === 0, 'notifications: recipient marks own notice read');
        $case = Store::get($case['id']);
        wp_set_current_user($ids['unrelated']);
        check(api('GET', '/applications/' . $case['id'] . '/notifications')->get_status() === 403, 'notifications: unrelated account cannot inspect notices');
        check(api('POST', '/notifications/' . $notice['id'] . '/read', ['application_id' => $case['id'], 'expected_version' => $case['version']])->get_status() === 403, 'notifications: unrelated account cannot mark notice read');

        update_option('dbcl_settings', ['require_staff_mfa' => false, 'notifications_enabled' => true, 'sla_hours' => 1]);
        $deliveries = 0; $claimedBeforeSend = []; $throw = false;
        $delivery = static function ($result, array $payload, array $context) use (&$deliveries, &$claimedBeforeSend, &$throw) {
            $deliveries++;
            $stored = Store::get($payload['application_id']);
            $claimedBeforeSend[] = $stored['notifications'][$payload['id']]['delivery']['state'] ?? '';
            check(!str_contains(wp_json_encode($payload), 'PRIVATE-NOTE') && !str_contains(wp_json_encode($payload), '123456789012'), 'notifications: delivery adapter payload contains customer-safe copy only');
            check($context['idempotency_key'] === $payload['id'], 'notifications: adapter receives stable idempotency key');
            if ($throw) { throw new RuntimeException('Synthetic adapter timeout; no real message sent.'); }
            return ['status' => 'DELIVERED', 'reference' => 'SYNTHETIC-DELIVERY-REF'];
        };
        add_filter('dbcl_deliver_notification', $delivery, 10, 3);
        $case['stage'] = 'SLT_MANDATE_PENDING';
        $case = Notifications::append($case, 'test_stage_change');
        $case = Store::save($case, $case['version'], $ids['reviewer'], 'test_stage_change');
        Notifications::run_reminders(gmdate('c'));
        check($deliveries === 1 && $claimedBeforeSend === ['PROCESSING'], 'notifications: delivery attempt is durably claimed before adapter execution');
        $case = Store::get($case['id']);
        $latest = array_values($case['notifications'])[1];
        check($latest['delivery']['state'] === 'DELIVERED', 'notifications: confirmed adapter delivery recorded');
        Notifications::run_reminders(gmdate('c'));
        check($deliveries === 1, 'notifications: cron replay does not redeliver successful notice');
        $throw = true;
        $case['stage'] = 'SLT_COLLECTION_PENDING';
        $case = Notifications::append($case, 'test_unknown_delivery');
        $case = Store::save($case, $case['version'], $ids['reviewer'], 'test_unknown_delivery');
        Notifications::run_reminders(gmdate('c'));
        $case = Store::get($case['id']);
        $latest = array_values($case['notifications'])[2];
        check($latest['delivery']['state'] === 'UNKNOWN', 'notifications: adapter exception preserves unknown outcome');
        $before = $deliveries;
        Notifications::run_reminders(gmdate('c'));
        check($deliveries === $before, 'notifications: unknown delivery is never blindly retried');
        update_option('dbcl_settings', ['require_staff_mfa' => false, 'notifications_enabled' => false, 'sla_hours' => 1]);
        $case['notification_state']['stage_entered_at'] = gmdate('c', time() - 7200);
        $case = Store::save($case, $case['version'], $ids['applicant'], 'unrelated_touch_does_not_reset_sla');
        $before = count($case['notifications']);
        Notifications::run_reminders(gmdate('c'));
        $case = Store::get($case['id']);
        check(count($case['notifications']) === $before + 1 && array_values($case['notifications'])[$before]['kind'] === 'SLA_REMINDER', 'notifications: overdue stage receives a safe in-app SLA reminder');
        Notifications::run_reminders(gmdate('c'));
        check(count(Store::get($case['id'])['notifications']) === $before + 1, 'notifications: repeated cron respects reminder interval');
    } finally {
        if ($delivery !== null) { remove_filter('dbcl_deliver_notification', $delivery, 10); }
        update_option('dbcl_settings', $old);
    }
}
