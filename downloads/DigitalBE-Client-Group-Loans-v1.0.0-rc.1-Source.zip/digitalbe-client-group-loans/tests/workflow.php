<?php
use DigitalBE\ClientGroupLoans\Workflow;

function dbcl_workflow_tests(array $ids): void {
    $actors = [
        'review' => ['id' => $ids['reviewer'], 'capabilities' => ['dbcl_review']],
        'supervisor' => ['id' => $ids['supervisor'], 'capabilities' => ['dbcl_assign']],
        'operations' => ['id' => $ids['operations'], 'capabilities' => ['dbcl_operate']],
        'verify' => ['id' => $ids['verifier'], 'capabilities' => ['dbcl_verify']],
        'maker' => ['id' => $ids['maker'], 'capabilities' => ['dbcl_finance_make', 'dbcl_finance_check']],
        'checker' => ['id' => $ids['checker'], 'capabilities' => ['dbcl_finance_check']],
    ];
    $partyActors = [];
    foreach (Workflow::ROLES as $role) { $partyActors[$role] = ['id' => $ids[$role], 'capabilities' => ['party'], 'party_role' => $role]; }
    $case = Workflow::initial(['branch' => 'test-branch', 'loan_purpose' => 'Synthetic full-journey test'], $ids['applicant']);
    $run = static function (string $command, array $input, array $actor) use (&$case) {
        $result = Workflow::apply($case, $command, $input, $actor);
        if (!success($result, 'Workflow: ' . $command)) { throw new RuntimeException('Workflow failed at ' . $command . ': ' . $result->get_error_message()); }
        $case = $result;
        return $result;
    };
    $evidence = ['reference' => 'external-reference', 'evidence_ref' => 'reviewed-authoritative-bank-or-provider-record'];
    $prepare = ['purpose' => 'initial_disbursement', 'amount_paise' => 1000000, 'beneficiary_ref' => 'bank-applicant', 'idempotency_key' => 'test-initial-unique-key'] + $evidence;
    error_is(Workflow::apply($case, 'prepare_payment', $prepare, $actors['maker']), 'dbcl_financial_operations_disabled', 'Financial operations are disabled by default');
    $case['policy']['financial_operations_enabled'] = true;
    error_is(Workflow::apply($case, 'prepare_payment', $prepare, $actors['maker']), 'dbcl_gate_blocked', 'Enabled finance cannot skip missing onboarding gates');
    foreach (Workflow::ROLES as $i => $role) {
        $case['parties'][$role]['user_id'] = $ids[$role];
        $case['parties'][$role]['profile'] = ['legal_name' => 'Synthetic ' . $role, 'mobile' => '900000000' . $i];
        $case['parties'][$role]['consents']['document_processing'] = ['accepted' => true, 'version' => '1'];
        $case['parties'][$role]['bank'] = ['holder_name' => 'Synthetic ' . $role, 'account_number' => '1234567890' . $i, 'ifsc' => 'HDFC0000001'];
        foreach (Workflow::DOCUMENTS as $type) {
            $documentId = wp_generate_uuid4();
            $case['parties'][$role]['documents'][] = ['id' => $documentId, 'type' => $type, 'sha256' => hash('sha256', $role . $type), 'scan_status' => 'CLEAN'];
            $run('review_document', ['party_role' => $role, 'document_id' => $documentId, 'decision' => 'ACCEPTED', 'original_confirmed' => true, 'reason' => 'Original clearly legible'], $actors['review']);
        }
        $run('record_bank_verification', ['party_role' => $role, 'result' => 'PASS', 'reference' => 'bank-' . $role, 'evidence_ref' => 'verified-bank-record-' . $role], $actors['review']);
    }
    $run('submit_documents', [], $partyActors['applicant']);
    check(!Workflow::evaluate($case)['identity_kyc']['passed'], 'Document acceptance alone does not satisfy identity KYC');
    foreach (Workflow::ROLES as $role) {
        $case['parties'][$role]['kyc']['pan-advanced-v3'] = ['status' => 'verified', 'reference' => 'SYNTHETIC-KYC-' . $role, 'profile_hash' => Workflow::identity_hash($case['parties'][$role])];
    }
    check(Workflow::evaluate($case)['identity_kyc']['passed'], 'Each party requires independently verified identity evidence');
    $run('assign_officer', ['officer_id' => $ids['reviewer'], 'reason' => 'Assigned within test branch'], $actors['supervisor']);
    $run('record_bc_enrolment', ['partner' => 'Synthetic BC', 'result' => 'PENDING', 'reason' => 'Awaiting actual response', 'valid_until' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400)] + $evidence, $actors['review']);
    check(!Workflow::evaluate($case)['bc_eligibility']['passed'], 'Pending BC response is never treated as eligibility pass');
    $run('record_bc_enrolment', ['partner' => 'Synthetic BC', 'result' => 'PASS', 'reason' => 'Partner response reviewed', 'valid_until' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400)] + $evidence, $actors['review']);
    $run('schedule_counselling', ['meeting_url' => 'https://meet.google.com/abc-defg-hij', 'scheduled_at' => gmdate('Y-m-d\TH:i:s\Z'), 'reference' => 'counselling-test'], $actors['review']);
    $run('complete_counselling', ['attended_roles' => implode(',', Workflow::ROLES), 'checklist_confirmed' => true, 'notes' => 'All distinct obligations explained'] + $evidence, $actors['review']);
    check(!Workflow::evaluate($case)['counselling']['passed'], 'Officer attendance does not substitute individual acknowledgement');
    foreach (Workflow::ROLES as $role) { $run('acknowledge_counselling', ['confirmed' => true], $partyActors[$role]); }
    $terms = ['lender_beneficiary_ref' => 'verified-initial-lender-bank', 'lender_bank_evidence_ref' => 'lender-account-verification-evidence', 'lender' => 'Synthetic Lender', 'borrower_role' => 'applicant', 'beneficiary_role' => 'applicant', 'terms_version' => 'test-approved-1', 'terms_text' => 'Synthetic terms for tests only; no real lending.', 'annual_interest_bps' => 1200, 'tenure_months' => 12, 'repayment_frequency' => 'MONTHLY', 'processing_fee_paise' => 0, 'other_charges_paise' => 0, 'first_due_at' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400 * 30)];
    error_is(Workflow::apply($case, 'set_loan_terms', ['loan' => 'initial', 'amount_paise' => 999999] + $terms, $actors['review']), 'dbcl_invalid_loan_terms', 'Initial loan cannot silently change from exact INR10000');
    $signLoan = static function (string $kind, int $amount) use (&$run, &$case, $terms, $actors, $partyActors, $evidence): void {
        $run('set_loan_terms', ['loan' => $kind, 'amount_paise' => $amount] + $terms, $actors['review']);
        foreach (Workflow::ROLES as $role) {
            $run('accept_terms', ['purpose' => $kind, 'terms_version' => $terms['terms_version'], 'confirmed' => true], $partyActors[$role]);
            $run('record_signature', ['purpose' => $kind, 'party_role' => $role, 'status' => 'COMPLETED', 'terms_hash' => $case['loans'][$kind]['terms']['hash'], 'document_hash' => hash('sha256', $kind . $role . $case['loans'][$kind]['terms']['hash'])] + $evidence, $actors['operations']);
        }
        $oldTermsHash = $case['loans'][$kind]['terms']['hash'];
        $newTerms = Workflow::apply($case, 'set_loan_terms', ['loan' => $kind, 'amount_paise' => $amount, 'terms_version' => 'amended-version-2', 'terms_text' => 'Materially amended repayment terms for callback correlation test'] + $terms, $actors['review']);
        if (!success($newTerms, $kind . ': material terms amendment creates a new immutable signature target')) { return; }
        $newTerms = Workflow::apply($newTerms, 'accept_terms', ['purpose' => $kind, 'terms_version' => 'amended-version-2', 'confirmed' => true], $partyActors['applicant']);
        if (!success($newTerms, $kind . ': individual accepts new version before delayed old callback arrives')) { return; }
        $provider = $actors['operations']; $provider['provider'] = true;
        $signedOld = ['purpose' => $kind, 'party_role' => 'applicant', 'status' => 'COMPLETED', 'terms_hash' => $oldTermsHash, 'document_hash' => hash('sha256', 'old-executed-artifact')] + $evidence;
        error_is(Workflow::apply($newTerms, 'record_signature', $signedOld, $provider), 'dbcl_terms_version_conflict', $kind . ': delayed old-version signature cannot complete newly accepted terms');
        $signedNew = array_merge($signedOld, ['terms_hash' => $newTerms['loans'][$kind]['terms']['hash'], 'document_hash' => hash('sha256', 'new-executed-artifact')]);
        $currentSignature = Workflow::apply($newTerms, 'record_signature', $signedNew, $provider);
        check(!is_wp_error($currentSignature) && $currentSignature['loans'][$kind]['signatures']['applicant']['terms_hash'] === $newTerms['loans'][$kind]['terms']['hash'], $kind . ': exactly correlated current-version signature can complete');
    };
    $mandate = static function (string $kind, int $amount, string $beneficiary, string $frequency) use (&$run, &$case, $actors, $partyActors, $evidence): void {
        $run('prepare_mandate', ['purpose' => $kind, 'payer_role' => 'applicant', 'beneficiary_ref' => $beneficiary, 'amount_paise' => $amount, 'frequency' => $frequency, 'valid_from' => gmdate('Y-m-d\TH:i:s\Z', time() - 86400), 'valid_until' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400 * 365)], $actors['operations']);
        $run('accept_mandate', ['purpose' => $kind, 'mandate_id' => $case['mandates'][$kind]['id'], 'confirmed' => true], $partyActors['applicant']);
        $run('record_mandate', ['purpose' => $kind, 'mandate_id' => $case['mandates'][$kind]['id'], 'status' => 'ACTIVE'] + $evidence, $actors['operations']);
    };
    $withdrawalChecks = static function (string $kind, string $financialPurpose, int $amount) use (&$case, $actors, $partyActors, $evidence): void {
        $original = $case;
        $current = $case['mandates'][$kind];
        $request = ['purpose' => $kind, 'mandate_id' => $current['id'], 'reason' => 'Payer requests withdrawal of this separate authorization'];
        error_is(Workflow::apply($case, 'withdraw_mandate', $request, $partyActors['co_applicant']), 'dbcl_mandate_not_owned', $kind . ': unrelated party cannot withdraw payer authorization');
        error_is(Workflow::apply($case, 'withdraw_mandate', $request, $actors['operations']), 'dbcl_forbidden', $kind . ': staff cannot impersonate the payer withdrawal');
        $spoofed = $partyActors['co_applicant']; $spoofed['party_role'] = 'applicant';
        error_is(Workflow::apply($case, 'withdraw_mandate', $request, $spoofed), 'dbcl_party_session_required', $kind . ': spoofed payer role without own account is rejected');
        error_is(Workflow::apply($case, 'withdraw_mandate', array_merge($request, ['mandate_id' => wp_generate_uuid4()]), $partyActors['applicant']), 'dbcl_mandate_not_owned', $kind . ': withdrawal is bound to exact mandate ID');
        $withdrawn = Workflow::apply($case, 'withdraw_mandate', $request, $partyActors['applicant']);
        if (!success($withdrawn, $kind . ': own payer can withdraw mandate authorization')) { return; }
        $m = $withdrawn['mandates'][$kind];
        check($m['status'] === 'WITHDRAWAL_REQUESTED' && $m['provider_status'] === 'ACTIVE', $kind . ': withdrawal blocks locally without inventing provider cancellation');
        check(!empty($m['authorization_withdrawal']['requested_at']) && $m['authorization_withdrawal']['user_id'] === $partyActors['applicant']['id'] && $m['authorization_withdrawal']['reason'] === $request['reason'], $kind . ': withdrawal preserves timestamp, own actor and reason');
        check(count($m['authorization_withdrawal_history']) === 1 && $m['authorization'] === $current['authorization'], $kind . ': request history preserves prior authorization evidence');
        $gate = $kind . '_mandate';
        $gates = Workflow::evaluate($withdrawn);
        check(!$gates[$gate]['passed'] && in_array(strtoupper($kind) . '_MANDATE_AUTHORIZATION_WITHDRAWN', $gates[$gate]['blockers'], true), $kind . ': explicit withdrawal blocks authorization gate immediately');
        $legacyActive = $withdrawn; $legacyActive['mandates'][$kind]['status'] = 'ACTIVE';
        check(!Workflow::evaluate($legacyActive)[$gate]['passed'], $kind . ': withdrawal marker blocks even an out-of-order effective ACTIVE flag');
        $blocked = Workflow::apply($withdrawn, 'prepare_payment', ['purpose' => $financialPurpose, 'amount_paise' => $amount, 'beneficiary_ref' => Workflow::beneficiary_ref($withdrawn, $financialPurpose), 'idempotency_key' => 'withdrawn-' . $kind . '-instruction-key'] + $evidence, $actors['maker']);
        error_is($blocked, 'dbcl_gate_blocked', $kind . ': a new financial instruction cannot bypass payer withdrawal');
        error_is(Workflow::apply($withdrawn, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => 'ACTIVE'] + $evidence, $actors['operations']), 'dbcl_mandate_authorization_withdrawn', $kind . ': staff ACTIVE evidence cannot resurrect withdrawn authorization');
        $provider = $actors['operations']; $provider['provider'] = true;
        error_is(Workflow::apply($withdrawn, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => 'ACTIVE'] + $evidence, $provider), 'dbcl_mandate_authorization_withdrawn', $kind . ': authenticated stale provider ACTIVE result cannot resurrect withdrawal');
        error_is(Workflow::apply($withdrawn, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => 'PENDING'] + $evidence, $actors['operations']), 'dbcl_mandate_authorization_withdrawn', $kind . ': intermediate PENDING cannot reopen withdrawn mandate');
        error_is(Workflow::apply($withdrawn, 'accept_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'confirmed' => true], $partyActors['applicant']), 'dbcl_mandate_authorization_withdrawn', $kind . ': original mandate cannot silently receive replacement consent');
        $duplicate = Workflow::apply($withdrawn, 'withdraw_mandate', $request, $partyActors['applicant']);
        check($duplicate === $withdrawn, $kind . ': repeated withdrawal retains original timestamp and one history entry');
        $replacement = array_intersect_key($current, array_flip(['purpose', 'payer_role', 'beneficiary_ref', 'amount_paise', 'frequency', 'valid_from', 'valid_until']));
        error_is(Workflow::apply($withdrawn, 'prepare_mandate', $replacement, $actors['operations']), 'dbcl_active_mandate_exists', $kind . ': replacement waits for confirmed cancellation of existing external registration');
        $cancelled = Workflow::apply($withdrawn, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => 'CANCELLED'] + $evidence, $actors['operations']);
        if (!success($cancelled, $kind . ': staff can record evidence-backed cancellation confirmation')) { return; }
        check($cancelled['mandates'][$kind]['status'] === 'CANCELLED' && $cancelled['mandates'][$kind]['provider_status'] === 'CANCELLED' && !empty($cancelled['mandates'][$kind]['authorization_withdrawal']), $kind . ': provider cancellation stays distinct from prior payer request');
        $fresh = Workflow::apply($cancelled, 'prepare_mandate', $replacement, $actors['operations']);
        if (!success($fresh, $kind . ': cancellation permits a separately identified new registration')) { return; }
        $freshId = $fresh['mandates'][$kind]['id'];
        check($freshId !== $current['id'] && empty($fresh['mandates'][$kind]['authorization']) && empty($fresh['mandates'][$kind]['authorization_withdrawal']), $kind . ': replacement never inherits old authorization or withdrawal marker');
        check(end($fresh['mandate_history'][$kind])['authorization_withdrawal'] === $m['authorization_withdrawal'], $kind . ': cancelled mandate and withdrawal stay archived');
        foreach (['ACTIVE', 'CANCELLED'] as $oldStatus) {
            error_is(Workflow::apply($fresh, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => $oldStatus] + $evidence, $provider), 'dbcl_mandate_reference_conflict', $kind . ': old registration callback ' . $oldStatus . ' cannot alter its replacement');
        }
        $pendingWithdrawal = Workflow::apply($fresh, 'withdraw_mandate', ['purpose' => $kind, 'mandate_id' => $freshId, 'reason' => 'Stop this pending authorization before provider submission'], $partyActors['applicant']);
        check(!is_wp_error($pendingWithdrawal) && $pendingWithdrawal['mandates'][$kind]['status'] === 'WITHDRAWAL_REQUESTED' && $pendingWithdrawal['mandates'][$kind]['provider_status'] === 'NOT_SUBMITTED', $kind . ': pending local registration can be withdrawn without inventing a provider submission or cancellation');
        error_is(Workflow::apply($fresh, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $freshId, 'status' => 'ACTIVE'] + $evidence, $actors['operations']), 'dbcl_mandate_authorization_required', $kind . ': fresh registration cannot activate without new own-party authorization');
        error_is(Workflow::apply($fresh, 'accept_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'confirmed' => true], $partyActors['applicant']), 'dbcl_mandate_not_owned', $kind . ': old authorization reference cannot claim replacement');
        $fresh = Workflow::apply($fresh, 'accept_mandate', ['purpose' => $kind, 'mandate_id' => $freshId, 'confirmed' => true], $partyActors['applicant']);
        if (!success($fresh, $kind . ': new payer acceptance is tied to new mandate ID')) { return; }
        $fresh = Workflow::apply($fresh, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $freshId, 'status' => 'ACTIVE'] + $evidence, $actors['operations']);
        check(!is_wp_error($fresh) && Workflow::evaluate($fresh)[$gate]['passed'], $kind . ': fresh acceptance and activation restore only the new mandate gate');
        foreach (['CANCELLED', 'REJECTED', 'FAILED'] as $terminal) {
            $terminalCase = Workflow::apply($original, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => $terminal] + $evidence, $actors['operations']);
            if (!success($terminalCase, $kind . ': terminal ' . $terminal . ' evidence can be recorded')) { continue; }
            foreach (['PENDING', 'ACTIVE'] as $stale) {
                error_is(Workflow::apply($terminalCase, 'record_mandate', ['purpose' => $kind, 'mandate_id' => $current['id'], 'status' => $stale] + $evidence, $provider), 'dbcl_terminal_mandate', $kind . ': terminal ' . $terminal . ' cannot regress to ' . $stale . ' on same ID');
            }
        }
        check($case === $original, $kind . ': isolated withdrawal regression does not mutate original case by reference');
    };
    $signLoan('initial', 1000000);
    $mandate('initial', 1000000, 'Synthetic Lender', 'MONTHLY');
    $withdrawalChecks('initial', 'initial_disbursement', 1000000);
    $run('prepare_payment', $prepare, $actors['maker']);
    $initialId = $case['loans']['initial']['payment']['id'];
    $run('prepare_payment', $prepare, $actors['maker']);
    check($case['loans']['initial']['payment']['id'] === $initialId, 'Identical idempotent instruction does not create another payment');
    error_is(Workflow::apply($case, 'prepare_payment', array_merge($prepare, ['amount_paise' => 1500000]), $actors['maker']), 'dbcl_idempotency_conflict', 'Idempotency key cannot be reused for different amounts');
    $approve = ['purpose' => 'initial_disbursement', 'instruction_id' => $initialId, 'evidence_ref' => 'independent-check'];
    error_is(Workflow::apply($case, 'check_payment', $approve, $actors['maker']), 'dbcl_maker_checker_required', 'Maker cannot approve own instruction even with checker capability');
    $run('check_payment', $approve, $actors['checker']);
    $run('record_submission', ['purpose' => 'initial_disbursement', 'instruction_id' => $initialId, 'result' => 'UNKNOWN'] + $evidence, $actors['maker']);
    error_is(Workflow::apply($case, 'prepare_payment', array_merge($prepare, ['idempotency_key' => 'new-key-for-timeout']), $actors['maker']), 'dbcl_payment_in_flight', 'Unknown transfer outcome prevents blind retry');
    $settle = ['purpose' => 'initial_disbursement', 'instruction_id' => $initialId, 'result' => 'SETTLED', 'settled_at' => gmdate('Y-m-d\TH:i:s\Z'), 'amount_paise' => 1000000, 'currency' => 'INR', 'beneficiary_ref' => 'bank-applicant', 'reference' => 'initial-disbursement-utr', 'evidence_ref' => 'bank-settlement-record'];
    $inFlightWithdrawal = Workflow::apply($case, 'withdraw_mandate', ['purpose' => 'initial', 'mandate_id' => $case['mandates']['initial']['id'], 'reason' => 'Withdrawal while external transaction awaits reconciliation'], $partyActors['applicant']);
    if (success($inFlightWithdrawal, 'Payer may withdraw while an earlier payment outcome is unknown')) {
        $reconciledAfterWithdrawal = Workflow::apply($inFlightWithdrawal, 'record_settlement', $settle, $actors['checker']);
        check(!is_wp_error($reconciledAfterWithdrawal) && $reconciledAfterWithdrawal['loans']['initial']['payment']['status'] === 'SETTLED' && $reconciledAfterWithdrawal['mandates']['initial']['status'] === 'WITHDRAWAL_REQUESTED', 'Withdrawal blocks new authorization but does not suppress authoritative settlement of an existing instruction');
    }
    error_is(Workflow::apply($case, 'record_settlement', array_merge($settle, ['beneficiary_ref' => 'wrong-bank']), $actors['checker']), 'dbcl_settlement_mismatch', 'Reconciliation rejects mismatched beneficiary');
    $run('record_settlement', $settle, $actors['checker']);
    $run('record_settlement', $settle, $actors['checker']);
    check(count($case['loans']['initial']['settlements']) === 1, 'Duplicate settlement does not duplicate loan ledger');
    check($case['loans']['initial']['settlements'][0]['source'] === 'OFFICER_REPORTED', 'Manual reconciliation remains visibly officer reported');
    error_is(Workflow::apply($case, 'record_settlement', array_merge($settle, ['result' => 'FAILED']), $actors['checker']), 'dbcl_settlement_immutable', 'Settled payment cannot regress to failed');
    $settlePurpose = static function (string $purpose, int $amount, string $beneficiary, string $key) use (&$run, &$case, $actors, $evidence): void {
        $run('prepare_payment', ['purpose' => $purpose, 'amount_paise' => $amount, 'beneficiary_ref' => $beneficiary, 'idempotency_key' => $key] + $evidence, $actors['maker']);
        $record = $purpose === 'return_collection' ? $case['return_collection'] : ($purpose === 'slt_contribution' ? $case['slt'] : $case['loans'][$purpose === 'bc_disbursement' ? 'bc' : 'initial']);
        $id = $record['payment']['id'];
        $run('check_payment', ['purpose' => $purpose, 'instruction_id' => $id, 'evidence_ref' => 'independent-check'], $actors['checker']);
        $run('record_submission', ['purpose' => $purpose, 'instruction_id' => $id, 'result' => 'SUBMITTED'] + $evidence, $actors['maker']);
        $run('record_settlement', ['purpose' => $purpose, 'instruction_id' => $id, 'result' => 'SETTLED', 'settled_at' => gmdate('Y-m-d\TH:i:s\Z'), 'amount_paise' => $amount, 'currency' => 'INR', 'beneficiary_ref' => $beneficiary, 'reference' => 'utr-' . $key, 'evidence_ref' => 'bank-settlement-record'], $actors['checker']);
    };
    $run('set_return_collection', ['recipient' => 'Explicit Synthetic Return Entity', 'purpose' => 'Approved separate collection purpose', 'beneficiary_ref' => 'return-verified-bank', 'terms_version' => 'return-1', 'terms_text' => 'Separate authorized return collection', 'due_at' => gmdate('Y-m-d\TH:i:s\Z', time() - 60)] + $evidence, $actors['review']);
    $run('accept_terms', ['purpose' => 'return_collection', 'terms_version' => 'return-1', 'confirmed' => true], $partyActors['applicant']);
    $settlePurpose('return_collection', 1000000, 'return-verified-bank', 'return-collection-key');
    check($case['return_collection']['status'] === 'RECONCILED', 'Distinct INR10000 return reconciles');
    check($case['loans']['initial']['status'] !== 'CLOSED' && Workflow::settled_total($case['loans']['initial'], 'repayment') === 0, 'Third-party return never repays or closes original lender loan');
    check($case['slt']['amount_paise'] === 2500000, 'INR10000 return does not reduce INR25000 SLT obligation');
    error_is(Workflow::apply($case, 'close_initial_loan', ['lender_balance_paise' => 0] + $evidence, $actors['checker']), 'dbcl_lender_repayment_not_confirmed', 'Zero-balance assertion cannot close original loan without separate lender repayment');
    $settlePurpose('initial_repayment', 1000000, 'verified-initial-lender-bank', 'original-lender-repayment-key');
    $run('close_initial_loan', ['lender_balance_paise' => 0] + $evidence, $actors['checker']);
    check($case['loans']['initial']['status'] === 'CLOSED', 'Separate lender repayment and evidence-backed zero balance close original loan');
    $run('set_slt_terms', ['purpose' => 'Synthetic membership contribution', 'beneficiary_ref' => 'slt-verified-bank', 'payer_role' => 'applicant', 'terms_version' => 'slt-1', 'terms_text' => 'Separate INR25000 one-time contribution; conditions/refund disclosed', 'due_at' => gmdate('Y-m-d\TH:i:s\Z', time() - 60)] + $evidence, $actors['operations']);
    $run('accept_terms', ['purpose' => 'slt', 'terms_version' => 'slt-1', 'confirmed' => true], $partyActors['applicant']);
    $run('record_signature', ['purpose' => 'slt', 'party_role' => 'applicant', 'status' => 'COMPLETED', 'terms_hash' => $case['slt']['terms']['hash'], 'document_hash' => hash('sha256', 'slt-membership')] + $evidence, $actors['operations']);
    $mandate('slt', 2500000, 'slt-verified-bank', 'ONE_TIME');
    $run('record_slt_notice', ['delivered_at' => gmdate('Y-m-d\TH:i:s\Z', time() - 86400 * 2)] + $evidence, $actors['operations']);
    $sltPrepare = ['purpose' => 'slt_contribution', 'amount_paise' => 2500000, 'beneficiary_ref' => 'slt-verified-bank', 'idempotency_key' => 'slt-before-final-loan-key'] + $evidence;
    error_is(Workflow::apply($case, 'prepare_payment', $sltPrepare, $actors['maker']), 'dbcl_gate_blocked', 'Active SLT mandate cannot trigger debit before confirmed final BC disbursement');
    foreach (['fvr', 'bvr'] as $type) {
        $run('assign_verification', ['type' => $type, 'officer_id' => $ids['verifier'], 'due_at' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400), 'reason' => 'Assigned evidence checklist'], $actors['supervisor']);
        $run('record_verification', ['type' => $type, 'result' => 'FAIL', 'checklist' => 'Completed task with failed result'] + $evidence, $actors['verify']);
        check(!Workflow::evaluate($case)['verifications']['passed'], 'Completed ' . strtoupper($type) . ' with FAIL does not pass gate');
        $run('record_verification', ['type' => $type, 'result' => 'PASS', 'checklist' => 'Approved checklist satisfied'] + $evidence, $actors['verify']);
    }
    $run('open_query', ['description' => 'Synthetic blocking BC query', 'reference' => 'query-1', 'due_at' => gmdate('Y-m-d\TH:i:s\Z', time() + 86400), 'blocking' => true], $actors['review']);
    $queryId = $case['queries'][0]['id'];
    $run('respond_query', ['query_id' => $queryId, 'response' => 'Corrected evidence submitted'] + $evidence, $actors['review']);
    check(!Workflow::evaluate($case)['queries']['passed'], 'Submitted query response is not partner-confirmed closure');
    $run('close_query', ['query_id' => $queryId] + $evidence, $actors['review']);
    $signLoan('bc', 25000000);
    $mandate('bc', 25000000, 'Synthetic Lender', 'MONTHLY');
    $run('prepare_kit', $evidence, $actors['operations']);
    $run('submit_kit', $evidence, $actors['operations']);
    check(!Workflow::evaluate($case)['db_kit']['passed'], 'Submitted DB kit is not treated as accepted');
    $run('accept_kit', $evidence, $actors['operations']);
    check(Workflow::evaluate($case)['db_kit']['passed'], 'Exact immutable DB kit accepted');
    $withdrawalChecks('bc', 'bc_disbursement', 25000000);
    $changed = $case;
    $changed['parties']['applicant']['profile']['legal_name'] = 'Changed Identity';
    check(!Workflow::evaluate($changed)['db_kit']['passed'], 'Material identity change invalidates accepted DB kit snapshot');
    $changed = $case;
    $changed['parties']['applicant']['bank']['account_number'] = '99999999999';
    check(!Workflow::bank_verified($changed['parties']['applicant']['bank']), 'Changed bank details invalidate previous verification hash');
    $settlePurpose('bc_disbursement', 25000000, 'bank-applicant', 'final-bc-disbursement-key');
    check(Workflow::evaluate($case)['bc_disbursement']['passed'], 'Final BC loan settlement confirmed independently');
    $withdrawalChecks('slt', 'slt_contribution', 2500000);
    $settlePurpose('slt_contribution', 2500000, 'slt-verified-bank', 'slt-one-time-contribution-key');
    check($case['slt']['ever_collected'] === true && Workflow::settled_total($case['slt']) === 2500000, 'One exact INR25000 SLT contribution settles after BC disbursement');
    $retry = Workflow::apply($case, 'prepare_payment', array_merge($sltPrepare, ['idempotency_key' => 'new-slt-key-after-settlement']), $actors['maker']);
    check(is_wp_error($retry), 'New idempotency key cannot collect a second successful SLT contribution');
    check(Workflow::settled_total($case['return_collection']) === 1000000 && Workflow::settled_total($case['slt']) === 2500000, 'Return and SLT ledgers remain exact separate INR10000 and INR25000');
    foreach (['initial', 'bc', 'slt'] as $purpose) {
        $afterSettlement = Workflow::apply($case, 'withdraw_mandate', ['purpose' => $purpose, 'mandate_id' => $case['mandates'][$purpose]['id'], 'reason' => 'Stop any future use after the completed financial events'], $partyActors['applicant']);
        if (!success($afterSettlement, $purpose . ': mandate withdrawal remains available after financial settlement')) { continue; }
        check($afterSettlement['loans'] === $case['loans'] && $afterSettlement['return_collection'] === $case['return_collection'] && $afterSettlement['slt'] === $case['slt'] && $afterSettlement['receipts'] === $case['receipts'], $purpose . ': authorization withdrawal never regresses settled ledgers, lender closure or historical receipts');
    }
    $sandbox = $case;
    $sandbox['policy']['surepass_environment'] = 'sandbox';
    foreach (Workflow::ROLES as $role) {
        $sandbox['parties'][$role]['kyc']['pan-advanced-v3']['environment'] = 'sandbox';
        $sandbox['parties'][$role]['bank']['verification']['environment'] = 'sandbox';
        $sandbox['parties'][$role]['bank']['verification']['source'] = 'PROVIDER_CONFIRMED';
    }
    check(Workflow::evaluate($sandbox)['identity_kyc']['passed'] && Workflow::evaluate($sandbox)['initial_documentation']['passed'], 'Sandbox identity and bank evidence can validate a clearly sandbox UAT case');
    $production = $sandbox;
    $production['policy']['surepass_environment'] = 'production';
    check(!Workflow::evaluate($production)['identity_kyc']['passed'], 'Production identity gate rejects otherwise verified sandbox results for every party');
    check(!Workflow::evaluate($production)['initial_documentation']['passed'] && !Workflow::evaluate($production)['initial_mandate']['passed'], 'Production loan and mandate gates reject sandbox bank ownership evidence');
    foreach (Workflow::ROLES as $role) {
        $production['parties'][$role]['kyc']['pan-advanced-v3']['environment'] = 'production';
    }
    check(Workflow::evaluate($production)['identity_kyc']['passed'], 'Production identity results meet production gate when their current profile hashes and references match');
    foreach (Workflow::ROLES as $role) {
        $production['parties'][$role]['bank']['verification']['environment'] = 'production';
    }
    check(Workflow::evaluate($production)['initial_documentation']['passed'] && Workflow::evaluate($production)['initial_mandate']['passed'], 'Production bank ownership evidence restores loan and purpose-bound mandate gates');
    $untagged = $production;
    unset($untagged['parties']['applicant']['kyc']['pan-advanced-v3']['environment'], $untagged['parties']['applicant']['bank']['verification']['environment']);
    check(!Workflow::evaluate($untagged)['identity_kyc']['passed'] && !Workflow::evaluate($untagged)['initial_documentation']['passed'], 'Legacy untagged verification evidence cannot silently become production evidence');
    $manualBank = $sandbox['parties']['applicant']['bank'];
    $manualBank['verification']['source'] = 'OFFICER_REPORTED';
    $manualBank['verification']['evidence_ref'] = 'independently-reviewed-authoritative-bank-record';
    check(Workflow::bank_verified($manualBank, $production['policy']) && $manualBank['verification']['source'] === 'OFFICER_REPORTED' && $manualBank['verification']['environment'] === 'sandbox', 'Explicit approved manual bank review can satisfy policy while retaining honest source and original environment');
    $noManualPolicy = $production['policy']; $noManualPolicy['allow_manual_evidence'] = false;
    check(!Workflow::bank_verified($manualBank, $noManualPolicy), 'Production manual bank exception requires the approved manual-evidence policy');
    unset($manualBank['verification']['evidence_ref']);
    check(!Workflow::bank_verified($manualBank, $production['policy']), 'Manual source label without authoritative evidence cannot bypass the production bank guard');
}
