<?php
/** Run separately against the disposable WordPress fixture; uses only a local delivery mock. */
require __DIR__ . '/bootstrap.php';

use DigitalBE\ClientGroupLoans\Notifications;
use DigitalBE\ClientGroupLoans\Store;
use DigitalBE\ClientGroupLoans\Workflow;

$checks = 0;
$failures = [];
$users = [];
$cases = [];
$prefix = 'dbclnotice_' . bin2hex(random_bytes(5));
$testSettings = ['notifications_enabled' => false, 'sla_hours' => 48, 'require_staff_mfa' => false];
$settingsFilter = static function () use (&$testSettings) { return $testSettings; };
add_filter('pre_option_dbcl_settings', $settingsFilter);
$networkFilter = static fn() => new WP_Error('dbcl_test_offline', 'External delivery is disabled in these tests.');
add_filter('pre_http_request', $networkFilter, 1);
function ncheck(bool $condition, string $label): void {
    global $checks, $failures;
    $checks++;
    if (!$condition) { $failures[] = $label; fwrite(STDERR, "FAIL $label\n"); }
}
function nrequest(string $method, string $path, array $data = []): WP_REST_Response {
    $request = new WP_REST_Request($method, '/digitalbe-loans/v1' . $path);
    if ($data) { $request->set_header('Content-Type', 'application/json'); $request->set_body(wp_json_encode($data)); }
    return rest_do_request($request);
}
$newUser = static function (string $role = 'subscriber', int $org = 87654) use (&$users, $prefix): int {
    $login = $prefix . '_' . count($users);
    $id = wp_insert_user(['user_login' => $login, 'user_pass' => bin2hex(random_bytes(24)), 'user_email' => $login . '@example.invalid', 'role' => $role]);
    if (is_wp_error($id)) { throw new RuntimeException('Could not create a synthetic notification test user.'); }
    update_user_meta($id, 'dbcl_org_id', $org);
    $users[] = $id;
    return $id;
};
$newCase = static function (int $owner, int $other, int $staff) use (&$cases): array {
    $case = Workflow::initial(['org_id' => 87654, 'branch' => 'notice-test', 'loan_purpose' => 'Synthetic notification test'], $owner);
    $case['org_id'] = 87654;
    $case['owner_id'] = $owner;
    $case['assigned_id'] = $staff;
    $case['parties']['applicant']['user_id'] = $owner;
    $case['parties']['applicant']['consents']['communications'] = ['accepted' => true];
    $case['parties']['co_applicant']['user_id'] = $other;
    $case['parties']['co_applicant']['consents']['communications'] = ['accepted' => false];
    $case['internal_notes'] = 'Secret internal risk thresholds must never enter customer notices.';
    $case = Notifications::append($case, 'application_created');
    $case = Store::create($case);
    if (is_wp_error($case)) { throw new RuntimeException('Could not store a synthetic notification test case.'); }
    $cases[] = $case['id'];
    return $case;
};
$deliver = new ReflectionMethod(Notifications::class, 'deliver');
$deliver->setAccessible(true);
$mockCalls = 0;
$seenProcessing = false;
$lastPayload = [];
$mode = 'delivered';
$adapter = static function ($unused, array $notice, array $context) use (&$mockCalls, &$seenProcessing, &$lastPayload, &$mode) {
    $mockCalls++;
    $lastPayload = $notice;
    $current = Store::get($notice['application_id']);
    $seenProcessing = !is_wp_error($current) && ($current['notifications'][$notice['id']]['delivery']['state'] ?? '') === 'PROCESSING';
    ncheck(($context['idempotency_key'] ?? '') === $notice['id'], 'Adapter gets stable notification idempotency key');
    if ($mode === 'throw') { throw new RuntimeException('Synthetic uncertain timeout; must not be retried.'); }
    if ($mode === 'pending') { return ['status' => 'ACCEPTED']; }
    if ($mode === 'failed') { return ['status' => 'FAILED']; }
    return ['status' => 'DELIVERED', 'reference' => 'synthetic-local-mock'];
};

try {
    $owner = $newUser();
    $other = $newUser();
    $staff = $newUser('dbcl_credit_officer');
    $outsider = $newUser();
    $foreign = $newUser('subscriber', 87655);
    wp_set_current_user($owner);
    $case = $newCase($owner, $other, $staff);
    $id = $case['id'];
    $noticeId = array_key_first($case['notifications']);
    ncheck(count($case['notifications']) === 1, 'Initial stage creates one in-app notice');
    ncheck($case['notifications'][$noticeId]['delivery']['state'] === 'DISABLED', 'External channels disabled by default');
    ncheck(count(Notifications::append($case, 'profile_updated')['notifications']) === 1, 'Unchanged stage and exception create no duplicate notice');
    $earlier = gmdate('c', time() - 49 * HOUR_IN_SECONDS);
    $case['notification_state']['stage_entered_at'] = $earlier;
    ncheck(Notifications::append($case, 'profile_updated')['notification_state']['stage_entered_at'] === $earlier, 'Unrelated profile update preserves stage SLA origin');
    $case['stage'] = 'BC_RESPONSE_PENDING';
    $case = Notifications::append($case, 'bc_result');
    ncheck(count($case['notifications']) === 2, 'Stage transition appends a notice');
    ncheck($case['notification_state']['stage_entered_at'] !== $earlier, 'Actual stage transition resets SLA origin');
    ncheck(count(Notifications::append($case, 'bc_result')['notifications']) === 2, 'Repeated append is deduplicated');
    $case['exception'] = ['status' => 'HOLD', 'reason' => 'Private risk threshold'];
    $case = Notifications::append($case, 'hold');
    ncheck(!str_contains(wp_json_encode($case['notifications']), 'Private risk threshold') && !str_contains(wp_json_encode($case['notifications']), 'Secret internal'), 'Notices do not copy internal notes or exception reasons');
    $case = Store::save($case, $case['version'], $owner, 'test_notices');
    if (is_wp_error($case)) { throw new RuntimeException('Could not store synthetic notices.'); }

    $response = nrequest('GET', '/applications/' . $id . '/notifications');
    $visible = $response->get_data();
    ncheck($response->get_status() === 200 && $visible['unread_count'] === 3, 'Own party can list their in-app notices');
    ncheck(!isset($visible['notifications'][0]['recipients']) && !isset($visible['notifications'][0]['read_by']), 'Notification response hides other recipients and read states');
    $response = nrequest('POST', '/notifications/' . $noticeId . '/read', ['application_id' => $id, 'expected_version' => $case['version']]);
    $readView = $response->get_data();
    ncheck($response->get_status() === 200 && $readView['unread_count'] === 2, 'Own notice read acknowledgement saved');
    $mine = array_values(array_filter($readView['notifications'], static fn($n) => $n['id'] === $noticeId))[0];
    ncheck($mine['read'] === true && is_string($mine['read_at']), 'Read response carries individual acknowledgement timestamp');
    $replay = nrequest('POST', '/notifications/' . $noticeId . '/read', ['application_id' => $id, 'expected_version' => $case['version']]);
    ncheck($replay->get_status() === 200 && $replay->get_data()['version'] === $readView['version'], 'Read replay is idempotent despite original stale version');
    $another = $visible['notifications'][0]['id'] === $noticeId ? $visible['notifications'][1]['id'] : $visible['notifications'][0]['id'];
    $stale = nrequest('POST', '/notifications/' . $another . '/read', ['application_id' => $id, 'expected_version' => $case['version']]);
    ncheck($stale->get_status() === 409, 'Unread acknowledgement requires current record version');
    wp_set_current_user($other);
    $response = nrequest('GET', '/applications/' . $id . '/notifications');
    ncheck($response->get_status() === 200 && $response->get_data()['unread_count'] === 3, 'One party reading does not read another party notices');
    wp_set_current_user($staff);
    ncheck(nrequest('GET', '/applications/' . $id . '/notifications')->get_status() === 200, 'Assigned staff can list their notices');
    wp_set_current_user($outsider);
    ncheck(nrequest('GET', '/applications/' . $id . '/notifications')->get_status() === 403, 'Unrelated account cannot list notices');
    ncheck(nrequest('POST', '/notifications/' . $noticeId . '/read', ['application_id' => $id, 'expected_version' => 999])->get_status() === 403, 'Unrelated account cannot acknowledge notices');
    wp_set_current_user($foreign);
    ncheck(nrequest('GET', '/applications/' . $id . '/notifications')->get_status() === 403, 'Cross-organization account cannot read notices');
    wp_set_current_user(0);
    ncheck(nrequest('GET', '/applications/' . $id . '/notifications')->get_status() === 401, 'Unauthenticated notice access denied');

    // Only this fixture is made old; external delivery remains disabled during global cron scan.
    global $wpdb;
    $case = Store::get($id);
    $case['exception'] = null;
    $case['notification_state']['stage_entered_at'] = gmdate('c', time() - 49 * HOUR_IN_SECONDS);
    $case = Store::save($case, $case['version'], $owner, 'test_clear_hold');
    ncheck(time() - strtotime(Store::get($id)['updated_at'] . ' UTC') < 60, 'Recent unrelated mutation does not conceal overdue stage');
    $before = count($case['notifications']);
    Notifications::run_reminders(gmdate('c'));
    $case = Store::get($id);
    ncheck(count($case['notifications']) === $before + 1 && !empty($case['last_reminder_at']), 'SLA cron creates overdue in-app reminder');
    Notifications::run_reminders(gmdate('c'));
    ncheck(count(Store::get($id)['notifications']) === $before + 1, 'Repeated cron does not duplicate SLA reminder');
    $case = Store::get($id);$case['stage'] = 'COMPLETED';
    $case = Store::save($case, $case['version'], $owner, 'test_complete');
    $wpdb->update($wpdb->prefix . 'dbcl_applications', ['updated_at' => gmdate('Y-m-d H:i:s', time() - 100 * HOUR_IN_SECONDS)], ['id' => $id]);
    Notifications::run_reminders(gmdate('c'));
    ncheck(count(Store::get($id)['notifications']) === $before + 1, 'Completed case gets no SLA reminder');
    ncheck($mockCalls === 0, 'Default reminders never invoke an external adapter');

    add_filter('dbcl_deliver_notification', $adapter, 10, 3);
    $testSettings['notifications_enabled'] = true;
    $case = $newCase($owner, $other, $staff);
    $sendId = $case['id'];$sendNoticeId = array_key_first($case['notifications']);
    ncheck($case['notifications'][$sendNoticeId]['delivery']['state'] === 'PENDING', 'Explicitly enabled configured adapter creates pending delivery');
    $deliver->invoke(null, $sendId, $testSettings, time());
    $case = Store::get($sendId);
    ncheck($mockCalls === 1 && $seenProcessing, 'Adapter runs only after durable PROCESSING claim');
    ncheck($case['notifications'][$sendNoticeId]['delivery']['state'] === 'DELIVERED', 'Confirmed local mock result durably recorded');
    ncheck(in_array($owner, $lastPayload['recipients'], true) && in_array($staff, $lastPayload['recipients'], true) && !in_array($other, $lastPayload['recipients'], true), 'External recipients require party communications consent or current staff assignment');
    wp_set_current_user($other);
    $response = nrequest('GET', '/applications/' . $sendId . '/notifications');
    ncheck($response->get_data()['notifications'][0]['external_delivery_state'] === 'DISABLED', 'Unconsented party does not see delivery to someone else as their delivery');
    $deliver->invoke(null, $sendId, $testSettings, time());
    ncheck($mockCalls === 1, 'Completed delivery is not resent on restart');

    $mode = 'throw';$case['stage'] = 'COUNSELLING_PENDING';$case = Notifications::append($case, 'test_exception');
    $case = Store::save($case, $case['version'], $owner, 'test_exception');$exceptionId = array_key_last($case['notifications']);
    $deliver->invoke(null, $sendId, $testSettings, time());
    $case = Store::get($sendId);
    ncheck($case['notifications'][$exceptionId]['delivery']['state'] === 'UNKNOWN', 'Uncertain adapter exception recorded UNKNOWN');
    $calls = $mockCalls;$deliver->invoke(null, $sendId, $testSettings, time());
    ncheck($mockCalls === $calls, 'Unknown delivery never blindly retried');

    $mode = 'pending';$case['stage'] = 'INITIAL_DOCUMENTATION_PENDING';$case = Notifications::append($case, 'test_accepted');
    $case = Store::save($case, $case['version'], $owner, 'test_accepted');$acceptedId = array_key_last($case['notifications']);
    $deliver->invoke(null, $sendId, $testSettings, time());$case = Store::get($sendId);
    ncheck($case['notifications'][$acceptedId]['delivery']['state'] === 'UNKNOWN', 'Provider acceptance alone is never delivery confirmation');

    $mode = 'delivered';$case['stage'] = 'INITIAL_MANDATE_PENDING';$case = Notifications::append($case, 'test_crash');
    $crashId = array_key_last($case['notifications']);
    $case['notifications'][$crashId]['delivery'] = array_merge($case['notifications'][$crashId]['delivery'], ['state' => 'PROCESSING', 'attempted_at' => gmdate('c', time() - 600), 'attempt_id' => wp_generate_uuid4()]);
    $case = Store::save($case, $case['version'], $owner, 'test_crash');$calls = $mockCalls;
    $deliver->invoke(null, $sendId, $testSettings, time());$case = Store::get($sendId);
    ncheck($case['notifications'][$crashId]['delivery']['state'] === 'UNKNOWN' && $mockCalls === $calls, 'Stale PROCESSING crash becomes UNKNOWN without a send');

    $mode = 'failed';$case['stage'] = 'INITIAL_DISBURSEMENT_PENDING';$case = Notifications::append($case, 'test_confirmed_failure');
    $case = Store::save($case, $case['version'], $owner, 'test_confirmed_failure');$failedId = array_key_last($case['notifications']);
    $deliver->invoke(null, $sendId, $testSettings, time());$case = Store::get($sendId);
    ncheck($case['notifications'][$failedId]['delivery']['state'] === 'FAILED', 'Confirmed adapter failure durably recorded as FAILED');
    $calls = $mockCalls;$deliver->invoke(null, $sendId, $testSettings, time());
    ncheck($mockCalls === $calls, 'Confirmed failure requires explicit reconciliation or supported retry');

    // Pending notice loses all currently authorized recipients before the cron delivery claim.
    $case['stage'] = 'RETURN_COLLECTION_PENDING';$case = Notifications::append($case, 'test_withdrawal');
    $withdrawId = array_key_last($case['notifications']);
    $case['assigned_id'] = 0;
    $case['parties']['applicant']['consents']['communications']['accepted'] = false;
    $case = Store::save($case, $case['version'], $owner, 'test_withdrawal');$calls = $mockCalls;
    $deliver->invoke(null, $sendId, $testSettings, time());$case = Store::get($sendId);
    ncheck($case['notifications'][$withdrawId]['delivery']['state'] === 'DISABLED' && $mockCalls === $calls, 'Consent withdrawal and staff reassignment rechecked before send');
} catch (Throwable $e) {
    $failures[] = 'Unexpected notification test exception: ' . $e->getMessage();
    fwrite(STDERR, end($failures) . "\n" . $e->getTraceAsString() . "\n");
} finally {
    remove_filter('dbcl_deliver_notification', $adapter, 10);
    remove_filter('pre_option_dbcl_settings', $settingsFilter);
    remove_filter('pre_http_request', $networkFilter, 1);
    wp_set_current_user(0);
    global $wpdb;
    foreach ($cases as $id) {
        foreach (['members', 'events', 'applications'] as $table) { $wpdb->delete($wpdb->prefix . 'dbcl_' . $table, [$table === 'applications' ? 'id' : 'application_id' => $id]); }
    }
    foreach ($users as $id) { wp_delete_user($id); }
}
printf("%d notification assertions executed; %d failures.\n", $checks, count($failures));
exit($failures ? 1 : 0);
