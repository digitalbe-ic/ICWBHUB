<?php
/** Storage metadata-transplant regressions; use a disposable WordPress database. */
require __DIR__ . '/bootstrap.php';
use DigitalBE\ClientGroupLoans\Crypto;
use DigitalBE\ClientGroupLoans\Store;

$assertions = 0;
$failures = [];
$ids = [];
$fileIds = [];
$tmp = null;
function scheck(bool $okay, string $label): void {
    global $assertions, $failures;
    $assertions++;
    if (!$okay) { $failures[] = $label; fwrite(STDERR, "FAIL $label\n"); }
}
function storage_error($value, string $code): bool { return is_wp_error($value) && $value->get_error_code() === $code; }
try {
    global $wpdb;
    foreach ([1, 2] as $number) {
        $case = Store::create(['id' => wp_generate_uuid4(), 'org_id' => 98765, 'branch' => 'integrity-test', 'owner_id' => 98700 + $number, 'assigned_id' => 0, 'parties' => ['applicant' => ['id' => wp_generate_uuid4(), 'user_id' => 98700 + $number]]]);
        if (is_wp_error($case)) { throw new RuntimeException('Unable to create encrypted storage fixture.'); }
        $ids[] = $case['id'];
        $cases[] = $case;
    }
    $table = $wpdb->prefix . 'dbcl_applications';
    $original = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $table . ' WHERE id=%s', $ids[0]), ARRAY_A);
    $otherData = $wpdb->get_var($wpdb->prepare('SELECT data FROM ' . $table . ' WHERE id=%s', $ids[1]));
    $wpdb->update($table, ['data' => $otherData], ['id' => $ids[0]]);
    scheck(storage_error(Store::get($ids[0]), 'dbcl_corrupt_state'), 'Application ciphertext transplant is rejected');
    $wpdb->update($table, ['data' => $original['data']], ['id' => $ids[0]]);
    foreach (['org_id' => 99999, 'owner_id' => 99999, 'assigned_id' => 99999, 'branch' => 'tampered-branch', 'version' => 99999] as $field => $value) {
        $wpdb->update($table, [$field => $value], ['id' => $ids[0]]);
        scheck(storage_error(Store::get($ids[0]), 'dbcl_corrupt_state'), 'Encrypted application metadata binds ' . $field);
        $wpdb->update($table, [$field => $original[$field]], ['id' => $ids[0]]);
    }
    scheck(!is_wp_error(Store::get($ids[0])), 'Restored original metadata decrypts normally');

    $tmp = tempnam(sys_get_temp_dir(), 'dbcl-integrity-');
    $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j2lUAAAAASUVORK5CYII=');
    file_put_contents($tmp, $png);
    foreach ($cases as $case) {
        $file = Store::store_file($case['id'], $case['parties']['applicant']['id'], 'live_photo', $tmp, 'image/png');
        if (is_wp_error($file)) { throw new RuntimeException('Unable to store private file fixture.'); }
        $fileIds[] = $file['id'];
    }
    scheck(Store::read_file($fileIds[0])['bytes'] === $png, 'Context-bound private file decrypts unchanged');
    $fileTable = $wpdb->prefix . 'dbcl_files';
    $record = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $fileTable . ' WHERE id=%s', $fileIds[0]), ARRAY_A);
    $other = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $fileTable . ' WHERE id=%s', $fileIds[1]), ARRAY_A);
    foreach (['application_id' => $ids[1], 'party_id' => wp_generate_uuid4(), 'document_type' => 'aadhaar_front', 'mime' => 'application/pdf', 'size' => 1, 'sha256' => hash('sha256', 'tampered')] as $field => $value) {
        $wpdb->update($fileTable, [$field => $value], ['id' => $fileIds[0]]);
        scheck(storage_error(Store::read_file($fileIds[0]), 'dbcl_file_integrity'), 'Encrypted file metadata binds ' . $field);
        $wpdb->update($fileTable, [$field => $record[$field]], ['id' => $fileIds[0]]);
    }
    $wpdb->update($fileTable, ['path' => $other['path'], 'sha256' => $other['sha256'], 'size' => $other['size']], ['id' => $fileIds[0]]);
    scheck(storage_error(Store::read_file($fileIds[0]), 'dbcl_file_integrity'), 'File ciphertext plus public hash transplant is rejected');
    $wpdb->update($fileTable, ['path' => $record['path'], 'sha256' => $record['sha256'], 'size' => $record['size']], ['id' => $fileIds[0]]);
    $method = new ReflectionMethod(Store::class, 'private_dir');
    $method->setAccessible(true);
    $directory = $method->invoke(null);
    if (is_wp_error($directory)) { throw new RuntimeException('Private directory unavailable.'); }
    $path = $directory . '/' . $record['path'];
    $boundCiphertext = file_get_contents($path);
    file_put_contents($path, Crypto::encrypt($png));
    scheck(storage_error(Store::read_file($fileIds[0]), 'dbcl_file_format'), 'Legacy unbound file format fails closed without unsafe fallback');
    file_put_contents($path, $boundCiphertext);
    scheck(Store::read_file($fileIds[0])['bytes'] === $png, 'Original bound file remains readable after restoration');
} catch (Throwable $e) {
    $failures[] = 'Unexpected storage integrity exception: ' . $e->getMessage();
    fwrite(STDERR, end($failures) . "\n");
} finally {
    global $wpdb;
    if ($tmp && is_file($tmp)) { unlink($tmp); }
    $method = new ReflectionMethod(Store::class, 'private_dir');$method->setAccessible(true);$directory = $method->invoke(null);
    foreach ($fileIds as $fileId) {
        $filename = $wpdb->get_var($wpdb->prepare('SELECT path FROM ' . $wpdb->prefix . 'dbcl_files WHERE id=%s', $fileId));
        if (!is_wp_error($directory) && is_string($filename) && preg_match('/^[a-f0-9]{48}\.enc$/D', $filename)) { @unlink($directory . '/' . $filename); }
    }
    foreach ($ids as $id) { foreach (['members', 'events', 'files', 'applications'] as $name) { $wpdb->delete($wpdb->prefix . 'dbcl_' . $name, [$name === 'applications' ? 'id' : 'application_id' => $id]); } }
}
printf("%d storage integrity assertions executed; %d failures.\n", $assertions, count($failures));
exit($failures ? 1 : 0);
