<?php
use DigitalBE\ClientGroupLoans\Documents;

/** Finance/date and document-security invariants, called by integration.php. */
function dbcl_document_tests(): void
{
    $terms = ['amount_paise' => 1000000, 'tenure_months' => 12, 'annual_rate' => 24, 'frequency' => 'monthly', 'first_due_date' => '2027-01-31', 'disbursement_date' => '2026-12-31'];
    $schedule = Documents::schedule($terms);
    check(count($schedule) === 12, 'documents: monthly instalment count');
    check(array_sum(array_column($schedule, 'principal_paise')) === 1000000, 'documents: exact principal reconciliation');
    check($schedule[11]['closing_paise'] === 0, 'documents: zero closing balance');
    check($schedule[1]['due_date'] === '2027-02-28' && $schedule[2]['due_date'] === '2027-03-31', 'documents: short month does not drift payment anchor');
    check(Documents::apr($terms, $schedule) > 26 && Documents::apr($terms, $schedule) < 28, 'documents: effective APR reflects compounding and actual dates');
    $withFees = $terms + ['processing_fee_paise' => 30000, 'tax_paise' => 5400];
    check(Documents::apr($withFees, $schedule) > Documents::apr($terms, $schedule), 'documents: upfront fees increase effective APR');
    $zeroRate = array_replace($terms, ['annual_rate' => 0]);
    $zeroSchedule = Documents::schedule($zeroRate);
    check(array_sum(array_column($zeroSchedule, 'interest_paise')) === 0, 'documents: zero-rate loan has no interest');
    check(abs(Documents::apr($zeroRate, $zeroSchedule)) < 0.00001, 'documents: zero-rate/no-fee loan has zero APR');
    $semi = array_replace($terms, ['frequency' => 'semi_monthly', 'first_due_date' => '2027-01-15']);
    $semiSchedule = Documents::schedule($semi);
    check(count($semiSchedule) === 24 && $semiSchedule[1]['due_date'] === '2027-02-01' && $semiSchedule[2]['due_date'] === '2027-02-15', 'documents: semi-monthly dates follow configured anchors');
    check(array_sum(array_column($semiSchedule, 'principal_paise')) === 1000000, 'documents: semi-monthly principal reconciles');
    foreach ([['tenure_months' => -2], ['amount_paise' => -1], ['amount_paise' => 1.5], ['first_due_date' => '2027-02-30'], ['frequency' => 'weekly']] as $change) {
        $rejected = false;
        try {
            Documents::schedule(array_replace($terms, $change));
        } catch (InvalidArgumentException $error) {
            $rejected = true;
        }
        check($rejected, 'documents: reject malformed financial term ' . array_key_first($change));
    }
    $case = ['id' => 'A<script>bad</script>', 'group_id' => 'G1', 'parties' => ['applicant' => ['id' => 'P1', 'profile' => ['legal_name' => '<script>NAME</script>', 'pan' => 'ABCDE1234F', 'aadhaar_last4' => '1234'], 'bank' => ['account_number' => '123456789012']]], 'loans' => ['bc' => ['amount_paise' => 1000000, 'terms' => $terms]]];
    $html = Documents::render('application', $case);
    check(strpos($html, '<script>') === false && strpos($html, '&lt;script&gt;') !== false, 'documents: application-controlled HTML is escaped');
    check(strpos($html, 'ABCDE1234F') === false && strpos($html, '123456789012') === false, 'documents: PAN and bank numbers are masked');
    check(strpos($html, 'DRAFT') !== false, 'documents: unapproved templates stay draft');
    foreach (['application', 'sanction', 'kfs', 'agreement', 'dpn', 'indemnity', 'membership', 'receipt', 'db_kit', 'initial_kfs'] as $type) {
        $snapshot = Documents::snapshot($type, $case);
        check(strlen($snapshot['sha256']) === 64 && hash('sha256', $snapshot['html']) === $snapshot['sha256'], 'documents: immutable content hash for ' . $type);
    }
    check(Documents::snapshot('receipt', $case)['status'] === 'draft', 'documents: no receipt without settlement');
    $receipt = ['status' => 'CONFIRMED', 'amount_paise' => 2500000, 'settlement_reference' => 'SYNTHETIC-UTR', 'settled_at' => '2026-12-31T00:00:00Z', 'obligation_id' => 'SLT1', 'recipient_name' => 'Shubh Labh Trust'];
    check(Documents::snapshot('receipt', $case, ['receipt' => $receipt])['status'] === 'ready_for_execution', 'documents: settlement supports a receipt');
    $receipt['status'] = 'SUBMITTED';
    check(Documents::snapshot('receipt', $case, ['receipt' => $receipt])['status'] === 'draft', 'documents: submission acknowledgement cannot support receipt');
    $membership = Documents::render('membership', $case);
    check(strpos($membership, 'INR 25,000.00') !== false && strpos($membership, 'INR 10,000.00') !== false, 'documents: membership keeps financial obligations separate');
    check(count(Documents::schema()['roles']) === 4 && count(Documents::schema()['documents']) === 8, 'documents: four parties and complete document checklist');

    // The workflow stores approved commercial fields in metadata, not at the document root.
    $case['loans']['bc'] = ['amount_paise' => 1000000, 'lender' => 'Synthetic Lender', 'net_disbursement_paise' => 970000, 'terms' => ['version' => 'v1', 'metadata' => ['annual_interest_bps' => 2400, 'tenure_months' => 12, 'repayment_frequency' => 'MONTHLY', 'first_due_at' => '2027-01-31T00:00:00Z', 'processing_fee_paise' => 30000, 'expected_disbursement_at' => '2026-12-31T00:00:00Z']]];
    $html = Documents::render('kfs', $case);
    check(strpos($html, 'Synthetic Lender') !== false && strpos($html, '2027-02-28') !== false, 'documents: workflow commercial metadata maps to KFS');
    check(strpos($html, 'INR 9,700.00') !== false, 'documents: KFS uses actual disclosed net disbursal');
    check(Documents::snapshot('kfs', $case)['terms_version'] === 'v1', 'documents: snapshot binds workflow terms version');
}
