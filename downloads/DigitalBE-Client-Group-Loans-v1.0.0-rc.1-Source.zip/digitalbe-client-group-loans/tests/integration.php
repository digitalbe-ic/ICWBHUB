<?php
require __DIR__ . '/bootstrap.php';

use DigitalBE\ClientGroupLoans\Auth;
use DigitalBE\ClientGroupLoans\Crypto;
use DigitalBE\ClientGroupLoans\Store;
use DigitalBE\ClientGroupLoans\Workflow;
use DigitalBE\ClientGroupLoans\Providers;

$assertions = 0;
$failures = [];
$users = [];
$applications = [];
$testPrefix = 'dbcltest_' . bin2hex(random_bytes(4));
function check(bool $condition, string $label): void {
    global $assertions, $failures;
    $assertions++;
    if (!$condition) { $failures[] = $label; fwrite(STDERR, "FAIL: $label\n"); }
}
function success($value, string $label): bool {
    $okay = !is_wp_error($value);
    check($okay, $label . ($okay ? '' : ' [' . $value->get_error_code() . ']'));
    return $okay;
}
function error_is($value, string $code, string $label): void {
    check(is_wp_error($value) && $value->get_error_code() === $code, $label);
}
function make_user(string $role = 'subscriber', int $org = 1, string $branch = ''): int {
    global $users, $testPrefix;
    $name = $testPrefix . '_' . count($users);
    $id = wp_insert_user(['user_login' => $name, 'user_pass' => bin2hex(random_bytes(24)), 'user_email' => $name . '@example.invalid', 'role' => $role]);
    if (is_wp_error($id)) { throw new RuntimeException('Unable to create synthetic test user.'); }
    $users[] = $id;
    update_user_meta($id, 'dbcl_org_id', $org);
    if ($branch !== '') { update_user_meta($id, 'dbcl_branch', $branch); }
    return $id;
}
function basic_case(int $owner, int $org = 1): array {
    $case = Workflow::initial(['branch' => 'branch-a', 'org_id' => $org, 'purpose' => 'Synthetic integration test', 'requested_amount_paise' => 25000000], $owner);
    $case['org_id'] = $org;
    $case['owner_id'] = $owner;
    $case['branch'] = 'branch-a';
    $case['parties']['applicant']['user_id'] = $owner;
    $case['parties']['applicant']['profile']['legal_name'] = 'Synthetic Applicant';
    $case['parties']['applicant']['profile']['pan'] = 'ABCDE1234F';
    $case['parties']['applicant']['bank']['account_number'] = '123456789012';
    return $case;
}
function api(string $method, string $path, array $body = []): WP_REST_Response {
    $request = new WP_REST_Request($method, '/digitalbe-loans/v1' . $path);
    if ($body) { $request->set_header('Content-Type', 'application/json'); $request->set_body(wp_json_encode($body)); }
    return rest_do_request($request);
}
// Every unexpected HTTP request fails locally. Individual provider tests override this interceptor.
add_filter('pre_http_request', static function () { return new WP_Error('dbcl_test_network_disabled', 'External network disabled during tests.'); }, 1);
$oldSettings = get_option('dbcl_settings', null);
update_option('dbcl_settings', ['require_staff_mfa' => false]);

try {
    $owner = make_user();
    $other = make_user();
    $foreign = make_user('subscriber', 2);
    $reviewer = make_user('dbcl_credit_officer');
    $otherBranch = make_user('dbcl_supervisor', 1, 'branch-b');
    $supervisor = make_user('dbcl_supervisor');
    $auditor = make_user('dbcl_auditor');
    $maker = make_user('dbcl_finance_maker');
    $checker = make_user('dbcl_finance_checker');
    $administrator = make_user('administrator');

    $plain = 'Synthetic PAN ABCDE1234F';
    $encrypted = Crypto::encrypt($plain);
    check($encrypted !== $plain && str_starts_with($encrypted, 'v1:'), 'Sensitive state is encrypted');
    check(Crypto::decrypt($encrypted) === $plain, 'Authenticated encryption round trip');
    check(Crypto::encrypt($plain) !== $encrypted, 'Encryption uses fresh nonce');
    $tamperedBytes = base64_decode(substr($encrypted, 3), true);
    $tamperedBytes[30] = chr(ord($tamperedBytes[30]) ^ 1);
    $tampered = 'v1:' . base64_encode($tamperedBytes);
    check(is_wp_error(Crypto::decrypt($tampered)), 'Tampered ciphertext rejected');
    check(is_wp_error(Crypto::decrypt('plaintext')), 'Plaintext is never accepted as encrypted state');

    $case = Store::create(basic_case($owner));
    if (!success($case, 'Create encrypted application')) { throw new RuntimeException('Application creation failed.'); }
    $applications[] = $case['id'];
    $read = Store::get($case['id']);
    check($read['parties']['applicant']['profile']['legal_name'] === 'Synthetic Applicant', 'Application state decrypts correctly');
    global $wpdb;
    $raw = $wpdb->get_var($wpdb->prepare('SELECT data FROM ' . $wpdb->prefix . 'dbcl_applications WHERE id=%s', $case['id']));
    check(!str_contains($raw, 'ABCDE1234F') && !str_contains($raw, 'Synthetic Applicant'), 'Database payload contains no plaintext PII');
    $stale = $case;
    $case['purpose'] = 'Updated synthetic purpose';
    $saved = Store::save($case, $case['version'], $owner, 'profile_changed', ['party_role' => 'applicant', 'raw_pan' => 'ABCDE1234F']);
    if (success($saved, 'Versioned application update')) { $case = $saved; }
    check($case['version'] === 2, 'Successful update increments version');
    error_is(Store::save($stale, $stale['version'], $owner, 'stale_write'), 'dbcl_conflict', 'Stale update rejected with optimistic conflict');
    $invalidScope = $case;
    $invalidScope['org_id'] = 2;
    error_is(Store::save($invalidScope, $case['version'], $owner, 'scope_change'), 'dbcl_scope_immutable', 'Organization cannot be reassigned by state update');
    $events = Store::audit($case['id']);
    check(count($events) === 2, 'Failed updates do not append successful audit entries');
    check($events[1]['prev_hash'] === $events[0]['hash'], 'Audit events form a hash chain');
    check(!str_contains(wp_json_encode($events), 'ABCDE1234F'), 'Audit excludes raw sensitive input');

    wp_set_current_user($owner);
    check(Auth::access($case) === true, 'Applicant accesses own application');
    check(Auth::own_party($case, 'applicant') === true, 'Applicant updates own profile');
    check(is_wp_error(Auth::own_party($case, 'guarantor_1')), 'Applicant cannot consent for guarantor');
    wp_set_current_user($other);
    check(is_wp_error(Auth::access($case)), 'Unrelated user denied application');
    wp_set_current_user($foreign);
    check(is_wp_error(Auth::access($case)), 'Cross-organization user denied');
    wp_set_current_user($reviewer);
    check(is_wp_error(Auth::access($case)), 'Unassigned credit officer denied');
    $case['assigned_id'] = $reviewer;
    $case = Store::save($case, $case['version'], $supervisor, 'officer_assigned');
    check(Auth::access($case) === true, 'Assigned credit officer accesses case');
    wp_set_current_user($otherBranch);
    check(is_wp_error(Auth::access($case)), 'Branch restriction enforced');
    wp_set_current_user($auditor);
    check(Auth::access($case, false) === true && is_wp_error(Auth::access($case, true)), 'Auditor can read but cannot mutate');
    wp_set_current_user($administrator);
    check(!in_array('dbcl_finance_check', Auth::actor($case)['capabilities'], true), 'Configuration administrator has no implicit finance-check authority');
    update_option('dbcl_settings', ['require_staff_mfa' => true]);
    wp_set_current_user($reviewer);
    error_is(Auth::access($case, true), 'dbcl_mfa_required', 'Configured staff MFA gate blocks unverified session');
    update_option('dbcl_settings', ['require_staff_mfa' => false]);

    $case['parties']['guarantor_1']['profile'] = ['legal_name' => 'Other Synthetic Party', 'pan' => 'ZZZZZ9999Z', 'mobile' => '9000000000'];
    $case['profile_history'] = [['role' => 'guarantor_1', 'profile' => ['pan' => 'ZZZZZ9999Z'], 'bank' => ['account_number' => '111122223333']]];
    $case['consent_history'] = [['role' => 'guarantor_1', 'record' => ['text' => 'PRIVATE-GUARANTOR-CONSENT']]];
    $case['financial_observations'] = [['notes' => 'PRIVATE-OFFICER-NOTE']];
    wp_set_current_user($owner);
    $view = Auth::public_case($case);
    check(!isset($view['profile_history'], $view['consent_history']) && !str_contains(wp_json_encode($view), 'PRIVATE-'), 'Client projection excludes other-party histories and private officer observations');
    check(!isset($view['parties']['guarantor_1']['profile']), 'Party projection excludes another party profile');
    check(!str_contains(wp_json_encode($view), 'ZZZZZ9999Z'), 'Party projection excludes unrelated PAN');
    check(!str_contains(wp_json_encode($view), '123456789012'), 'Account identifiers masked in client response');
    $ownerUser = get_user_by('id', $owner);
    $ownerUser->add_cap('dbcl_review');
    $view = Auth::public_case($case);
    check(!isset($view['parties']['guarantor_1']['profile']), 'User who is staff and a party remains party-scoped');
    $ownerUser->remove_cap('dbcl_review');

    check(Store::list([])['total'] === 0, 'Unscoped database queue fails closed');
    check(Store::list(['org_id' => 2])['total'] === 0, 'Organization queue isolation');
    check(Store::list(['user_id' => $reviewer])['total'] >= 1, 'Assigned case appears in officer queue');
    check(Store::list(['user_id' => $other])['total'] === 0, 'Unrelated user queue contains no applications');

    $invitation = Store::issue_invitation($case['id'], 'co_applicant', time() + HOUR_IN_SECONDS);
    if (success($invitation, 'Create one-time invitation')) {
        check(strlen($invitation['token']) === 64, 'Invitation has cryptographic random token');
        error_is(Store::claim_invitation($invitation['token'], $owner), 'dbcl_independent_party', 'Applicant cannot claim another required party role');
        $claimed = Store::claim_invitation($invitation['token'], $other);
        if (success($claimed, 'Independent party claims invitation')) { $case = $claimed; }
        check((int) Store::get($case['id'])['parties']['co_applicant']['user_id'] === $other, 'Invitation atomically binds authenticated party');
        check(is_wp_error(Store::claim_invitation($invitation['token'], $foreign)), 'Claimed invitation cannot be replayed');
    }

    $eventId = $testPrefix . ':event';
    $hash = hash('sha256', 'synthetic provider event');
    check(Store::claim_event($eventId, $hash) === true, 'New callback event claimed once');
    check(Store::claim_event($eventId, $hash) === false, 'Identical callback is harmless duplicate');
    error_is(Store::claim_event($eventId, hash('sha256', 'changed')), 'dbcl_callback_replay', 'Callback event ID cannot be reused with changed payload');
    check(is_wp_error(Store::claim_event('../bad', $hash)), 'Malformed callback identifiers rejected');

    $callbackEvent = $testPrefix . ':atomic';
    $beforeCallback = Store::get($case['id']);
    $callbackVersion = $beforeCallback['version'];
    error_is(Store::save($beforeCallback, $callbackVersion - 1, 0, 'provider_callback', [], $callbackEvent, $hash), 'dbcl_conflict', 'Callback state conflict rolls back atomic event claim');
    check(Store::event_status($callbackEvent, $hash) === null, 'Uncommitted callback remains retryable after rollback');
    $atomic = Store::save($beforeCallback, $callbackVersion, 0, 'provider_callback', [], $callbackEvent, $hash);
    if (success($atomic, 'Callback state and inbox commit atomically')) { $case = $atomic; }
    $duplicate = Store::save($beforeCallback, $callbackVersion, 0, 'provider_callback', [], $callbackEvent, $hash);
    check(!is_wp_error($duplicate) && !empty($duplicate['_callback_duplicate']) && $duplicate['version'] === $case['version'], 'Callback retry remains idempotent even with stale original expected version');
    check(Store::event_status($callbackEvent, $hash) === true, 'Committed callback visible in read-only replay lookup');
    error_is(Store::save($case, $case['version'], 0, 'provider_callback', [], $callbackEvent, hash('sha256', 'changed callback')), 'dbcl_callback_replay', 'Atomic callback rejects event ID with altered payload');

    $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jrS0AAAAASUVORK5CYII=');
    $temp = tempnam(sys_get_temp_dir(), 'dbcl-fixture-');
    file_put_contents($temp, $png);
    $file = Store::store_file($case['id'], $case['parties']['applicant']['id'], 'live_photo', $temp, 'image/png');
    if (success($file, 'Original image stored privately')) {
        check(!isset($file['path']) && $file['scan_status'] === 'PENDING', 'Upload metadata reveals no storage path or fabricated scan pass');
        $readFile = Store::read_file($file['id']);
        check(!is_wp_error($readFile) && $readFile['bytes'] === $png, 'Private encrypted image download round trip');
        $diskName = $wpdb->get_var($wpdb->prepare('SELECT path FROM ' . $wpdb->prefix . 'dbcl_files WHERE id=%s', $file['id']));
        $disk = rtrim(DBCL_PRIVATE_DIR, '/') . '/' . $diskName;
        check(!str_contains(file_get_contents($disk), $png), 'Private image bytes encrypted at rest');
        error_is(Store::store_file($case['id'], $case['parties']['applicant']['id'], 'live_photo', $temp, 'application/pdf'), 'dbcl_file_type', 'MIME mismatch rejected');
    }
    file_put_contents($temp, '<?php echo "unsafe";');
    check(is_wp_error(Store::store_file($case['id'], $case['parties']['applicant']['id'], 'identity', $temp, 'image/jpeg')), 'Executable disguised as image rejected');
    unlink($temp);

    // Providers remain unavailable without individual consent and never route inactive Aadhaar OTP products.
    check(!isset(Providers::catalog()['aadhaar-v2-generate-otp']), 'Inactive Aadhaar OTP operation is not enabled');
    check(is_wp_error(Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], [])), 'KYC without recorded consent denied');
    $context = ['consent' => true, 'party_id' => $case['parties']['applicant']['id'], 'application_id' => $case['id'], 'consent_purpose' => 'kyc', 'settings' => ['surepass_environment' => 'sandbox']];
    $missingToken = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
    check(is_wp_error($missingToken) && $missingToken->get_error_code() !== 'surepass_consent_required', 'UUID-based provider consent context accepted');

    $oldToken = getenv('DBCL_SUREPASS_TOKEN');
    $oldWebhook = getenv('DBCL_WEBHOOK_SECRET');
    putenv('DBCL_SUREPASS_TOKEN=synthetic-test-token-never-a-live-key');
    putenv('DBCL_WEBHOOK_SECRET=synthetic-test-webhook-secret');
    $mockBody = ['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'bank_validation_synthetic', 'account_exists' => true, 'full_name' => 'Synthetic Applicant', 'account_number' => '123456789012', 'ifsc' => 'HDFC0000001']];
    $observedRequest = [];
    $mock = static function ($pre, $args, $url) use (&$mockBody, &$observedRequest) {
        $observedRequest = ['url' => $url, 'args' => $args];
        return ['headers' => [], 'body' => wp_json_encode($mockBody), 'response' => ['code' => 200, 'message' => 'OK'], 'cookies' => []];
    };
    add_filter('pre_http_request', $mock, 20, 3);
    $context['expected_name'] = 'Synthetic Applicant';
    $verified = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
    if (success($verified, 'Source-proven bank contract sends mocked verification')) {
        check($verified['status'] === 'verified', 'Bank verification requires positive existence and matched holder');
        check(!str_contains(wp_json_encode($verified), '123456789012') && !str_contains(wp_json_encode($verified), 'synthetic-test-token'), 'Normalized provider result excludes credentials and full bank identifiers');
        check($observedRequest['args']['sslverify'] === true && $observedRequest['args']['redirection'] === 0, 'Provider TLS and redirect protections preserved');
        check($observedRequest['url'] === 'https://sandbox.surepass.app/api/v1/bank-verification/', 'Recovered bank route uses restricted sandbox host');
        $sent = json_decode($observedRequest['args']['body'], true);
        check($sent['id_number'] === '123456789012' && $sent['ifsc'] === 'HDFC0000001', 'Recovered bank payload uses correct mapped fields');
    }
    $mockBody = ['success' => true, 'data' => []];
    $incomplete = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
    check(!is_wp_error($incomplete) && $incomplete['status'] === 'review_required', 'HTTP200 success without verified evidence cannot pass KYC');
    $mockBody = ['success' => true, 'data' => ['account_exists' => true, 'full_name' => 'Different Holder']];
    $mismatch = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
    check(!is_wp_error($mismatch) && $mismatch['status'] === 'review_required', 'Different bank account holder is not automatically verified');
    $mockBody = ['success' => true, 'data' => ['account_exists' => false, 'full_name' => 'Synthetic Applicant']];
    $nonexistent = Providers::request('bank-verification', ['account_number' => '123456789012', 'ifsc' => 'HDFC0000001'], $context);
    check(!is_wp_error($nonexistent) && $nonexistent['status'] === 'failed', 'Explicitly nonexistent bank account fails verification');
    $invalidPathContext = $context;
    $invalidPathContext['settings']['surepass_mappings']['bank-verification'] = ['confirmed' => true, 'path' => 'https://evil.invalid/steal'];
    check(is_wp_error(Providers::request('bank-verification', [], $invalidPathContext)), 'Provider mappings cannot override restricted host');
    remove_filter('pre_http_request', $mock, 20);
    $rawEvent = wp_json_encode(['application_id' => $case['id'], 'status' => 'SETTLED']);
    $timestamp = (string) time();
    $callbackId = $testPrefix . '_callback';
    $signature = hash_hmac('sha256', $timestamp . '.' . $callbackId . '.' . $rawEvent, 'synthetic-test-webhook-secret');
    check(Providers::verify_callback($rawEvent, $signature, $timestamp, $callbackId) === true, 'Authenticated callback envelope accepted');
    check(is_wp_error(Providers::verify_callback($rawEvent . ' ', $signature, $timestamp, $callbackId)), 'Changed callback payload rejected');
    check(is_wp_error(Providers::verify_callback($rawEvent, $signature, (string) (time() - 600), $callbackId)), 'Expired callback rejected');
    check(is_wp_error(Providers::verify_callback($rawEvent, str_repeat('0', 64), $timestamp, $callbackId)), 'Forged callback signature rejected');
    putenv($oldToken === false ? 'DBCL_SUREPASS_TOKEN' : 'DBCL_SUREPASS_TOKEN=' . $oldToken);
    putenv($oldWebhook === false ? 'DBCL_WEBHOOK_SECRET' : 'DBCL_WEBHOOK_SECRET=' . $oldWebhook);

    // REST endpoint permissions exercise actual registered WordPress routes.
    wp_set_current_user(0);
    $response = api('GET', '/applications/' . $case['id']);
    check($response->get_status() === 401, 'Unauthenticated REST application denied');
    wp_set_current_user($foreign);
    $response = api('GET', '/applications/' . $case['id']);
    check($response->get_status() === 403, 'Cross-organization REST application denied');
    wp_set_current_user($other);
    $response = api('GET', '/applications/' . $case['id']);
    check($response->get_status() === 200, 'Linked co-applicant can open REST case');
    if ($response->get_status() === 200) {
        check(!str_contains(wp_json_encode($response->get_data()), 'ABCDE1234F'), 'REST case masks another party identity');
    }
    wp_set_current_user($owner);
    $response = api('POST', '/applications/' . $case['id'] . '/commands', ['command' => 'set_status', 'input' => ['status' => 'DISBURSED'], 'expected_version' => $case['version']]);
    check($response->get_status() >= 400, 'REST has no unrestricted status-setting command');
    wp_set_current_user($auditor);
    $response = api('POST', '/applications/' . $case['id'] . '/commands', ['command' => 'assign_officer', 'input' => ['officer_id' => $reviewer], 'expected_version' => $case['version']]);
    check($response->get_status() === 403, 'Auditor mutation denied through REST');

    require __DIR__ . '/workflow.php';
    dbcl_workflow_tests(['applicant' => $owner, 'co_applicant' => $other, 'guarantor_1' => make_user(), 'guarantor_2' => make_user(), 'reviewer' => $reviewer, 'supervisor' => $supervisor, 'operations' => make_user('dbcl_operations_officer'), 'verifier' => make_user('dbcl_verification_officer'), 'maker' => $maker, 'checker' => $checker]);
    require __DIR__ . '/governance.php';
    dbcl_governance_tests(['administrator' => $administrator, 'checker' => $checker, 'applicant' => $owner, 'co_applicant' => $other, 'reviewer' => $reviewer, 'unrelated' => make_user()]);
    require __DIR__ . '/kyc.php';
    dbcl_kyc_tests(['applicant' => $owner, 'supervisor' => $supervisor]);
    require __DIR__ . '/esign.php';
    dbcl_esign_tests(['applicant' => $owner, 'co_applicant' => $other, 'operations' => make_user('dbcl_operations_officer')]);
    if (is_file(__DIR__ . '/documents.php')) { require __DIR__ . '/documents.php'; dbcl_document_tests(); }
} catch (Throwable $e) {
    $failures[] = 'Unhandled test exception: ' . $e->getMessage();
    fwrite(STDERR, end($failures) . '\n' . $e->getTraceAsString() . "\n");
} finally {
    wp_set_current_user(0);
    global $wpdb;
    foreach ($applications as $applicationId) {
        $paths = $wpdb->get_col($wpdb->prepare('SELECT path FROM ' . $wpdb->prefix . 'dbcl_files WHERE application_id=%s', $applicationId));
        foreach ($paths as $path) {
            if (preg_match('/^[a-f0-9]{48}\.enc$/D', $path) && defined('DBCL_PRIVATE_DIR')) { @unlink(rtrim(DBCL_PRIVATE_DIR, '/') . '/' . $path); }
        }
        foreach (['members', 'events', 'files', 'invitations', 'applications'] as $table) {
            $key = $table === 'applications' ? 'id' : 'application_id';
            $wpdb->delete($wpdb->prefix . 'dbcl_' . $table, [$key => $applicationId]);
        }
    }
    $wpdb->query($wpdb->prepare('DELETE FROM ' . $wpdb->prefix . 'dbcl_inbox WHERE event_id LIKE %s', $wpdb->esc_like($testPrefix) . '%'));
    foreach ($users as $id) { wp_delete_user($id); }
    if ($oldSettings === null) { delete_option('dbcl_settings'); } else { update_option('dbcl_settings', $oldSettings); }
}
printf("%d assertions executed; %d failures.\n", $assertions, count($failures));
exit($failures ? 1 : 0);
