<?php
use DigitalBE\ClientGroupLoans\Store;
use DigitalBE\ClientGroupLoans\Workflow;

function dbcl_kyc_tests(array $ids): void {
    global $applications;
    $oldSettings = get_option('dbcl_settings', []);
    $oldToken = getenv('DBCL_SUREPASS_TOKEN');
    $settings = ['surepass_environment' => 'sandbox', 'require_staff_mfa' => false, 'consent_texts' => ['kyc' => ['version' => 'kyc-test-v1', 'text' => 'Synthetic KYC purpose consent'], 'data_processing' => ['version' => 'processing-test-v1', 'text' => 'Synthetic application data processing consent']]];
    update_option('dbcl_settings', $settings);
    putenv('DBCL_SUREPASS_TOKEN=synthetic-test-token-never-a-live-key');
    $case = basic_case($ids['applicant']);
    $party =& $case['parties']['applicant'];
    $party['profile']['mobile'] = '9876543210';
    $party['bank'] += ['ifsc' => 'HDFC0000001', 'holder_name' => 'Synthetic Applicant'];
    foreach ($settings['consent_texts'] as $purpose => $definition) { $party['consents'][$purpose] = ['accepted' => true, 'version' => $definition['version'], 'text' => $definition['text'], 'actor_id' => $ids['applicant']]; }
    unset($party);
    $case = Store::create($case);
    if (is_wp_error($case)) { throw new RuntimeException('Synthetic KYC application could not be created.'); }
    $applications[] = $case['id'];
    $calls = 0; $mode = 'success'; $reservations = []; $alterIdentity = false;
    $mock = static function ($preempt, $args, $url) use (&$calls, &$mode, &$reservations, &$alterIdentity, &$case) {
        $calls++;
        $stored = Store::get($case['id']);
        $operation = str_contains($url, 'bank-verification') ? 'bank-verification' : 'pan-advanced-v3';
        $reservations[] = $stored['parties']['applicant']['kyc_requests'][$operation]['status'] ?? '';
        if ($alterIdentity) {
            $stored['parties']['applicant']['profile']['legal_name'] = 'Changed During Request';
            Store::save($stored, $stored['version'], 0, 'synthetic_concurrent_identity_change');
        }
        if ($mode === 'timeout') { return new WP_Error('synthetic_timeout', 'Synthetic response timeout; no real network request.'); }
        return ['response' => ['code' => 200], 'body' => wp_json_encode(['success' => true, 'status_code' => 200, 'data' => ['client_id' => 'pan_SYNTHETIC123456', 'pan_number' => 'ABCDE1234F', 'pan_status' => 'E', 'full_name' => 'Synthetic Applicant', 'account_exists' => true]])];
    };
    add_filter('pre_http_request', $mock, 30, 3);
    try {
        wp_set_current_user($ids['applicant']);
        $result = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'pan-advanced-v3', 'expected_version' => $case['version']]);
        check($result->get_status() === 200 && $calls === 1 && $reservations[0] === 'PROCESSING', 'kyc: durable reservation precedes paid provider request');
        $case = Store::get($case['id']);
        $kyc = $case['parties']['applicant']['kyc']['pan-advanced-v3'] ?? [];
        check(($kyc['status'] ?? '') === 'verified' && ($kyc['profile_hash'] ?? '') === Workflow::identity_hash($case['parties']['applicant']), 'kyc: verified result binds exact participant profile');
        $cached = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'pan-advanced-v3', 'expected_version' => $case['version']]);
        check($cached->get_status() === 200 && $calls === 1, 'kyc: unchanged completed input reuses result instead of creating paid request');
        $unmapped = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'pan-advanced-v3', 'payload' => ['unmapped_browser_nonce' => 'different-input-that-is-not-sent'], 'expected_version' => $case['version']]);
        check($unmapped->get_status() === 200 && $calls === 1, 'kyc: an unmapped browser field cannot defeat paid-request deduplication');
        $bankResult = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'bank-verification', 'expected_version' => $case['version']]);
        $case = Store::get($case['id']);
        check($bankResult->get_status() === 200 && $calls === 2, 'kyc: first bank request is reserved and completed independently');
        check(($case['parties']['applicant']['kyc']['bank-verification']['environment'] ?? '') === 'sandbox', 'kyc: sandbox evidence preserves its provider environment');
        $cachedBank = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'bank-verification', 'payload' => ['ignored' => 'different'], 'expected_version' => $case['version']]);
        check($cachedBank->get_status() === 200 && $calls === 2, 'kyc: stored bank verification metadata cannot create another billable request');
        $changedConsent = $settings; $changedConsent['consent_texts']['kyc']['version'] = 'new-unaccepted-version'; update_option('dbcl_settings', $changedConsent);
        $staleConsent = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'pan-advanced-v3', 'expected_version' => $case['version']]);
        check($staleConsent->get_status() === 422 && $calls === 2, 'kyc: superseded purpose consent cannot authorize another enquiry');
        update_option('dbcl_settings', $settings);
        $incomplete = api('POST', '/applications/' . $case['id'] . '/commands', ['command' => 'submit_documents', 'input' => [], 'expected_version' => $case['version']]);
        check($incomplete->get_status() === 422, 'submission: server rejects incomplete required participant fields');
        $case['parties']['applicant']['bank']['account_number'] = '09876543210';
        unset($case['parties']['applicant']['bank']['verification']);
        $case = Store::save($case, $case['version'], 0, 'synthetic_changed_account');
        $mode = 'timeout';
        $timeout = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'bank-verification', 'expected_version' => $case['version']]);
        $case = Store::get($case['id']);
        check($timeout->get_status() === 502 && ($case['parties']['applicant']['kyc_requests']['bank-verification']['status'] ?? '') === 'UNKNOWN', 'kyc: timeout is durably unknown rather than failed or verified');
        $callsBefore = $calls;
        $retry = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'bank-verification', 'expected_version' => $case['version']]);
        check($retry->get_status() === 409 && $calls === $callsBefore, 'kyc: unknown outcome blocks blind paid retry');
        $requestId = $case['parties']['applicant']['kyc_requests']['bank-verification']['id'];
        wp_set_current_user($ids['supervisor']);
        $noEvidence = api('POST', '/applications/' . $case['id'] . '/kyc/reconcile', ['role' => 'applicant', 'operation' => 'bank-verification', 'request_id' => $requestId, 'expected_version' => $case['version']]);
        check($noEvidence->get_status() === 400, 'kyc: unknown result cannot be cleared without provider evidence');
        $reconciled = api('POST', '/applications/' . $case['id'] . '/kyc/reconcile', ['role' => 'applicant', 'operation' => 'bank-verification', 'request_id' => $requestId, 'provider_confirmed_not_processed' => true, 'evidence_ref' => 'SYNTHETIC-PROVIDER-RECONCILIATION', 'expected_version' => $case['version']]);
        $case = Store::get($case['id']);
        check($reconciled->get_status() === 200 && $case['parties']['applicant']['kyc_requests']['bank-verification']['status'] === 'FAILED', 'kyc: independent evidenced not-processed reconciliation allows fresh attempt');
        wp_set_current_user($ids['applicant']);
        $mode = 'success'; $alterIdentity = true;
        $stale = api('POST', '/applications/' . $case['id'] . '/kyc', ['role' => 'applicant', 'operation' => 'bank-verification', 'expected_version' => $case['version']]);
        $case = Store::get($case['id']);
        check($stale->get_status() === 409 && ($case['parties']['applicant']['kyc_requests']['bank-verification']['status'] ?? '') === 'PROCESSING', 'kyc: profile change during provider call cannot attach stale verified result or silently retry');
        check(!Workflow::evaluate($case)['identity_kyc']['passed'], 'kyc: changed identity no longer satisfies prior profile-bound KYC');
        $user = get_user_by('id', $ids['applicant']); $user->add_cap('dbcl_review');
        $otherParty = api('POST', '/applications/' . $case['id'] . '/profile', ['role' => 'guarantor_1', 'profile' => ['legal_name' => 'Unauthorized Assisted Entry'], 'expected_version' => $case['version']]);
        check($otherParty->get_status() === 403, 'kyc: staff-plus-party session cannot edit another party profile');
        $user->remove_cap('dbcl_review');
    } finally {
        remove_filter('pre_http_request', $mock, 30);
        putenv($oldToken === false ? 'DBCL_SUREPASS_TOKEN' : 'DBCL_SUREPASS_TOKEN=' . $oldToken);
        update_option('dbcl_settings', $oldSettings);
    }
}
